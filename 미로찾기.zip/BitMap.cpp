#include "BitMap.h"

BitMap* BitMap::m_hThis = NULL;
void BitMap::SetDC(HDC hdc)
{
	MemDC[0]= CreateCompatibleDC(hdc);
	curImage[0] = CreateCompatibleBitmap(hdc, MAP_WIDTH, MAP_HEIGHT);
	oldImage[0] = (HBITMAP)SelectObject(MemDC[0], curImage[0]);

	HBRUSH hWhite = (HBRUSH)GetStockObject(WHITE_BRUSH);
	SelectObject(MemDC[0], hWhite);
	Rectangle(MemDC[0], 0, 0, MAP_WIDTH, MAP_HEIGHT);
	for (int i = 0; i < 24; i++)
	{
		for (int j = 0; j < 24; j++)
			Rectangle(MemDC[0], BLOCK_WIDTH * i, BLOCK_HEIGHT * j, (BLOCK_WIDTH * i) + BLOCK_WIDTH, (BLOCK_HEIGHT * j) + BLOCK_HEIGHT);
	}
	SelectObject(MemDC[0], curImage[0]);
	DeleteObject(hWhite);

	MemDC[1] = CreateCompatibleDC(MemDC[0]);
	curImage[1] = (HBITMAP)LoadImage(NULL, "block.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE);
	oldImage[1] = (HBITMAP)SelectObject(MemDC[1], curImage[1]);

	MemDC[2] = CreateCompatibleDC(MemDC[0]);
	curImage[2] = (HBITMAP)LoadImage(NULL, "goal.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE);
	oldImage[2] = (HBITMAP)SelectObject(MemDC[2], curImage[2]);

	MemDC[3] = CreateCompatibleDC(MemDC[0]);
	curImage[3] = (HBITMAP)LoadImage(NULL, "image.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE);
	oldImage[3] = (HBITMAP)SelectObject(MemDC[3], curImage[3]);

	MemDC[4] = CreateCompatibleDC(MemDC[0]);
	curImage[4] = (HBITMAP)LoadImage(NULL, "back.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE);
	oldImage[4] = (HBITMAP)SelectObject(MemDC[4], curImage[4]);
}

void BitMap::DrawPlayer(int x, int y, int way, int type)
{
	BITMAP btSize; 
	GetObject(curImage[3], sizeof(btSize), &btSize);

	TransparentBlt(MemDC[0], x, y, BLOCK_WIDTH, BLOCK_HEIGHT, MemDC[3], (btSize.bmWidth / 4)* type, (btSize.bmHeight / 4)* way, (btSize.bmWidth / 4), (btSize.bmHeight / 4), RGB(255, 0, 255));
}

void BitMap::DrawBlock(int x, int y, int Type)
{
	BITMAP btSize;
	if (Type == BLOCK)
	{
		GetObject(curImage[1], sizeof(btSize), &btSize);
		TransparentBlt(MemDC[0], BLOCK_WIDTH * x, BLOCK_HEIGHT * y, BLOCK_WIDTH, BLOCK_HEIGHT, MemDC[1], 0, 0, btSize.bmWidth, btSize.bmHeight, RGB(255, 0, 255));
	}
	else if (Type == GOAL)
	{
		GetObject(curImage[2], sizeof(btSize), &btSize);
		TransparentBlt(MemDC[0], BLOCK_WIDTH * x, BLOCK_HEIGHT * y, BLOCK_WIDTH, BLOCK_HEIGHT, MemDC[2], 0, 0, btSize.bmWidth, btSize.bmHeight, RGB(255, 0, 255));
	}
}

void BitMap::DrawObject(int x, int y, int Type)
{
	if (Type >= 400 && Type < 500)
	{
		if (Type % 2 == 0)
		{
			HBRUSH hRed = (HBRUSH)CreateSolidBrush(RGB(255, 0, 0));
			SelectObject(MemDC[0], hRed);
			Ellipse(MemDC[0], BLOCK_WIDTH * x, BLOCK_HEIGHT * y, (BLOCK_WIDTH * x) + BLOCK_WIDTH, (BLOCK_HEIGHT * y) + BLOCK_HEIGHT);
			SelectObject(MemDC[0], curImage[0]);
			DeleteObject(hRed);
		}
		else
		{
			HBRUSH hBlue = (HBRUSH)CreateSolidBrush(RGB(0, 84, 255));
			SelectObject(MemDC[0], hBlue);
			Ellipse(MemDC[0], BLOCK_WIDTH * x, BLOCK_HEIGHT * y, (BLOCK_WIDTH * x) + BLOCK_WIDTH, (BLOCK_HEIGHT * y) + BLOCK_HEIGHT);
			SelectObject(MemDC[0], curImage[0]);
			DeleteObject(hBlue);
		}
	}
	else if (Type >= 500 && Type < 600)
	{
		if (Type % 2 == 0)
		{
			HBRUSH hRed = (HBRUSH)CreateSolidBrush(RGB(255, 0, 0));
			SelectObject(MemDC[0], hRed);
			Rectangle(MemDC[0], BLOCK_WIDTH * x, BLOCK_HEIGHT * y, (BLOCK_WIDTH * x) + BLOCK_WIDTH, (BLOCK_HEIGHT * y) + BLOCK_HEIGHT);
			SelectObject(MemDC[0], curImage[0]);
			DeleteObject(hRed);
		}
		else
		{
			HBRUSH hBlue = (HBRUSH)CreateSolidBrush(RGB(0, 84, 255));
			SelectObject(MemDC[0], hBlue);
			Rectangle(MemDC[0], BLOCK_WIDTH * x, BLOCK_HEIGHT * y, (BLOCK_WIDTH * x) + BLOCK_WIDTH, (BLOCK_HEIGHT * y) + BLOCK_HEIGHT);
			SelectObject(MemDC[0], curImage[0]);
			DeleteObject(hBlue);
		}
	}
	else if (Type == 6)
	{
		HBRUSH hYellow = (HBRUSH)CreateSolidBrush(RGB(255, 228, 0));
		SelectObject(MemDC[0], hYellow);
		Rectangle(MemDC[0], BLOCK_WIDTH * x, BLOCK_HEIGHT * y, (BLOCK_WIDTH * x) + BLOCK_WIDTH, (BLOCK_HEIGHT * y) + BLOCK_HEIGHT);
		SelectObject(MemDC[0], curImage[0]);
		DeleteObject(hYellow);
	}
	else if (Type == 7)
	{
		HBRUSH hYellow = (HBRUSH)CreateSolidBrush(RGB(255, 228, 0));
		SelectObject(MemDC[0], hYellow);
		Ellipse(MemDC[0], BLOCK_WIDTH * x, BLOCK_HEIGHT * y, (BLOCK_WIDTH * x) + BLOCK_WIDTH, (BLOCK_HEIGHT * y) + BLOCK_HEIGHT);
		SelectObject(MemDC[0], curImage[0]);
		DeleteObject(hYellow);
	}
}

void BitMap::DrawGame(HDC hdc)
{
	TransparentBlt(hdc, 30, 0, MAP_WIDTH, MAP_HEIGHT, MemDC[0], 0, 0, MAP_WIDTH, MAP_HEIGHT, RGB(255, 0, 255));
}

void BitMap::ReleaseBit()
{
	for (int i = 4; i >= 0; i--)
	{
		SelectObject(MemDC[i], oldImage[i]);
		DeleteObject(curImage[i]);
		DeleteDC(MemDC[i]);
	}
}

void BitMap::DeleteBitMap()
{
	delete m_hThis;
	m_hThis = NULL;
}
