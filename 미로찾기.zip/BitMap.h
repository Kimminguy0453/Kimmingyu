#pragma once
#include <Windows.h>
#include <iostream>
using namespace std;
#define MAP_HEIGHT 1000
#define MAP_WIDTH 1900
#define BLOCK_HEIGHT 40
#define BLOCK_WIDTH 75
#define SCREEN_HEIGHT 1890
#define SCREEN_WIDTH 1880

enum IMAGETYPE
{
	PLAYER_ICON = 1,
	GOAL = 2,
	BLOCK = 3,
	BROKEN_BLOCK = 6,
	ITEM = 7
};

class BitMap
{
private:
	HDC MemDC[4];
	HBITMAP curImage[5];
	HBITMAP oldImage[5];
	static BitMap* m_hThis;
public:
	static BitMap* GetInstance()
	{
		if (m_hThis == NULL)
			m_hThis = new BitMap;
		return m_hThis;
	}
	void SetDC(HDC hdc);
	void DrawPlayer(int x, int y, int Way, int Type);
	void DrawBlock(int x, int y, int Type);
	void DrawGame(HDC hdc);
	void DrawObject(int x, int y, int Type);
	void ReleaseBit();
	void DeleteBitMap();
};

