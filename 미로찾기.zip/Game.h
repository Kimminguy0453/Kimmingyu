#pragma once
#include "BitMap.h"
#define MAP_MAX 1

enum MOVESET
{
	DOWN,
	UP,
	LEFT,
	RIGHT
};


struct Character
{
	POINT starting_pt;
	POINT cur_pt;
	POINT pt;
	int Way;
	int Type;
	int ItemCount;
	int CurBlock;
	bool Move;
	bool Use;

};

class Game
{
private:
	LARGE_INTEGER Start, End, Frequency;
	double Delta;
	Character player;
	int g_map[24][24];
	bool CounterOn;
	bool GameFlag;
	int Stage;
public:
	Game(HWND hWnd);
	void MoveInput();
	void PlayerMove(HWND hWnd);
	void GameDraw(HWND hWnd);
	void LoadMap(HWND hWnd);
	bool GameUpdate(HWND hWnd);
	void MotionUpdate();
	void ResetDelta();
	void GameEnd(HWND hWnd);
	void PlayerEvent(HWND hWnd);
	bool SwitchCheck(int Num);
	inline bool GetFlag()
	{
		return GameFlag;
	}
	~Game();
};

