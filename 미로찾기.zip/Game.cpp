#include "Game.h"

Game::Game(HWND hWnd)
{
	GameFlag = true;
	player.Way = RIGHT;
	player.Type = 0;
	player.Move = false;
	player.ItemCount = 0;
	Stage = 1;
	LoadMap(hWnd);
	CounterOn = false;
	Delta = 0;
}

bool Game::GameUpdate(HWND hWnd)
{
	QueryPerformanceFrequency(&Frequency);
	if (!CounterOn)
	{
		QueryPerformanceCounter(&Start);
		CounterOn = true;
	}
	else
	{
		QueryPerformanceCounter(&End);
		if (!player.Move)
			MoveInput();
		else
		{
			Delta += (double)(End.QuadPart - Start.QuadPart) / (double)(Frequency.QuadPart);
			if (Delta > 1)
				Delta = 1;
			PlayerMove(hWnd);
			return true;
		}
		Start = End;
	}
	return false;
}

void Game::PlayerEvent(HWND hWnd)
{
	if (g_map[player.pt.x][player.pt.y] == GOAL)
	{
		player.Use = false;
		if (Stage < MAP_MAX)
		{
			if (MessageBox(hWnd, TEXT("���� �������� ����"), TEXT("Stage Clear!!"), MB_YESNO) == IDYES)
			{
				Stage++;
				player.Use = false;
				LoadMap(hWnd);
			}
			else
				GameEnd(hWnd);
		}
		else
			GameEnd(hWnd);
	}
	else if (g_map[player.pt.x][player.pt.y] == ITEM)
	{
		player.ItemCount++;
		g_map[player.pt.x][player.pt.y] = 0;
	}
	else if (g_map[player.pt.x][player.pt.y] >= 400 && g_map[player.pt.x][player.pt.y] < 500)
	{
		if (g_map[player.pt.x][player.pt.y] % 2 == 1)
		{
			int ExitPotal = g_map[player.pt.x][player.pt.y] - 1;
			for (int i = 0; i < 24; i++)
			{
				for (int j = 0; j < 24; j++)
				{
					if (g_map[j][i] == ExitPotal)
					{
						player.pt.x = j;
						player.pt.y = i;
						player.cur_pt.x = player.pt.x *BLOCK_WIDTH;
						player.cur_pt.y = player.pt.y *BLOCK_HEIGHT;
						player.starting_pt.x = player.cur_pt.x;
						player.starting_pt.y = player.cur_pt.y;
					}
				}
			}
		}
	}
	else if (g_map[player.pt.x][player.pt.y] >= 500 && g_map[player.pt.x][player.pt.y] < 600)
	{
		if (g_map[player.pt.x][player.pt.y] % 2 == 0)
		{	
			int Door = g_map[player.pt.x][player.pt.y] + 1;
			g_map[player.pt.x][player.pt.y] = 0;
			for (int i = 0; i < 24; i++)
			{
				for (int j = 0; j < 24; j++)
				{
					if (g_map[j][i] == Door)
						g_map[j][i] = 0;
				}
			}
		}
	}
}

void Game::GameEnd(HWND hWnd)
{
	MessageBox(hWnd, TEXT("���� ����"), TEXT("Stage Clear"), MB_OK);
	player.Use = false;
	GameFlag = false;
	memset(g_map, 0, sizeof(int) * 24 * 24);
}

void Game::PlayerMove(HWND hWnd)
{
	if (player.Use)
	{
		if (player.Way == LEFT)
		{
			if (player.starting_pt.x - (int)(BLOCK_WIDTH * Delta) >= 0)
				player.cur_pt.x = player.starting_pt.x - (int)(BLOCK_WIDTH * Delta);
		}
		else if (player.Way == RIGHT)
		{
			if (player.starting_pt.x + (int)(BLOCK_WIDTH * Delta) <= MAP_WIDTH - BLOCK_WIDTH)
				player.cur_pt.x = player.starting_pt.x + (int)(BLOCK_WIDTH * Delta);
		}
		else if (player.Way == UP)
		{
			if (player.starting_pt.y - (int)(BLOCK_HEIGHT  * Delta) >= 0)
				player.cur_pt.y = player.starting_pt.y - (int)(BLOCK_HEIGHT  * Delta);
		}
		else if (player.Way == DOWN)
		{
			if (player.starting_pt.y + (int)(BLOCK_HEIGHT  * Delta) <= MAP_HEIGHT - BLOCK_HEIGHT)
				player.cur_pt.y = player.starting_pt.y + (int)(BLOCK_HEIGHT  * Delta);
		}
		if (Delta == 1)
		{
			ResetDelta();
			PlayerEvent(hWnd);
		}
		MotionUpdate();
	}
}

void Game::ResetDelta()
{
	Delta = 0;
	player.Move = false;
	player.starting_pt.x = player.cur_pt.x;
	player.starting_pt.y = player.cur_pt.y;
	player.pt.x = player.starting_pt.x / BLOCK_WIDTH;
	player.pt.y = player.starting_pt.y / BLOCK_HEIGHT;
}

void Game::MotionUpdate()
{
	if (player.Move)
	{
		player.Type++;
		if (player.Type > 3)
			player.Type = 0;
	}
	else
		player.Type = 0;
}

void Game::MoveInput()
{
	if (player.Use)
	{
		if (GetKeyState(VK_LEFT) & 0x8000)
		{
			player.Way = LEFT;
			if (player.starting_pt.x - BLOCK_WIDTH < 0)
				player.Move = false;
			else if (g_map[player.pt.x - 1][player.pt.y] == BLOCK)
				player.Move = false;
			else if (g_map[player.pt.x - 1][player.pt.y ] == BROKEN_BLOCK)
			{
				if (player.ItemCount == 0)
					player.Move = false;
				else
				{
					g_map[player.pt.x - 1][player.pt.y ] = 0;
					player.ItemCount--;
					player.Move = true;
				}
			}
			else
				player.Move = true;
		}
		else if (GetKeyState(VK_RIGHT) & 0x8000)
		{
			player.Way = RIGHT;
			if (player.starting_pt.x + BLOCK_WIDTH > BLOCK_WIDTH * 23)
				player.Move = false;
			else if (g_map[player.pt.x + 1][player.pt.y] == BLOCK)
				player.Move = false;
			else if (g_map[player.pt.x + 1][player.pt.y] == BROKEN_BLOCK)
			{
				if(player.ItemCount == 0)
					player.Move = false;
				else
				{
					g_map[player.pt.x + 1][player.pt.y] = 0;
					player.ItemCount--;
					player.Move = true;
				}
			}
			else
				player.Move = true;
		}
		else if (GetKeyState(VK_UP) & 0x8000)
		{
			player.Way = UP;
			if (player.starting_pt.y + BLOCK_HEIGHT < 0)
				player.Move = false;
			else if (g_map[player.pt.x][player.pt.y - 1] == BLOCK)
				player.Move = false;
			else if (g_map[player.pt.x][player.pt.y - 1] == BROKEN_BLOCK)
			{
				if (player.ItemCount == 0)
					player.Move = false;
				else
				{
					g_map[player.pt.x][player.pt.y - 1] = 0;
					player.ItemCount--;
					player.Move = true;
				}
			}
			else
				player.Move = true;
		}
		else if (GetKeyState(VK_DOWN) & 0x8000)
		{
			player.Way = DOWN;
			if (player.starting_pt.y + BLOCK_HEIGHT >BLOCK_HEIGHT * 23)
				player.Move = false;
			else if (g_map[player.pt.x][player.pt.y + 1] == BLOCK)
				player.Move = false;
			else if (g_map[player.pt.x][player.pt.y + 1] == BROKEN_BLOCK)
			{
				if (player.ItemCount == 0)
					player.Move = false;
				else
				{
					g_map[player.pt.x][player.pt.y + 1] = 0;
					player.ItemCount--;
					player.Move = true;
				}
			}
			else
				player.Move = true;
		}
		else
			player.Move = false;
	}
}

void Game::GameDraw(HWND hWnd)
{
	HDC hdc = GetDC(hWnd);
	BitMap::GetInstance()->SetDC(hdc);
	for (int i = 0; i < 24; i++)
	{
		for (int j = 0; j < 24; j++)
		{
			if (g_map[j][i] == GOAL || g_map[j][i] == BLOCK)

				BitMap::GetInstance()->DrawBlock(j, i, g_map[j][i]);
			else if(g_map[j][i] >= 400 && g_map[j][i] < 600)
				BitMap::GetInstance()->DrawObject(j, i, g_map[j][i]);
			else if(g_map[j][i] == BROKEN_BLOCK || g_map[j][i] == ITEM)
				BitMap::GetInstance()->DrawObject(j, i, g_map[j][i]);
		}
	}
	if(player.Use)
		BitMap::GetInstance()->DrawPlayer(player.cur_pt.x, player.cur_pt.y, player.Way, player.Type);
	BitMap::GetInstance()->DrawGame(hdc);
	BitMap::GetInstance()->ReleaseBit();
	ReleaseDC(hWnd, hdc);
}

void Game::LoadMap(HWND hWnd)
{
	memset(g_map, 0, sizeof(int) * 24 * 24);
	char File[MAX_PATH] = "";
	wsprintf(File, "Stage%d", Stage);
	HANDLE hFile = CreateFile(File, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	for (int i = 0; i < 24; i++)
	{
		for (int j = 0; j < 24; j++)
		{
			DWORD readB;
			POINT pt;
			pt.x = j;
			pt.y = i;
			ReadFile(hFile, &g_map[j][i], sizeof(int), &readB, NULL);
			if (g_map[j][i] == PLAYER_ICON)
			{
				g_map[j][i] = 0;
				player.pt.x = j;
				player.pt.y = i;
				player.starting_pt.x = BLOCK_WIDTH * j;
				player.starting_pt.y = BLOCK_HEIGHT * i;
				player.cur_pt.x = BLOCK_WIDTH * j;
				player.cur_pt.y = BLOCK_HEIGHT * i;
				player.Use = true;
			}
		}
	}
	CloseHandle(hFile);
}

Game::~Game()
{
	BitMap::GetInstance()->DeleteBitMap();
}