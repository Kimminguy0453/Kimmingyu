#include "Shape.h"

Shape* Shape::m_hThis = NULL;

void Shape::SetType(string Type)
{
	m_Type = Type;
}
void Shape::SetPoint(int x, int y)
{
	m_Point.x = x;
	m_Point.y = y;
}

void Shape::MoveShpae(int Direct)
{
	if (Direct == LEFT)
		m_Point.x--;
	else if (Direct == UP)
		m_Point.y--;
	else if (Direct == RIGHT)
		m_Point.x++;
	else if (Direct == DOWN)
		m_Point.y++;
}

void Shape::Draw(HDC hdc)
{
	if (m_Type == "��")
		Ellipse(hdc, m_Point.x - 50, m_Point.y - 50, m_Point.x + 50, m_Point.y + 50);
	else if (m_Type == "�簢��")
		Rectangle(hdc, m_Point.x - 50, m_Point.y - 50, m_Point.x + 50, m_Point.y + 50);
}

void Shape::DeleteShape()
{
	delete m_hThis;
	m_hThis = NULL;
}
