#pragma once
#include <iostream>
#include<Windows.h>
#include<string>
using namespace std;

struct Point
{
	int x;
	int y;
};

enum Direction
{
	LEFT,
	UP,
	RIGHT,
	DOWN
};

class Shape
{
private:
	string m_Type;
	Point m_Point;
	static Shape* m_hThis;
public:
	void SetPoint(int x, int y);
	void SetType(string Type = "��");
	void MoveShpae(int Direct);
	void Draw(HDC hdc);
	void DeleteShape();
	void ChangeType()
	{
		if (m_Type == "��")
			m_Type = "�簢��";
		else
			m_Type = "��";
	}
	static Shape* GetInstance()
	{
		if (m_hThis == NULL)
			m_hThis = new Shape;
		return m_hThis;
	}
};

