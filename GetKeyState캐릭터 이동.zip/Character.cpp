#include "Character.h"

Character* Character::m_hThis = NULL;
void Character::SetCharacter()
{
	m_ix = 450;
	m_iy = 300;
	m_Motion.Motion = 0;
	m_Motion.Direction = DOWN;
	m_MoveOn = false;
	JumpCount = 0;
	m_bJump = false;
}

void Character::MoveSetCharacter()
{
	bool Longjump = false;
	if (!m_bJump)
	{
		if (GetKeyState(VK_UP) & 0x8000)
		{
			m_Motion.Direction = UP;
			MoveMotion();
			m_iy -= 10;
			Longjump = true;
		}
		if (GetKeyState(VK_DOWN) & 0x8000)
		{
			m_Motion.Direction = DOWN;
			MoveMotion();
			m_iy += 10;
			Longjump = true;
		}
		if (GetKeyState(VK_LEFT) & 0x8000)
		{
			m_Motion.Direction = LEFT;
			MoveMotion();
			m_ix -= 10;
			Longjump = true;
		}
		if (GetKeyState(VK_RIGHT) & 0x8000)
		{
			m_Motion.Direction = RIGHT;
			MoveMotion();
			m_ix += 10;
			Longjump = true;
		}
		if (GetKeyState(VK_SPACE) & 0x8000)
		{
			m_bJump = true;
			if (Longjump)
				m_Move.Jump = 6;
			else
				m_Move.Jump = 3;
		}
	}
	else
		CharacterJump();
}

void Character::MoveMotion()
{
	m_Motion.Motion++;
	if (m_Motion.Motion > 3)
		m_Motion.Motion = 0;
}

void Character::CharacterJump()
{
	JumpCount++;
	if (m_Motion.Direction == DOWN || m_Motion.Direction == UP)
	{
		if(m_Motion.Direction == DOWN)
			m_iy += m_Move.Jump;
		else 
			m_iy -= m_Move.Jump;
		if (JumpCount <= 7)
			m_ix += m_Move.Jump;
		else if (JumpCount >= 14)
			m_ix -= m_Move.Jump;;
	}
	else if ((m_Motion.Direction == LEFT || m_Motion.Direction == RIGHT))
	{
		if(m_Motion.Direction == RIGHT)
			m_ix += m_Move.Jump;
		else
			m_ix -= m_Move.Jump;
		if (JumpCount <= 7)
			m_iy -= m_Move.Jump;
		if (JumpCount >= 14)
			m_iy += m_Move.Jump;
	}
	if (JumpCount == 20)
	{
		JumpCount = 0;
		m_bJump = false;
	}
}

void Character::CharacterDraw(HDC hdc)
{
	Bt_Image = new BitMap;
	Bt_Image->InitImage(hdc);
	Bt_Image->DrawImage(hdc, m_ix, m_iy, m_Motion.Motion, m_Motion.Direction);
}

void Character::ReleaseImage()
{
	delete Bt_Image;
	Bt_Image = NULL;
}