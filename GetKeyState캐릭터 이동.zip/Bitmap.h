#pragma once
#include <Windows.h>
class BitMap
{
private:
	HDC MemDC;
	HBITMAP m_pImage;
	HBITMAP m_pOld;
	int bx, by;
public:
	BitMap();
	void InitImage(HDC hdc);
	void DrawImage(HDC hdc, int x, int y, int Motion, int Direction);
	~BitMap();
};

