#pragma once
#include "BitMap.h"

enum DIRECTION
{
	DOWN,
	UP,
	LEFT,
	RIGHT,
	STOP
};

struct CharacterMotion
{
	int Motion;
	int Direction;//��������
};

struct Move
{
	int Run_x;
	int Run_y;
	int Jump;
};

class Character
{
private:
	int m_ix;
	int m_iy;
	bool m_bJump;
	bool m_MoveOn;
	int JumpCount;
	Move m_Move;
	CharacterMotion m_Motion;
	BitMap* Bt_Image;
	static Character* m_hThis;
public:
	void SetCharacter();
	static Character* GetInstance()
	{
		if (m_hThis == NULL)
			m_hThis = new Character;
		return m_hThis;
	}
	void MoveMotion();
	void MoveSetCharacter();
	void CharacterJump();
	void CharacterDraw(HDC hdc);
	void ReleaseImage();
};

