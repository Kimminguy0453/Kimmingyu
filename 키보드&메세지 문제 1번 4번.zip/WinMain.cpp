#include <iomanip>
#include "Shape.h"
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;//�۷ι� �ν��Ͻ��ڵ鰪
LPCTSTR lpszClass = TEXT("HelloWorld");

struct Circle
{
	int x;
	int y;
	int Radius;
};

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPervlnstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);
	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL,
		(HMENU)NULL, hInstance, NULL);
	//���� ȭ���� (100, 100)��ġ�� �� 640, ���� 480�� ũ��
	ShowWindow(hWnd, nCmdShow);
	//���� ���� ����
	Shape::GetInstance()->SetShape(100, 100,"��");
	//
	while (GetMessage(&Message, NULL, 0, 0))
	{
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}
LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	RECT rt = { 100, 0, 200, 200 };
	PAINTSTRUCT ps;
	HDC hdc;
	switch (iMessage)
	{
	case WM_DESTROY:
		PostQuitMessage(0);
		Shape::GetInstance()->DeleteShape();
		return 0;
	case WM_KEYDOWN:
		switch (wParam)
		{
		case VK_LEFT:
			Shape::GetInstance()->MoveShpae(LEFT);
			break;
		case VK_RIGHT:
			Shape::GetInstance()->MoveShpae(RIGHT);
			break;
		case VK_UP:
			Shape::GetInstance()->MoveShpae(UP);
			break;
		case VK_DOWN:
			Shape::GetInstance()->MoveShpae(DOWN);
			break;
		case VK_SPACE:
			if (MessageBox(hWnd, TEXT("���� ����"), TEXT("MessageBox"), MB_YESNO) == IDYES)
				Shape::GetInstance()->ChangeType();
		}
		InvalidateRect(hWnd, NULL, TRUE);
		return 0;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		Shape::GetInstance()->Draw(hdc);
		EndPaint(hWnd, &ps);
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}