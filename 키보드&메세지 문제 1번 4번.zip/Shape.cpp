#include "Shape.h"

Shape* Shape::m_hThis = NULL;

void Shape::SetShape(int x, int y, string Type)
{
	m_Point.x = x;
	m_Point.y = y;
	m_Type = Type;
}

void Shape::MoveShpae(int Direct)
{
	if (Direct == LEFT)
		m_Point.x--;
	else if (Direct == UP)
		m_Point.y--;
	else if (Direct == RIGHT)
		m_Point.x++;
	else if (Direct == DOWN)
		m_Point.y++;
}

void Shape::Draw(HDC hdc)
{
	if (m_Type == "��")
		Ellipse(hdc, m_Point.x, m_Point.y, m_Point.x + 100, m_Point.y +100);
	else if (m_Type == "�簢��")
		Rectangle(hdc, m_Point.x, m_Point.y, m_Point.x +100, m_Point.y +100);
}

void Shape::DeleteShape()
{
	delete m_hThis;
	m_hThis = NULL;
}

