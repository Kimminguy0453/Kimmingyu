#include "CardManager.h"

CardManager* CardManager::m_hThis = NULL;

void CardManager::MakeCard()
{
	int x; 
	int y;
	int Key;
	bool Check;

	while (1)
	{
		Check = false;
		Key = rand() % 20;
		x = 10 + (110 * (Key % 5));
		y = 10 + 110 * (Key / 5);
		for (auto iter = CardList.begin(); iter != CardList.end(); iter++)
		{
			if ((*iter).first == Key)
			{
				Check = true;
				break;
			}
		}
		if (!Check)
		{
			CardList.insert(pair<int, Card*>(Key, new Card(x, y , BitMap_ID)));
			if (CardList.size() % 2 == 0)
				BitMap_ID++;
		}
		if (CardList.size() == 20)
			break;
	}
}

int CardManager::GetCard(int x, int y)
{
	for (auto iter = CardList.begin(); iter != CardList.end(); iter++)
	{
		if ((*iter).second->CheckPoint(x, y))
		{
			if (!(*iter).second->GetCheck())
			{
				(*iter).second->CardCheck();
				return (*iter).first;
			}
		}
	}
	return NOT_CARD;
}

void CardManager::CheckCard(int key1, int key2)
{
	if (key1 != key2)
	{
		if (CardList.find(key1)->second->GetId() != CardList.find(key2)->second->GetId())
		{
			CardList.find(key1)->second->CardCheck();
			CardList.find(key2)->second->CardCheck();
		}
	}
}

bool CardManager::GameEnd()
{
	for (auto iter = CardList.begin(); iter != CardList.end(); iter++)
	{
		if (!(*iter).second->GetCheck())
			return false;
	}
	return true;
}

void CardManager::DeleteManager()
{
	for (auto iter = CardList.begin(); iter != CardList.end(); iter++)
		delete (*iter).second;
	CardList.clear();
	delete m_hThis;
	m_hThis = NULL;
}

void CardManager::DrawCard(HDC hdc, HINSTANCE hInst, int Key)
{
	CardList.find(Key)->second->InitCard(hdc, hInst);
	CardList.find(Key)->second->DrawCard(hdc);
	CardList.find(Key)->second->Release();
}
