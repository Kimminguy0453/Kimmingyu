#pragma once
#include<Windows.h>
#include "resource.h"
#define MAP_WIDHT 145
#define MAP_HEIGHT 235

struct MapSize
{
	int Width;
	int Height;
};

class BitMap
{
private:
	HDC MemDC;
	HBITMAP m_pBitMap;
	HBITMAP m_pOldMap;
	MapSize m_Size;
public:
	BitMap();
	void SetBitMap(HDC hdc, HINSTANCE hInst, int id);
	void DrawBitMap(HDC hdc, int x, int y);
	~BitMap();
};


