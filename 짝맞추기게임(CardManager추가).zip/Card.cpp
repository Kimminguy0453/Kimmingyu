#include "Card.h"

Card::Card(int x, int y, int Id)
{
	m_ix = x;
	m_iy =y;
	m_iId = Id;
	m_bCheck = false;
	Bt_map = NULL;
}

void Card::InitCard(HDC hdc, HINSTANCE hInst)
{
	Bt_map = new BitMap;

	if (m_bCheck)
		Bt_map->SetBitMap(hdc, hInst, m_iId);
	else
		Bt_map->SetBitMap(hdc, hInst, IDB_BITMAP11);
}

void Card::DrawCard(HDC hdc)
{
	Bt_map->DrawBitMap(hdc, m_ix, m_iy);
}

void Card::Release()
{
	delete Bt_map;
	Bt_map = NULL;
}

bool Card::CheckPoint(int x, int y)
{
	if ((x >= m_ix && x < m_ix + 100) && (y >= m_iy && y < m_iy + 100))
		return true;
	return false;
}

Card::~Card(){}