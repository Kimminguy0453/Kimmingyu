#pragma once
#include "Card.h"
#include <map>
#include <Time.h>
using namespace std;
#define NOT_CARD 21


class CardManager
{
private:
	static CardManager* m_hThis;

	int BitMap_ID;
	map<int, Card*> CardList;
public:
	void SetBitMap()
	{
		BitMap_ID = IDB_BITMAP1;
	}
	static CardManager* GetInstance()
	{
		if (m_hThis == NULL)
			m_hThis = new CardManager;
		return m_hThis;
	}
	void MakeCard();
	int GetCard(int x, int y);
	void CheckCard(int key1, int key2);
	bool GameEnd();
	void DeleteManager();
	void DrawCard(HDC hdc, HINSTANCE hInst, int Key);
};

