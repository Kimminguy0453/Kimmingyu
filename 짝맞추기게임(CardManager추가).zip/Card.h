#pragma once
#include "BitMap.h"

class Card
{
private:
	int m_ix;
	int m_iy;
	int m_iId;
	bool m_bCheck;
	BitMap* Bt_map;
public:
	Card(int x, int y, int Id);
	void DrawCard(HDC hdc);
	void InitCard(HDC hdc, HINSTANCE hInst);
	bool CheckPoint(int x, int y);
	void Release();
	void CardCheck()
	{
		if (m_bCheck)
			m_bCheck = false;
		else
			m_bCheck = true;
	}
	inline int GetId()
	{
		return m_iId;
	}
	inline bool GetCheck()
	{
		return m_bCheck;
	}
	~Card();
};

