#include<Windows.h>
#include "CardManager.h"

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
LPCTSTR lpszClass = TEXT("BitMap");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPervlnstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	srand(time(NULL));
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0))
	{
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

bool Game = true;
bool Check = false;
int Key1;
int Key2;
void DefaultSeting();
void KeyCheck(HWND hWnd, LPARAM lParam);
void CardCheck(HWND hWnd);

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch (iMessage)
	{
	case WM_CREATE:
		DefaultSeting();
		return 0;
	case WM_MOUSEMOVE:
		if (Game)
			CardCheck(hWnd);
		return 0;
	case WM_LBUTTONDOWN:
		if (Game)
			KeyCheck(hWnd, lParam);
		else
		{
			if (MessageBox(hWnd, TEXT("Game Clear"), TEXT("���� �����"), MB_YESNO) == IDYES)
			{
				DefaultSeting();
				Game = true;
				InvalidateRect(hWnd, NULL, TRUE);
			}
			else
				PostQuitMessage(0);
		}
		return 0;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		for (int i = 0; i < 20; i++)
			CardManager::GetInstance()->DrawCard(hdc, g_hInst, i);
		if (CardManager::GetInstance()->GameEnd())
		{
			CardManager::GetInstance()->DeleteManager();
			TextOut(hdc, 200, 450, TEXT("GAME CLEAR"), 10);
			Game = false;
			Key1 = NOT_CARD;
			Key2 = NOT_CARD;
		}
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		CardManager::GetInstance()->DeleteManager();
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}

void DefaultSeting()
{
	CardManager::GetInstance()->SetBitMap();
	CardManager::GetInstance()->MakeCard();
}

void KeyCheck(HWND hWnd, LPARAM lParam)
{
	if (!Check)
	{
		Key1 = CardManager::GetInstance()->GetCard(LOWORD(lParam), HIWORD(lParam));
		if (Key1 != NOT_CARD)
			Check = true;
	}
	else
	{
		Key2 = CardManager::GetInstance()->GetCard(LOWORD(lParam), HIWORD(lParam));
		if (Key2 != NOT_CARD)
			Check = false;
	}
	InvalidateRect(hWnd, NULL, TRUE);
}

void CardCheck(HWND hWnd)
{
	if (Key1 != NOT_CARD && Key2 != NOT_CARD)
	{
		CardManager::GetInstance()->CheckCard(Key1, Key2);
		Key1 = NOT_CARD;
		Key2 = NOT_CARD;
		InvalidateRect(hWnd, NULL, TRUE);
	}
}