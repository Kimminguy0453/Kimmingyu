#include "BitMap.h"
#include "resource.h"

BitMap::BitMap(){}

void BitMap::SetBitMap(HDC hdc, HINSTANCE hInst, int id)
{
	MemDC = CreateCompatibleDC(hdc);
	m_pBitMap = (HBITMAP)LoadBitmap(hInst, MAKEINTRESOURCE(id));
	m_pOldMap = (HBITMAP)SelectObject(MemDC, m_pBitMap);

	BITMAP MapData;
	GetObject(m_pBitMap, sizeof(MapData), &MapData);
	m_Size.Width = MapData.bmWidth;
	m_Size.Height = MapData.bmHeight;
}

void BitMap::DrawBitMap(HDC hdc, int x, int y)
{
	StretchBlt(hdc, x, y, 100, 100, MemDC, 0, 0, m_Size.Width, m_Size.Height, SRCCOPY);
}

BitMap::~BitMap()
{
	SelectObject(MemDC, m_pOldMap);
	DeleteObject(m_pBitMap);
	DeleteDC(MemDC);
}
