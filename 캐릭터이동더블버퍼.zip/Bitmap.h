#pragma once
#include <Windows.h>
#define MAINDRAW_DC 0
#define BACKGROUND_DC 1
#define CHARACTER_DC 2


class BitMap
{
private:
	RECT rt;
	HDC g_MemDC[3];
	HBITMAP g_hBitmap[3];
	HBITMAP g_hOld[3];
	int bx, by;
public:
	BitMap();
	void InitImage(HDC hdc);
	void BackGroundDraw();
	void CharacterDraw(int x, int y, int Motion, int Direction);
	void DrawImage(HDC hdc);
	~BitMap();
};

