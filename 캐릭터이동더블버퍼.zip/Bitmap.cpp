#include "Bitmap.h"

BitMap::BitMap()
{
	rt = { 0 , 0, 1024, 768 };
}

void BitMap::InitImage(HDC hdc)
{
	g_MemDC[MAINDRAW_DC] = CreateCompatibleDC(hdc);
	g_hBitmap[MAINDRAW_DC] = CreateCompatibleBitmap(hdc, 1024, 768);
	g_hOld[MAINDRAW_DC] = (HBITMAP)SelectObject(g_MemDC[MAINDRAW_DC], g_hBitmap[MAINDRAW_DC]);


	g_MemDC[BACKGROUND_DC] = CreateCompatibleDC(g_MemDC[MAINDRAW_DC]);
	g_hBitmap[BACKGROUND_DC] = (HBITMAP)LoadImage(NULL, TEXT("back.bmp"),
		IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
	g_hOld[BACKGROUND_DC] = (HBITMAP)SelectObject(g_MemDC[BACKGROUND_DC], g_hBitmap[BACKGROUND_DC]);

	g_MemDC[CHARACTER_DC] = CreateCompatibleDC(g_MemDC[MAINDRAW_DC]);
	g_hBitmap[CHARACTER_DC] = (HBITMAP)LoadImage(NULL, TEXT("image.bmp"),
		IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
	g_hOld[CHARACTER_DC] = (HBITMAP)SelectObject(g_MemDC[CHARACTER_DC], g_hBitmap[CHARACTER_DC]);
	BITMAP btSize;
	GetObject(g_hBitmap[CHARACTER_DC], sizeof(btSize), &btSize);
	bx = btSize.bmWidth;
	by = btSize.bmHeight;

}

void BitMap::BackGroundDraw()
{
	BitBlt(g_MemDC[MAINDRAW_DC], 0, 0, 1024, 768, g_MemDC[BACKGROUND_DC], 0, 0, RGB(255, 0, 255));
}

void BitMap::CharacterDraw(int x, int y, int Motion, int Direction)
{
	TransparentBlt(g_MemDC[MAINDRAW_DC], x, y, bx / 4, by / 4, g_MemDC[CHARACTER_DC], (bx / 4) * Motion, (by / 4) * Direction, bx / 4, by / 4, RGB(255, 0, 255));
}

void BitMap::DrawImage(HDC hdc)
{
	BitBlt(hdc, 0, 0, 1024, 768, g_MemDC[MAINDRAW_DC], 0, 0, SRCCOPY);
}


BitMap::~BitMap()
{
	for (int i = 0; i < 3; i++)
	{
		SelectObject(g_MemDC[i], g_hOld[i]);
		DeleteObject(g_hBitmap[i]);
		DeleteDC(g_MemDC[i]);
	}
}
