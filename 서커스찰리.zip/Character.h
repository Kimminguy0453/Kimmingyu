#pragma once
#include "Object.h"
#define JUMPRANHGE 200

enum MOTION_TYPE
{
	STOP,
	RUN,
	JUMP,
	WIN1,
	WIN2,
	LOSE
};

enum GAME_STATE
{
	GAME_PROGRESS,
	GAME_CLEAR,
	GAME_OVER
};

struct PassObstacle
{
	int PassFront;
	int PassEnemy;
};

class Character
{
private:
	ImageData CharacterData;
	int m_iLife = 0;
	int MoveRange;
	bool Move;
	bool MoveJump;
	POINT JumpPoint;
	bool JumpCheck;
	int JumpAngle;
	int Motion;
	int Score;
	int Remainder;
	PassObstacle Pass;
public:
	void SetCharacter(bool Reset = false);
	void InitCharacter();
	void InitLife();
	void CheckFinalField();
	void MoveCharacter(double Delta);
	void Move_Calculate(double Range);
	void MotionUpdate(int GaemState = GAME_PROGRESS);
	bool CharacterJump(double Delta);
	bool DeathCheck();
	void ScoreUpDate();
	void JumpRangeSet();
	inline bool GetJump()
	{
		return JumpCheck;
	}
	inline int GetMoveRange()
	{
		return MoveRange;
	}
	inline int GetLife()
	{
		return m_iLife;
	}
	inline int GetScore()
	{
		return Score;
	}
};

