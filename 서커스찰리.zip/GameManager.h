#pragma once
#include "Character.h"
#include "GameField.h"
#include <math.h>

struct FlagManager
{
	bool GameFlag;
	bool WinFlag;
	bool DeathFlag;
	bool JumpFlag;
	bool UseStartFrame;
	bool UseFrameCount;
};

class GameManager
{
private:
	Character* Player;
	GameField* Back;
	LARGE_INTEGER Start, End, Frequency;
	FlagManager Flag;
	double Delta;
	double EndCount;
	static GameManager* m_hThis;
public:
	static GameManager* GetGame()
	{
		if (m_hThis == NULL)
			m_hThis = new GameManager;
		return m_hThis;
	}
	void Default();
	void SetFrame();
	void Flag_Default_Set();
	void UpDate(HWND hWnd);
	void DrawGmae(HDC hdc);
	void ReSetGame(bool Reset = false);
	void DeathProcess();
	inline int GetGameFlag()
	{
		return Flag.GameFlag;
	}
	void GameEnd();
};

