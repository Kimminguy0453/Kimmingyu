#include "GameField.h"

void GameField::SetGameField()
{
	for (int i = FIELD; i <= MITER; i++)
		BitMap::GetInstance()->InitImage(Object::GetInstance()->SearchObjectID(i), i);	
}

void GameField::SetFieldData()
{
	int Count = 0;
	int Audience_x = 0;
	int Field_x = 0;
	int Enemy_x = 0;
	int Front_Count = 1;
	ImageData tmp;

	Object::GetInstance()->SetObject(FINAL, Object::GetInstance()->MakeImageData(FINAL, FINAL_START_X, FINAL_START_Y));
	while (1)
	{
		for (int i = 0; i < 14; i++)
		{
			Audience_Data.push_back(Object::GetInstance()->MakeImageData(AUDIENCE, Audience_x, AUDIENCE_START));
			Audience_x += AUDIENCE_WIDTH;
			Field_Data.push_back(Object::GetInstance()->MakeImageData(FIELD, Field_x, FILED_START));
			Field_x += FIELD_WIDTH;
			if (Count == 0 && i == 3)
				break;
			if (Count == 11 && i == 4)
				break;
		}
		Count++;
		if (Count == 11)
			break;
		Deco_Data.push_back(Object::GetInstance()->MakeImageData(DECO, Audience_x, DECO_START));
		Audience_x += DECO_WIDTH;
	}

	for (int i = 1; i <= 11; i++)
		Object::GetInstance()->SetObject(FRONT, Object::GetInstance()->MakeImageData(FRONT, i * ((FINAL_START_X - FRONT_WIDTH) / 10), FRONT_START, i + 1));

	for (int i = 0; i <= 10; i++)
		Miter_Data.push_back(Object::GetInstance()->MakeImageData(MITER, (MAX_MAP / 10) * i, MITER_START, 100 - (10 * i)));
}

void GameField::DrawGameField()
{
	for (auto iter = Audience_Data.begin(); iter != Audience_Data.end(); iter++)
		BitMap::GetInstance()->DrawScreen(AUDIENCE, (*iter).pt.x, (*iter).pt.y, (*iter).Width, (*iter).Height);

	for (auto iter = Deco_Data.begin(); iter != Deco_Data.end(); iter++)
		BitMap::GetInstance()->DrawScreen(DECO, (*iter).pt.x, (*iter).pt.y,(*iter).Width, (*iter).Height);

	for (auto iter = Field_Data.begin(); iter != Field_Data.end(); iter++)
		BitMap::GetInstance()->DrawScreen(FIELD, (*iter).pt.x, (*iter).pt.y, (*iter).Width, (*iter).Height);

	for (auto iter = Miter_Data.begin(); iter != Miter_Data.end(); iter++)
	{
		BitMap::GetInstance()->DrawScreen(MITER, (*iter).pt.x, (*iter).pt.y, (*iter).Width, (*iter).Height);
		BitMap::GetInstance()->MiterDraw((*iter).pt.x, (*iter).pt.y, (*iter).Width, (*iter).Height, (*iter).Number);
	}
	Object::GetInstance()->DrawObject();
}

void GameField::ReleaseField()
{
	Audience_Data.clear();
	Deco_Data.clear();
	Field_Data.clear();
}