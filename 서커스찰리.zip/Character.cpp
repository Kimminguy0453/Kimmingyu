#include "Character.h"

void Character::SetCharacter(bool Reset)
{
	if(Reset)
		m_iLife = 4;
	CharacterData.pt.x = 60;
	CharacterData.pt.y = 445;
	CharacterData.Width = 66;
	CharacterData.Height = 126;
	MoveRange = 0;
	Score = 0;
	JumpCheck = false;
	JumpAngle = -180;
	Move = false;
	Motion = 0;
	Pass.PassEnemy = 0;
	Pass.PassFront = 0;
	MoveJump = false;
}

void Character::InitCharacter()
{
	if (Motion == STOP)
		BitMap::GetInstance()->InitImage(TEXT("Circus\\player0.bmp"), CHARACTER);
	else if (Motion == RUN)
		BitMap::GetInstance()->InitImage(TEXT("Circus\\player1.bmp"), CHARACTER);
	else if (Motion == JUMP)
		BitMap::GetInstance()->InitImage(TEXT("Circus\\player2.bmp"), CHARACTER);
	else if (Motion == WIN1)
		BitMap::GetInstance()->InitImage(TEXT("Circus\\win.bmp"), CHARACTER);
	else if (Motion == WIN2)
		BitMap::GetInstance()->InitImage(TEXT("Circus\\win2.bmp"), CHARACTER);
	else if (Motion == LOSE)
		BitMap::GetInstance()->InitImage(TEXT("Circus\\die.bmp"), CHARACTER);

	BitMap::GetInstance()->DrawScreen(CHARACTER, CharacterData.pt.x + MoveRange, CharacterData.pt.y, CharacterData.Width, CharacterData.Height);
}

void  Character::InitLife()
{
	BitMap::GetInstance()->InitImage(TEXT("Circus\\icon.bmp"), LIFE);
}

void Character::MoveCharacter(double Delta)
{
	double Range;
	if(GetKeyState(VK_RIGHT) & 0x8000)
	{		
		Range = 200 * Delta;		
		Move_Calculate(Range);
		MotionUpdate();
	}
	else if (GetKeyState(VK_LEFT) & 0x8000)
	{
		Range = -200 * Delta;
		Move_Calculate(Range);
		MotionUpdate();
	}
	if (GetKeyState(VK_SPACE) & 0x8000)
	{
		JumpCheck = true;
		JumpRangeSet();
		JumpPoint.y = CharacterData.pt.y;
		MotionUpdate();
	}
}

void Character::JumpRangeSet()
{
	if (!Move)
		JumpPoint.x = MoveRange + 120;
	else
		JumpPoint.x = CharacterData.pt.x + 120;
}

void Character::Move_Calculate(double Range)
{
	if (!Move)
		MoveRange += Range;
	else
		CharacterData.pt.x += Range;

	CheckFinalField();
	if (MoveRange < 0)
		MoveRange = 0;
	if (CharacterData.pt.x < 60)
	{
		Move = false;
		CharacterData.pt.x = 60;
	}		
}

void Character::CheckFinalField()
{
	if (MoveRange > MAX_MAP - 1024)
	{
		if (JumpCheck)
		{
			Remainder = MoveRange - (MAX_MAP - 1024);
			MoveJump = true;
		}
    	MoveRange = MAX_MAP - 1024;
		Move = true;
	}
}

void Character::MotionUpdate(int GameState)
{
	if (GameState == GAME_CLEAR)
	{
		if (Motion != WIN1)
			Motion = WIN1;
		else
			Motion = WIN2;
		return;
	}
	if (GameState == GAME_OVER)
	{
		Motion = LOSE;
		return;
	}
	if (JumpCheck)
	{
		if (Motion != JUMP)
			Motion = JUMP;
	}
	else
	{
		if (Motion == STOP)
			Motion = RUN;
		else if (Motion == RUN || Motion == JUMP)
			Motion = STOP;
	}
}

bool Character::CharacterJump(double Delta)
{
	JumpAngle += 180*Delta;
	int y;
	if (JumpAngle >= 0)
	{
		JumpAngle = 0;
		JumpCheck = false;
	}

	if (!Move)
		MoveRange = cos(JumpAngle * 3.14 / 180) * 120 + JumpPoint.x;
	else if (MoveJump)
	{
		Remainder = cos(JumpAngle * 3.14 / 180) * 120 + JumpPoint.x - MoveRange;
		CharacterData.pt.x = Remainder;
	}
	else
		CharacterData.pt.x = cos(JumpAngle * 3.14 / 180) * 120 + JumpPoint.x;

	CharacterData.pt.y = sin(JumpAngle * 3.14 / 180) * 140 + JumpPoint.y;

	CheckFinalField();
	if (JumpAngle == 0)
	{
		if (MoveJump)
			MoveJump = false;
		ScoreUpDate();
		JumpAngle = -180;
		MotionUpdate();
	}
	if (Object::GetInstance()->FinalCheck(Object::GetInstance()->MakeRect(CharacterData.pt.x + MoveRange + CharacterData.Width / 3, CharacterData.pt.y, (CharacterData.Width / 3) * 2, CharacterData.Height)))
	{
		CharacterData.pt.y = (FINAL_START_Y + 10) - CharacterData.Height;
		JumpCheck = false;
		return true;
	}
	return false;
}

void Character::ScoreUpDate()
{
	Pass.PassFront += Object::GetInstance()->CheckPass(CharacterData.pt, MoveRange, Pass.PassFront, FRONT);
	Pass.PassEnemy += Object::GetInstance()->CheckPass(CharacterData.pt, MoveRange, Pass.PassEnemy, ENEMY);
	Score = (Pass.PassFront * 300) + (Pass.PassEnemy * 100);
	if (Score > 99999)
		Score = 99999;
}

bool Character::DeathCheck()
{
	if (Object::GetInstance()->CheckImpulse(Object::GetInstance()->MakeRect(CharacterData.pt.x + MoveRange + 10, CharacterData.pt.y, CharacterData.Width -10, CharacterData.Height)))
	{
		m_iLife--;
		return true;
	}
	return false;
}