#include "GameManager.h"

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
LPCTSTR lpszClass = TEXT("Circus Charlie");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	bool Gaming;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;

	RegisterClass(&WndClass);
	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 1024, 768,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);
	GameManager::GetGame()->Default();
	Gaming = GameManager::GetGame()->GetGameFlag();

	while (GetMessage(&Message, NULL, 0, 0))
	{
		if(PeekMessage(&Message, NULL, 0, 0, PM_REMOVE))
		{
			if (!Gaming)
			{
				TranslateMessage(&Message);
				DispatchMessage(&Message);
				if (MessageBox(hWnd, TEXT("���� �����Ͻðڽ��ϱ�?"), TEXT("���� ����"), MB_YESNO) == IDYES)
				{
					GameManager::GetGame()->GameEnd();
					PostQuitMessage(0);
				}
				else
					Gaming = true;
				if (Message.message == WM_QUIT)
					break;
			}
		}
		if (Gaming)
		{
			if(GameManager::GetGame()->GetGameFlag())
				GameManager::GetGame()->UpDate(hWnd);
			if (!GameManager::GetGame()->GetGameFlag())
			{
				if (MessageBox(hWnd, TEXT("���� �����"), TEXT("���� �ٽ��ϱ�"), MB_YESNO) == IDYES)
				{
					GameManager::GetGame()->Flag_Default_Set();
					GameManager::GetGame()->ReSetGame(true);
				}
				else
					Gaming = false;
			}
		}
	}
	return (int)Message.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	switch (iMessage)
	{
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
