#include "Object.h"

Object* Object::m_hThis = NULL;
LPCTSTR Object::SearchObjectID(int Type)
{
	if (Type == FIELD)
		return TEXT("Circus\\back.bmp");
	else if (Type == DECO)
		return TEXT("Circus\\back_deco.bmp");
	else if (Type == AUDIENCE)
		return TEXT("Circus\\back_normal.bmp");
	else if (Type == FINAL)
		return TEXT("Circus\\end.bmp");
	else if (Type == FRONT)
	{
		if (Front_Type)
		{
			Front_Type = false;
			return TEXT("Circus\\front.bmp");
		}
		else
		{
			Front_Type = true;
			return TEXT("Circus\\front2.bmp");
		}
	}
	else if (Type == ENEMY)
		return TEXT("Circus\\enemy.bmp");
	else if(Type == MITER)
		return TEXT("Circus\\miter.bmp");
}

ImageData Object::MakeImageData(int Type, int x, int y, int Number)
{
	ImageData tmp;

	tmp.pt.x = x;
	tmp.pt.y = y;
	tmp.Type = Type;
	tmp.Number = Number;
	if (Type == FIELD)
	{
		tmp.Width = FIELD_WIDTH;
		tmp.Height = FIELD_HEIGHT;
	}
	else if (Type == AUDIENCE)
	{
		tmp.Width = AUDIENCE_WIDTH;
		tmp.Height = AUDIENCE_HEIGHT;
	}
	else if (Type == DECO)
	{
		tmp.Width = DECO_WIDTH;
		tmp.Height = DECO_HEIGHT;
	}
	else if (Type == FINAL)
	{
		tmp.Width = FINAL_WIDTH;
		tmp.Height = FINAL_HEIGHT;
	}
	else if (Type == FRONT)
	{
		tmp.Width = FRONT_WIDTH;
		tmp.Height = FRONT_HEIGHT;
	}
	else if (Type == ENEMY)
	{
		tmp.Width = ENEMY_WIDTH;
		tmp.Height = ENEMY_HEIGHT;
	}
	else if (Type == MITER)
	{
		tmp.Width = MITER_WIDTH;
		tmp.Height = MITER_HEIGHT;
	}
	return tmp;
}

void Object::SetObject(int Type, ImageData Data)
{
	if (Type == FRONT)
		Front_Data.push_back(Data);
	else if (Type == FINAL)
		Final = Data;
}

void Object::SetEnemy()
{
	int Enemy_x = 0;
	for (int i = 0; i < 10; i++)
	{
		Enemy_x += (MAX_MAP / ENEMY_MAX) * 2;
		Eenmy_Data.push_back(MakeImageData(ENEMY, Enemy_x, ENEMY_START, i+1));
	}
}

void Object::DrawObject()
{
	for (auto iter = Front_Data.begin(); iter != Front_Data.end(); iter++)
		BitMap::GetInstance()->DrawScreen(FRONT, (*iter).pt.x, (*iter).pt.y, (*iter).Width, (*iter).Height);

	BitMap::GetInstance()->DrawScreen(FINAL, Final.pt.x, Final.pt.y, Final.Width, Final.Height);

	for (auto iter = Eenmy_Data.begin(); iter != Eenmy_Data.end(); iter++)
		BitMap::GetInstance()->DrawScreen((*iter).Type, (*iter).pt.x, (*iter).pt.y, (*iter).Width, (*iter).Height);
}


void Object::MoveEnemy(double Delta)
{
	for (auto iter = Eenmy_Data.begin(); iter != Eenmy_Data.end(); iter++)
	{
		(*iter).pt.x -= 150 * Delta;
		if ((*iter).pt.x + (*iter).Width < 0)
		{
			(*iter).pt.x = MAX_MAP;
			(*iter).Number += 10;
		}
	}
}

bool Object::FinalCheck(RECT Player_rt)
{
	RECT RcTemp;
	if (IntersectRect(&RcTemp, &Player_rt, &MakeRect(Final.pt.x, Final.pt.y - 10, Final.Width, 10)))
		return true;
	return false;
}

bool Object::CheckImpulse(RECT Player_rt)
{
	RECT RcTemp;
	for (auto iter = Front_Data.begin(); iter != Front_Data.end(); iter++)
	{
		if(IntersectRect(&RcTemp, &Player_rt, &MakeRect((*iter).pt.x, (*iter).pt.y, (*iter).Width, (*iter).Height)))
			return true;
	}
	for (auto iter = Eenmy_Data.begin(); iter != Eenmy_Data.end(); iter++)
	{
		if (IntersectRect(&RcTemp, &Player_rt, &MakeRect((*iter).pt.x, (*iter).pt.y, 20, 20)))
			return true;
		if (IntersectRect(&RcTemp, &Player_rt, &MakeRect((*iter).pt.x + (*iter).Width - 20, (*iter).pt.y + (*iter).Height -20, 20, 20)))
			return true;
	}
	return false;
}

int Object::CheckPass(POINT pt, int Move, int pass, int Type)
{
	int Count = 0;
	if (Type == FRONT)
	{
		for (auto iter = Front_Data.begin(); iter != Front_Data.end(); iter++)
		{	
			if ((*iter).pt.x + (*iter).Width < pt.x + Move)
			{
				if (pass <(*iter).Number)
					Count++;
			}
		}
	}
	else if (Type == ENEMY)
	{
		for (auto iter = Eenmy_Data.begin(); iter != Eenmy_Data.end(); iter++)
		{
			if ((*iter).pt.x + (*iter).Width < pt.x + Move)
			{
				if (pass < (*iter).Number)
					Count++;
			}
		}
	}
	return Count;
}

RECT Object::MakeRect(int x, int y, int Width, int Height)
{
	RECT rt = { x, y , x + Width, y + Height };
	return rt;
}

void Object::ReleaseObject(bool GameEnd)
{
	if (GameEnd)
		Front_Data.clear();
	Eenmy_Data.clear();
}

void Object::DeleteObject()
{
	ReleaseObject(true);
	delete m_hThis;
}