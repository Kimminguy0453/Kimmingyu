#pragma once
#include <Windows.h>
#define MAX_MAP 9305
#define SCOREBOARD_WIDTH 1005
#define SCOREBOARD_HEIGHT 140
#define SCOREBOARD_LINE 5

#define LIFE_WIDTH 15
#define LIFE_HEIGHT 15

enum BITAMP_TYPE
{
	SCREEN,
	FIELD,
	DECO,
	AUDIENCE,
	FINAL,
	FRONT,
	ENEMY,
	MITER,
	CHARACTER,
	LIFE,
	OBJECT_MAX
};

class BitMap
{
private:
	HDC Mem_DC[OBJECT_MAX];
	HBITMAP Main_Bit[OBJECT_MAX];
	HBITMAP Old_Bit[OBJECT_MAX];
	static BitMap* m_hThis;
public:
	static BitMap* GetInstance()
	{
		if (m_hThis == NULL)
			m_hThis = new BitMap;
		return m_hThis;
	}
	void InitPaper(HDC hdc);
	void DrawPaper(HDC hdc, int Start);
	void InitImage(LPCTSTR ID, int Type);
	void DrawScreen(int Type, int x, int y, int Width, int Height);
	void DrawScreenCharacter(POINT pt, int Width, int Height, int Move);
	void DrawScoreBoard(int x);
	void MiterDraw(int x, int y, int Width, int Height, int Miter);
	void DrawScore(int x, int Score, int Life);
	void Release();
	void DeleteBitMap()
	{
		delete m_hThis;
		m_hThis = NULL;
	}
};

