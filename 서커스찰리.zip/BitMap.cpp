#include "BitMap.h"

BitMap* BitMap::m_hThis = NULL;
void BitMap::InitPaper(HDC hdc)
{
	Mem_DC[(int)SCREEN] = CreateCompatibleDC(hdc);
	Main_Bit[(int)SCREEN] = CreateCompatibleBitmap(hdc, MAX_MAP, 768);
	Old_Bit[(int)SCREEN] = (HBITMAP)SelectObject(Mem_DC[(int)SCREEN], Main_Bit[(int)SCREEN]);
}

void BitMap::DrawPaper(HDC hdc, int Start)
{
	TransparentBlt(hdc, 0, 0, 1024, 768, Mem_DC[(int)SCREEN], Start, 0, 1024, 768, RGB(255, 0, 255));
}

void BitMap::DrawScoreBoard(int x)
{
	HPEN MyPen, OldPen;
	HBRUSH MyBrush, OldBrush;

	MyPen = CreatePen(PS_SOLID, SCOREBOARD_LINE, RGB(255, 165, 0));//�һ���
	MyBrush = CreateSolidBrush(RGB(0, 0, 0));//�귯�� ����
	OldPen = (HPEN)SelectObject(Mem_DC[(int)SCREEN], MyPen);//�Һ��� �� dc�� �� ����� �־���.
	Rectangle(Mem_DC[(int)SCREEN], x, 0, x + 1005, 140);//�簢�� �׸��� 
	OldBrush = (HBRUSH)SelectObject(Mem_DC[(int)SCREEN], MyBrush);//�귯�� ���� �� dc�� �귯�� ����� �־���.
	DeleteObject(MyPen);//�һ���

	Rectangle(Mem_DC[(int)SCREEN], x + SCOREBOARD_LINE, SCOREBOARD_LINE, x + (SCOREBOARD_WIDTH - SCOREBOARD_LINE), (SCOREBOARD_HEIGHT - SCOREBOARD_LINE));//�Ʊ� �׸� �簢���� ���θ� ���ϴ� ������ ä����.
	SelectObject(Mem_DC[(int)SCREEN], Main_Bit[(int)SCREEN]);// DC�� ��Ʈ�� ����� �־���.
	DeleteObject(MyBrush);// �귯�� ����
}

void BitMap::DrawScore(int x, int Score, int Life)
{
	TCHAR strScore[128];

	SetTextColor(Mem_DC[(int)SCREEN], RGB(255, 255, 255));
	SetBkColor(Mem_DC[(int)SCREEN], RGB(0, 0, 0));

	TextOut(Mem_DC[(int)SCREEN], x + 10, 10, TEXT("STAGE1"), 6);

	wsprintf(strScore, TEXT("Max_Score : %d"), 99999);
	TextOut(Mem_DC[(int)SCREEN], x + 10, 30, strScore, lstrlen(strScore));

	wsprintf(strScore, TEXT("Score : %d"), Score);
	TextOut(Mem_DC[(int)SCREEN], x + 10, 50, strScore, lstrlen(strScore));

	TextOut(Mem_DC[(int)SCREEN], x + 10, 70, TEXT("PLAYER LIFE"), 11);
	for (int i = 0; i < Life; i++)
		DrawScreen(LIFE, (x + 10) + (LIFE_WIDTH*i), 90, LIFE_WIDTH, LIFE_HEIGHT);
}

void BitMap::InitImage(LPCTSTR ID, int Type)
{
	Mem_DC[Type] = CreateCompatibleDC(Mem_DC[(int)SCREEN]);
	Main_Bit[Type] = (HBITMAP)LoadImage(NULL, ID, IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE);
	Old_Bit[Type] = (HBITMAP)SelectObject(Mem_DC[Type], Main_Bit[Type]);
}

void BitMap::DrawScreen(int Type, int x, int y, int Width, int Height)
{
	BITMAP btSize;
	GetObject(Main_Bit[Type], sizeof(btSize), &btSize);
	TransparentBlt(Mem_DC[(int)SCREEN], x, y, Width, Height, Mem_DC[Type], 0, 0, btSize.bmWidth, btSize.bmHeight, RGB(255, 0, 255));
}

void BitMap::MiterDraw(int x, int y, int Width, int Height, int Miter)
{
	TCHAR strMiter[128];
 	RECT rt = {x , y + 12, x + Width, y + Height};
	wsprintf(strMiter, TEXT("%d"), Miter);

	SetTextColor(Mem_DC[(int)SCREEN], RGB(255, 255, 255));
	SetBkColor(Mem_DC[(int)SCREEN], RGB(0, 0, 0));
 	DrawText(Mem_DC[(int)SCREEN], strMiter, -1, &rt, DT_CENTER | DT_VCENTER);
}

void BitMap::DrawScreenCharacter(POINT pt, int Width, int Height, int Move)
{
	BITMAP btSize;
	GetObject(Main_Bit[(int)CHARACTER], sizeof(btSize), &btSize);
	TransparentBlt(Mem_DC[(int)SCREEN], pt.x + Move, pt.y, Width, Height, Mem_DC[(int)CHARACTER], 0, 0, btSize.bmWidth, btSize.bmHeight, RGB(255, 0, 255));
}


void BitMap::Release()
{
	for (int i = OBJECT_MAX - 1; i >= 0; i--)
	{
		SelectObject(Mem_DC[i], Old_Bit[i]);
		DeleteObject(Main_Bit[i]);
		DeleteDC(Mem_DC[i]);
	}
}