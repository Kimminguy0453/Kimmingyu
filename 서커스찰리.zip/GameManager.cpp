#include "GameManager.h"

GameManager* GameManager::m_hThis = NULL;
void GameManager::Default()
{
	Player = new Character;//�÷��̾� ����
	Player->SetCharacter(true);//�÷��̾� �⺻���� ����
	Back = new GameField;//�����ʵ� ����
	Back->SetFieldData();//�����ʵ峻�� ������Ʈ ��ǥ ����
	Object::GetInstance()->SetEnemy();
	EndCount = 0;
	Flag_Default_Set();
	QueryPerformanceFrequency(&Frequency);
}

void GameManager::Flag_Default_Set()
{
	Flag.DeathFlag = false;
	Flag.WinFlag = false;
	Flag.JumpFlag = false;
	Flag.GameFlag = true;
	Flag.UseStartFrame = false;
	Flag.UseFrameCount = false;
}

void GameManager::UpDate(HWND hWnd)
{
	HDC hdc;
	hdc = GetDC(hWnd);
	if (GetKeyState(VK_ESCAPE) & 0x8000)
		Flag.GameFlag = false;
	else
	{
		if (!Flag.UseFrameCount)
			SetFrame();
		else
		{
			if (Flag.DeathFlag || Flag.WinFlag)
			{
				EndCount += Delta;
				if (Flag.WinFlag)
					Player->MotionUpdate(GAME_CLEAR);
				if (1 < EndCount)
				{
					if (Flag.DeathFlag)
						DeathProcess();
					else
						Flag.GameFlag = false;
					EndCount = 0;
				}
			}
			else
			{
				Object::GetInstance()->MoveEnemy(Delta);
				Flag.JumpFlag = Player->GetJump();
				if (!Flag.JumpFlag)
					Player->MoveCharacter(Delta);
				else
				{
					if (Player->CharacterJump(Delta))
					{
						Player->MotionUpdate(GAME_CLEAR);
						Flag.WinFlag = true;
					}
				}
				if (Player->DeathCheck())
				{
					Player->MotionUpdate(GAME_OVER);
					Flag.DeathFlag = true;
				}
			}
		}
		DrawGmae(hdc);
		ReleaseDC(hWnd, hdc);
	}
}

void GameManager::DrawGmae(HDC hdc)
{
	BitMap::GetInstance()->InitPaper(hdc);//�׷��� ��ȭ��
	Back->SetGameField();//����̹����� ����
	Back->DrawGameField();//����̹����� �׷���
	Player->InitCharacter();
	Player->InitLife();
	BitMap::GetInstance()->DrawScoreBoard(Player->GetMoveRange());
	BitMap::GetInstance()->DrawScore(Player->GetMoveRange(), Player->GetScore(), Player->GetLife());
	BitMap::GetInstance()->DrawPaper(hdc, Player->GetMoveRange());
	BitMap::GetInstance()->Release();
}

void GameManager::SetFrame()
{
	if (!Flag.UseStartFrame)
	{
		QueryPerformanceCounter(&Start);
		Flag.UseStartFrame = true;
	}
	else
	{
		QueryPerformanceCounter(&End);
		Delta = (double)(End.QuadPart - Start.QuadPart) / (double)(Frequency.QuadPart);
		Flag.UseFrameCount = true;
	}
}

void GameManager::DeathProcess()
{
	if (Player->GetLife() != 0)
	{
		ReSetGame();
		Flag.DeathFlag = false;
		return;
	}
	else
		Flag.GameFlag = false;
}

void GameManager::ReSetGame(bool Reset)
{
	Object::GetInstance()->ReleaseObject();
	Player->SetCharacter(Reset);
	Object::GetInstance()->SetEnemy();
}

void GameManager::GameEnd()
{
	delete Player;
	Player = NULL;
	Back->ReleaseField();
	delete Back;
	Back = NULL;
	Object::GetInstance()->DeleteObject();
	BitMap::GetInstance()->DeleteBitMap();
	delete m_hThis;
	m_hThis = NULL;
}