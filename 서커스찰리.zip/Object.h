#pragma once
#include "BitMap.h"
#include <list>
#include <time.h>
using namespace std;
//�ʵ峻�� ������Ʈ�� ���ۿ� ���� ����

#define FIELD_WIDTH  67
#define FIELD_HEIGHT 549
#define AUDIENCE_WIDTH  65
#define AUDIENCE_HEIGHT 64
#define DECO_WIDTH 72
#define DECO_HEIGHT 68

#define FRONT_WIDTH 65
#define FRONT_HEIGHT 70
#define FINAL_WIDTH  154
#define FINAL_HEIGHT 122
#define ENEMY_WIDTH 48
#define ENEMY_HEIGHT 230
#define MITER_WIDTH 86
#define MITER_HEIGHT 40

#define ENEMY_MAX 20

enum OBJECT_START
{
	ENEMY_START = 250,
	FINAL_START_X = 9055,
	FINAL_START_Y = 461,
	FRONT_START = 504,
	FILED_START = 219,
	DECO_START = 153,
	AUDIENCE_START = 155,
	MITER_START = 590
};

struct ImageData
{
	POINT pt;
	int Width;
	int Height;
	int Type;
	int Number;
};

class Object
{
private:
	bool Front_Type = true;
	list <ImageData> Front_Data;
	list <ImageData> Eenmy_Data;
	ImageData Final;
	static Object* m_hThis;
public:
	static Object* GetInstance()
	{
		if (m_hThis == NULL)
			m_hThis = new Object;
		return m_hThis;
	}
	LPCTSTR SearchObjectID(int Type);
	ImageData MakeImageData(int Type, int x, int y, int Number = 0);
	void SetObject(int Type, ImageData Data);
	void SetEnemy();
	void DrawObject();
	void MoveEnemy(double Delta);
	bool CheckImpulse(RECT Player_rt);
	bool FinalCheck(RECT Player_rt);
	int CheckPass(POINT pt, int Move, int pass, int Type);
	void ReleaseObject(bool GameEnd = false);
	RECT MakeRect(int x, int y, int Width, int Height);
	void DeleteObject();
};

