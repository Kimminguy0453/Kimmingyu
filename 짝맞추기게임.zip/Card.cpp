#include "Card.h"

Card* Card::m_hThis = NULL;

void Card::SetDefault()
{
	m_Default_Id = IDB_BITMAP1;
	CardCount = 0;
}

void Card::SetCardData()
{
	int Key;
	bool Check;
	while (1)
	{
		Check = false;
		Key = rand() % 20;
		for (auto iter = m_CardData.begin(); iter != m_CardData.end(); iter++)
		{
			if ((*iter).first == Key)
			{
				Check = true;
				break;
			}
		}
		if (!Check)
		{
			m_CardData.insert(pair<int, CardData>(Key, SetCard(Key)));
		}
		if (m_CardData.size() == 20)
			break;
	}
}

CardData Card::SetCard(int Key)
{
	CardData tmp;
	int y = Key/ 5;

	tmp.x = 10 + (110 * (Key % 5));
	tmp.Id = m_Default.Id;
	tmp.y = 10 + 110 * (Key / 5);;
	tmp.Check = false;
	CardCount++;
	if (CardCount % 2 == 0)
		m_Default.Id++;

	return tmp;
}

void Card::InitCard(HDC hdc, HINSTANCE hInst, int Key)
{
	Bt_map = new BitMap;
	if (m_CardData.find(Key)->second.Check)
		Bt_map->SetBitMap(hdc, hInst, m_CardData.find(Key)->second.Id);
	else
		Bt_map->SetBitMap(hdc, hInst, IDB_BITMAP11);
}


int Card::GetCard(int x, int y)
{
	for (auto iter = m_CardData.begin(); iter != m_CardData.end(); iter++)
	{
		if ( x >= (*iter).second.x && x <= (*iter).second.x + 100 && y >= (*iter).second.y && y <= (*iter).second.y + 100)
		{
			if (!(*iter).second.Check)
			{
				(*iter).second.Check = true;
				return (*iter).first;
			}
		}
	}
	return NOT_CARD;
}

void Card::CheckCard(int key1, int key2)
{
	if (key1 != key2)
	{
		if (m_CardData.find(key1)->second.Id != m_CardData.find(key2)->second.Id)
		{
			m_CardData.find(key1)->second.Check = false;
			m_CardData.find(key2)->second.Check = false;
		}
	}
}

void Card::DrawCard(HDC hdc, int Key)
{
		Bt_map->DrawBitMap(hdc, m_CardData.find(Key)->second.x, m_CardData.find(Key)->second.y);
}

void Card::Release()
{
	delete Bt_map;
	Bt_map = NULL;
}

bool Card::GameEnd()
{
	for (auto iter = m_CardData.begin(); iter != m_CardData.end(); iter++)
	{
		if (!(*iter).second.Check)
			return false;
	}
	return true;
}

void Card::AllDelete()
{
	m_CardData.clear();
}
