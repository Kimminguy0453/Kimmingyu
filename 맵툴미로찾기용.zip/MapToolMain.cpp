#include <Windows.h>
#include <vector>
using namespace std;

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
LPCSTR szClassName = "��ũ����";

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = szClassName;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
	RegisterClass(&WndClass);

	int			nWidth, nHeight;//������ ũ�� 
	nWidth = 1024 + GetSystemMetrics(SM_CXFRAME) * 2;
	nHeight = 768 + GetSystemMetrics(SM_CYFRAME) * 2 +
		GetSystemMetrics(SM_CYCAPTION) + GetSystemMetrics(SM_CYMENU);

	hWnd = CreateWindow(szClassName, szClassName, WS_OVERLAPPEDWINDOW, 0, 0,
		nWidth, nHeight, NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0))
	{
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}

	return (int)Message.wParam;
}

#define WIDTH 33
#define HEIGHT 25

int g_map[24][24];
int cur_select = 0;
int Potal = 400;
int switchDoor = 500;

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch (iMessage)
	{
	case WM_CREATE:
		CreateWindow("button", "��ĭ", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | WS_GROUP, 800, 0 , 100, 30 , hWnd, (HMENU)0, g_hInst, NULL);
		CreateWindow("button", "ĳ����", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 800, 40, 100, 30, hWnd, (HMENU)1, g_hInst, NULL);
		CreateWindow("button", "�ⱸ", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 800, 80, 100, 30, hWnd, (HMENU)2, g_hInst, NULL);
		CreateWindow("button", "��", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 800, 120, 100, 30, hWnd, (HMENU)3, g_hInst, NULL);
		CreateWindow("button", "��Ż", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 800, 160, 100, 30, hWnd, (HMENU)4, g_hInst, NULL);
		CreateWindow("button", "����ġ��", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 800, 200, 100, 30, hWnd, (HMENU)5, g_hInst, NULL);
		CreateWindow("button", "�μ��º�", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 800, 240, 100, 30, hWnd, (HMENU)6, g_hInst, NULL);
		CreateWindow("button", "������", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 800, 280, 100, 30, hWnd, (HMENU)7, g_hInst, NULL);

		CreateWindow("button", "����Ż �����", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 910, 160, 100, 30, hWnd, (HMENU)8, g_hInst, NULL);
		CreateWindow("button", "����ư �����", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 910, 200, 100, 30, hWnd, (HMENU)9, g_hInst, NULL);
		CreateWindow("button", "Save", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 800, 600, 100, 30, hWnd, (HMENU)100, g_hInst, NULL);
		CreateWindow("button", "Load", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 800, 650, 100, 30, hWnd, (HMENU)101, g_hInst, NULL);
		CreateWindow("button", "LoadJson", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 800, 700, 100, 30, hWnd, (HMENU)102, g_hInst, NULL);

		memset(g_map, 0, sizeof(int) * 24 * 24);
		return 0;
	case WM_DESTROY:
		KillTimer(hWnd, 1);
		PostQuitMessage(0);
		return 0;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		for (int i = 0; i < 24; i++)
		{
			for (int j = 0; j < 24; j++)
			{
				if (g_map[i][j] == 0)
					Rectangle(hdc, j * WIDTH, i * HEIGHT, (j + 1) * WIDTH, (i + 1) * HEIGHT);
				else if(g_map[i][j] == 1)
					Ellipse(hdc, j * WIDTH, i * HEIGHT, (j + 1) * WIDTH, (i + 1) * HEIGHT);
				else if (g_map[i][j] == 2)
				{
					HBRUSH hBlack = (HBRUSH)GetStockObject(BLACK_BRUSH);
					HBRUSH old = (HBRUSH)SelectObject(hdc, hBlack);
					Ellipse(hdc, j * WIDTH, i * HEIGHT, (j + 1) * WIDTH, (i + 1) * HEIGHT);
					SelectObject(hdc, old);
				}
				else if (g_map[i][j] == 3)
				{
					HBRUSH hBlack = (HBRUSH)GetStockObject(BLACK_BRUSH);
					HBRUSH old = (HBRUSH)SelectObject(hdc, hBlack);
					Rectangle(hdc, j * WIDTH, i * HEIGHT, (j + 1) * WIDTH, (i + 1) * HEIGHT);
					SelectObject(hdc, old);
				}
				else if (g_map[i][j] >= 400 && g_map[i][j] < 500)
				{
					if (g_map[i][j] % 2 == 0)
					{
						HBRUSH hRed = (HBRUSH)CreateSolidBrush(RGB(255, 0, 0));
						HBRUSH old = (HBRUSH)SelectObject(hdc, hRed);
						Ellipse(hdc, j * WIDTH, i * HEIGHT, (j + 1) * WIDTH, (i + 1) * HEIGHT);
						SelectObject(hdc, old);
					}
					else
					{
						HBRUSH hBlue = (HBRUSH)CreateSolidBrush(RGB(0, 84, 255));
						HBRUSH old = (HBRUSH)SelectObject(hdc, hBlue);
						Ellipse(hdc, j * WIDTH, i * HEIGHT, (j + 1) * WIDTH, (i + 1) * HEIGHT);
						SelectObject(hdc, old);
					}
				}
				else if (g_map[i][j] >= 500 && g_map[i][j] < 600)
				{
					if (g_map[i][j] % 2 == 0)
					{
						HBRUSH hRed = (HBRUSH)CreateSolidBrush(RGB(255, 0, 0));
						HBRUSH old = (HBRUSH)SelectObject(hdc, hRed);
						Rectangle(hdc, j * WIDTH, i * HEIGHT, (j + 1) * WIDTH, (i + 1) * HEIGHT);
						SelectObject(hdc, old);
					}
					else
					{
						HBRUSH hBlue = (HBRUSH)CreateSolidBrush(RGB(0, 84, 255));
						HBRUSH old = (HBRUSH)SelectObject(hdc, hBlue);
						Rectangle(hdc, j * WIDTH, i * HEIGHT, (j + 1) * WIDTH, (i + 1) * HEIGHT);
						SelectObject(hdc, old);
					}
				}
				else if (g_map[i][j] == 6)
				{
					HBRUSH hYellow = (HBRUSH)CreateSolidBrush(RGB(255, 228, 0));
					HBRUSH old = (HBRUSH)SelectObject(hdc, hYellow);
					Rectangle(hdc, j * WIDTH, i * HEIGHT, (j + 1) * WIDTH, (i + 1) * HEIGHT);
					SelectObject(hdc, old);
				}
				else if (g_map[i][j] == 7)
				{
					HBRUSH hYellow = (HBRUSH)CreateSolidBrush(RGB(255, 228, 0));
					HBRUSH old = (HBRUSH)SelectObject(hdc, hYellow);
					Ellipse(hdc, j * WIDTH, i * HEIGHT, (j + 1) * WIDTH, (i + 1) * HEIGHT);
					SelectObject(hdc, old);
				}
			}
		}
		EndPaint(hWnd, &ps);
		return 0;
	case WM_COMMAND:
	{
		switch (LOWORD(wParam))
		{
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
			cur_select = LOWORD(wParam);
			break;
		case 8:
			Potal++;
			break;
		case 9:
			switchDoor++;
			break;
		case 100: //SAVE
			{
				OPENFILENAME OFN;
				char str[300];
				char lpstrFile[MAX_PATH] = "";
				char lpstrPath[MAX_PATH] = "";

				memset(&OFN, 0, sizeof(OPENFILENAME));
				OFN.lStructSize = sizeof(OPENFILENAME);
				OFN.hwndOwner = hWnd;
				OFN.lpstrFilter = "Every File(*.*)\0*.*\0Text File\0*.txt;*.doc\0";
				OFN.lpstrFile = lpstrFile;
				OFN.nMaxFile = 256;
				GetCurrentDirectory(MAX_PATH, lpstrPath);
				OFN.lpstrInitialDir = lpstrPath;
				if (GetSaveFileName(&OFN) == 0)
				{
					DWORD err = CommDlgExtendedError();
					break;	
				}

				HANDLE hFile = CreateFile(OFN.lpstrFile, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
				for (int i = 0; i < 24; i++)
				{
					for (int j = 0; j < 24; j++)
					{
						DWORD writeB;
						WriteFile(hFile, &g_map[i][j], sizeof(int), &writeB, NULL);
					}
				}
				CloseHandle(hFile);
				InvalidateRect(hWnd, NULL, false);
			}
			break;
		case 101://load
			{
				HANDLE hFile = CreateFile("Stage1", GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
				for (int i = 0; i < 24; i++)
				{
					for (int j = 0; j < 24; j++)
					{
						DWORD readB;
						ReadFile(hFile, &g_map[i][j], sizeof(int), &readB, NULL);
					}
				}
				CloseHandle(hFile);
				InvalidateRect(hWnd, NULL, false);
			}
			break;
		}
		return 0;
	}
	case WM_LBUTTONDOWN:
		{
			POINT pt;
			pt.x = LOWORD(lParam);
			pt.y = HIWORD(lParam);

			if ((pt.x < WIDTH * 24 && pt.x > 0) && (pt.y < HEIGHT * 24 && pt.y > 0))
			{
				if (g_map[pt.y / HEIGHT][pt.x / WIDTH] == switchDoor - 1)
				{
					int Door = g_map[pt.y / HEIGHT][pt.x / WIDTH] + 1;
					for (int i = 0; i < 24; i++)
					{
						for (int j = 0; j < 24; j++)
						{
							if (g_map[j][i] == Door)
								g_map[j][i] = 0;
						}
					}
				}
				else if ((g_map[pt.y / HEIGHT][pt.x / WIDTH] >= 400 && g_map[pt.y / HEIGHT][pt.x / WIDTH] < 500) && g_map[pt.y / HEIGHT][pt.x / WIDTH] % 2 ==0)
				{	
					int EntryPotal = g_map[pt.y / HEIGHT][pt.x / WIDTH] + 1;
					for (int i = 0; i < 24; i++)
					{
						for (int j = 0; j < 24; j++)
						{
							if (g_map[j][i] == EntryPotal)
								g_map[j][i] = 0;
						}
					}
				}
				if (cur_select == 4)
				{
					g_map[pt.y / HEIGHT][pt.x / WIDTH] = Potal;
					if (Potal % 2 == 0)
						Potal++;
				}
				else if (cur_select == 5)
				{
					g_map[pt.y / HEIGHT][pt.x / WIDTH] = switchDoor;
					if (switchDoor % 2 == 0)
						switchDoor++;
					
				}
				else
					g_map[pt.y / HEIGHT][pt.x / WIDTH] = cur_select;
				InvalidateRect(hWnd, NULL, false);
			}
		}
		return 0;
	case WM_RBUTTONDOWN:
		{
			POINT pt;
			pt.x = LOWORD(lParam);
			pt.y = HIWORD(lParam);
		}
		return 0;
	}

	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
