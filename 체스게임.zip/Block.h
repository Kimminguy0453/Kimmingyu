#pragma once
#include "BitMap.h"
#include "Move.h"
//������ ������ ������ �װ��� �׸��� ���� ��Ʈ���� ������ Ŭ���� 

enum PIECE
{
	NOT_PIECE,
	PAWN,
	ROOK,
	KNIGHT,
	BISHOP,
	QUEEN,
	KING
};

enum PlAYER
{
	BLACK,
	WHITE = 7,
};

class Move;
class Block
{
protected:
	BitMap* bt_Map;
	POINT m_Point;
	RECT m_Rt;
	LPCTSTR m_ID;
	int m_Type;
	Move* BlockMove;
public:
	Block();
	bool PointCheck(POINT pt);
	void InitBlock(HDC hdc, HINSTANCE hInst);
	void DrawBlock(HDC hdc);
	void Release();
	void SetPoint(int x, int y);
	void ChangeID(LPCTSTR ID)
	{
		m_ID = ID;
	}
	inline POINT GetPoint()
	{
		return m_Point;
	}
	inline RECT GetRect()
	{
		return m_Rt;
	}
	inline Move* GetMove()
	{
		return BlockMove;
	}
	inline int GetType()
	{
		return m_Type;
	}
	~Block();
};

class King : public Block
{
public:
	King(int Team);
	~King();
};

class Queen : public Block
{
public:
	Queen(int Team);
	~Queen();
};

class Knight : public Block
{
public:
	Knight(int Teamr);
	~Knight();
};

class Bishop : public Block
{
public:
	Bishop(int Team);
	~Bishop();
};

class Rook : public Block
{
public:
	Rook(int Team);
	~Rook();
};

class Pawn : public Block
{
public:
	Pawn(int Team);
	~Pawn();
};

