#pragma once
#include <Windows.h>
#define WIDTH 80
#define HEIGHT 80
//��Ʈ���� ����ϴ� Ŭ����

class BitMap
{
private:
	HDC MemDC;
	HBITMAP m_myBitMap;
	HBITMAP m_OldMap;
	POINT m_point;
public:
	void InitBitMap(HDC hdc, HINSTANCE hInst, LPCTSTR ID);
	void DrawBitMap(HDC hdc, int x, int y);
};

