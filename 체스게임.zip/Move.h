#pragma once
#include<list>
#include "Block.h"
//������ �����̴� ��ɰ� �� ���� ������ ������ �����ϴ� Ŭ����.
using namespace std;

class Block;
class Move
{
protected:
	list<POINT> PointList;
	int m_Count = 0;
public:
	RECT MakeRect(int x, int y);
	bool CheckRange(list<Block*>BlockList, int x, int y, bool Team = true);
	virtual void MoveRange(list<Block*> BlockTeam, list<Block*> BlockEnemy, int x, int y) = 0;
	virtual void MoveDirect(list<Block*> BlockTeam, list<Block*> BlockEnemy, int px, int py, int x, int y);
	POINT InputPoint(int x, int y);
	void DrawRect(HDC hdc, HINSTANCE hInst);
	bool PointListCheck(int x, int y);
	void DeleteMove()//������ ���� ������ ���� 
	{
		PointList.clear();
	}
	void CountUp()//������ Ƚ��
	{
		m_Count++;
	}
	inline int RangeSize()
	{
		return PointList.size();
	}
	inline 	list<POINT> GetPointList()
	{
		return PointList;
	}
	
};

class KingMove : public Move
{
private:
	list<POINT> UnMoveList;
public:
	void MoveRange(list<Block*> BlockTeam, list<Block*> BlockEnemy, int x, int y);
	bool UnMove(list<Block*> BlockEnemy, int x, int y);
};

class QueenMove : public Move
{
public:
	void MoveRange(list<Block*> BlockTeam, list<Block*> BlockEnemy, int x, int y);
};

class BishopMove : public Move
{
public:
	void MoveRange(list<Block*> BlockTeam, list<Block*> BlockEnemy, int x, int y);
};

class KnightMove : public Move
{
public:
	void MoveRange(list<Block*> BlockTeam, list<Block*> BlockEnemy, int x, int y);
	void MoveDirect(list<Block*> BlockTeam, list<Block*> BlockEnemy, int px, int py, int x, int y);
};

class RookMove : public Move
{
public:
	void MoveRange(list<Block*> BlockTeam, list<Block*> BlockEnemy, int x, int y);
};

class PawnMove : public Move
{
private:
	int m_iTeam;
public:
	PawnMove(int Team);
	void MoveRange(list<Block*> BlockTeam, list<Block*> BlockEnemy, int x, int y);
	void MoveDirect(list<Block*> BlockTeam, list<Block*> BlockEnemy, int px, int py, int x, int y);
	~PawnMove();
};

