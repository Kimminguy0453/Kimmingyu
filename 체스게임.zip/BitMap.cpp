#include "BitMap.h"

void BitMap::InitBitMap(HDC hdc, HINSTANCE hInst, LPCTSTR ID)
{
	MemDC = CreateCompatibleDC(hdc);
	m_myBitMap = (HBITMAP)LoadImage(NULL, ID, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
	m_OldMap = (HBITMAP)SelectObject(MemDC, m_myBitMap);
	BITMAP bt_size;
	GetObject(m_myBitMap, sizeof(bt_size), &bt_size);
	m_point.x = bt_size.bmWidth;
	m_point.y = bt_size.bmHeight;
}

void BitMap::DrawBitMap(HDC hdc, int x, int y)
{
	TransparentBlt(hdc, 10 + x * WIDTH, y * HEIGHT, WIDTH, HEIGHT, MemDC, 0, 0, m_point.x, m_point.y, RGB(255, 0, 255));
}