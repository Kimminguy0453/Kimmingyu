#include "Move.h"

RECT Move::MakeRect(int x, int y)//
{
	RECT rt;
	rt.left = x * WIDTH;
	rt.top = y * HEIGHT;
	rt.right = rt.left + WIDTH;
	rt.bottom = rt.top + HEIGHT;
	return rt;
}

void Move::DrawRect(HDC hdc, HINSTANCE hInst)//���� ������ �׷��� 
{
	BitMap* bt;
	bt = new BitMap;
	bt->InitBitMap(hdc, hInst, TEXT("Chess\\block01.bmp"));
	for (auto iter = PointList.begin(); iter != PointList.end(); iter++)
		bt->DrawBitMap(hdc, (*iter).x, (*iter).y);
	delete bt;
	bt = NULL;
}

bool Move::PointListCheck(int x, int y)//���ݹ������� ��ǥ�� Ŭ���ߴ��� Ȯ�� �ϴ� ���� + ���� ���� ���� �����ִ��� Ȯ��
{
	for (auto iter = PointList.begin(); iter != PointList.end(); iter++)
	{
		if (x == (*iter).x && y == (*iter).y)
			return true;
	}
	return false;
}

bool Move::CheckRange(list<Block*>BlockList, int x, int y, bool Team)//���� ������ �����Ҷ� ���� ���⿡ ���� �ִ��� üũ ���̸� �����ִ� ��ġ���� ���ݹ��� ����.
{
	RECT rt;
	for (auto iter = BlockList.begin(); iter != BlockList.end(); iter++)
	{
		if (IntersectRect(&rt, &(*iter)->GetRect(), &MakeRect(x, y)))
		{
			if (!Team)
				PointList.push_back(InputPoint(x, y));
			return false;
		}
	}
	return true;
}

POINT Move::InputPoint(int x, int y)//����Ʈ�� �� �����͸� ���� ��ȯ.
{
	POINT pt;
	pt.x = x;
	pt.y = y;
	return pt;
}

void Move::MoveDirect(list<Block*> BlockTeam, list<Block*> BlockEnemy, int px, int py, int x, int y)//�ش�������� Ȯ���� ���� ���� ���翩�θ� üũ �����Լ��� ����� ŷ, ����Ʈ�� �������� �ٸ��� ����.
{
	while (1)
	{
		if ((px + x >= 0 && px + x < 8) && (py + y >= 0 && py + y < 8))
		{
			px += x;
			py += y;
			if (CheckRange(BlockTeam, px, py) && CheckRange(BlockEnemy, px, py, false))
				PointList.push_back(InputPoint(px, py));
			else
				break;
		}
		else
			break;
	}
}

void KingMove::MoveRange(list<Block*> BlockTeam, list<Block*> BlockEnemy, int x, int y)
{
	for (int i = x - 1; i < x + 2; i++)
	{
		for (int j = y - 1; j < y + 2; j++)
		{
			if ((i >= 0 && i < 8) && (j >= 0 && j < 8))
			{
				if (CheckRange(BlockTeam, i, j) && CheckRange(BlockEnemy, i, j, false))
				{
					if(!UnMove(BlockEnemy, i, j))
						PointList.push_back(InputPoint(i, j));
				}
			}
		}
	}

}

bool KingMove::UnMove(list<Block*> BlockEnemy, int x, int y)
{
	for (auto iter = BlockEnemy.begin(); iter != BlockEnemy.end(); iter++)
	{
		if ((*iter)->GetMove()->PointListCheck(x, y))
			return true;
	}
	return false;
}


void QueenMove::MoveRange(list<Block*> BlockTeam, list<Block*> BlockEnemy, int x, int y)
{
	MoveDirect(BlockTeam, BlockEnemy, x, y, 1, 0);
	MoveDirect(BlockTeam, BlockEnemy, x, y, -1, 0);
	MoveDirect(BlockTeam, BlockEnemy, x, y, 0, 1);
	MoveDirect(BlockTeam, BlockEnemy, x, y, 0, -1);
	MoveDirect(BlockTeam, BlockEnemy, x, y, 1, 1);
	MoveDirect(BlockTeam, BlockEnemy, x, y, -1, -1);
	MoveDirect(BlockTeam, BlockEnemy, x, y, 1, -1);
	MoveDirect(BlockTeam, BlockEnemy, x, y, -1, 1);
}


void BishopMove::MoveRange(list<Block*> BlockTeam, list<Block*> BlockEnemy, int x, int y)
{
	MoveDirect(BlockTeam, BlockEnemy, x, y, 1, 1);
	MoveDirect(BlockTeam, BlockEnemy, x, y, -1, -1);
	MoveDirect(BlockTeam, BlockEnemy, x, y, 1, -1);
	MoveDirect(BlockTeam, BlockEnemy, x, y, -1, 1);
}

void KnightMove::MoveRange(list<Block*> BlockTeam, list<Block*> BlockEnemy, int x, int y)
{
	MoveDirect(BlockTeam, BlockEnemy, x, y, -1, -2);
	MoveDirect(BlockTeam, BlockEnemy, x, y, 1, -2);
	MoveDirect(BlockTeam, BlockEnemy, x, y, -1, 2);
	MoveDirect(BlockTeam, BlockEnemy, x, y, 1, 2);
	MoveDirect(BlockTeam, BlockEnemy, x, y, 2, -1);
	MoveDirect(BlockTeam, BlockEnemy, x, y, 2, 1);
	MoveDirect(BlockTeam, BlockEnemy, x, y, -2, -1);
	MoveDirect(BlockTeam, BlockEnemy, x, y, -2, 1);
}

void KnightMove::MoveDirect(list<Block*> BlockTeam, list<Block*> BlockEnemy, int px, int py, int x, int y)
{
	if ((px + x >= 0 && px + x < 8) && (py + y >= 0 && py + y < 8))
	{
		if (CheckRange(BlockTeam, px + x, py + y) && CheckRange(BlockEnemy, px + x, py + y, false))
			PointList.push_back(InputPoint(px + x, py + y));
	}
}

void RookMove::MoveRange(list<Block*> BlockTeam, list<Block*> BlockEnemy, int x, int y)
{
	MoveDirect(BlockTeam, BlockEnemy, x, y, 1, 0);
	MoveDirect(BlockTeam, BlockEnemy, x, y, -1, 0);
	MoveDirect(BlockTeam, BlockEnemy, x, y, 0, 1);
	MoveDirect(BlockTeam, BlockEnemy, x, y, 0, -1);
}

PawnMove::PawnMove(int Team)
{
	m_iTeam = Team;
}

void PawnMove::MoveRange(list<Block*> BlockTeam, list<Block*> BlockEnemy, int x, int y)
{
	if (m_iTeam == WHITE)
	{
		CheckRange(BlockEnemy, x- 1, y -1, false);
		CheckRange(BlockEnemy, x + 1, y - 1, false);
		if (m_Count == 0)
		{
			for (int i = 1; i <= 2; i++)
				MoveDirect(BlockTeam, BlockEnemy, x, y, 0, -i);
		}
		else
			MoveDirect(BlockTeam, BlockEnemy, x, y, 0, -1);
	}
	else
	{
		CheckRange(BlockEnemy, x - 1, y + 1, false);
		CheckRange(BlockEnemy, x + 1, y + 1, false);
		if (m_Count == 0)
		{
			for (int i = 1; i <= 2; i++)
				MoveDirect(BlockTeam, BlockEnemy, x, y, 0, i);
		}
		else
			MoveDirect(BlockTeam, BlockEnemy, x, y, 0, 1);
	}
}

void PawnMove::MoveDirect(list<Block*> BlockTeam, list<Block*> BlockEnemy, int px, int py, int x, int y)
{
	if (CheckRange(BlockTeam, px + x, py + y) && CheckRange(BlockEnemy, px + x, py + y))
		PointList.push_back(InputPoint(px + x, py + y));
}

PawnMove::~PawnMove()
{

}