#include "Board.h"
#define PLAYER1 1
#define PLAYER2 2
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
LPCTSTR lpszClass = TEXT("TransparentBlt");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;

	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 1024, 768,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0))
	{
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

bool Move_On = false;
int TurnCount = 1;
void GmaeReSet(HWND hWnd);
void ChessMotion(HWND hWnd, LPARAM lParam);
void GameKey(HDC hdc);
void PaintGame(HDC hdc);
LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	RECT rt = { WIDTH*8 + 20, 0, WIDTH * 12, HEIGHT * 8};
	POINT in_Pt;

	switch (iMessage)
	{
	case WM_CREATE:
		Board::GetInstance()->SetBoard();
		Board::GetInstance()->SetPiece();
		InvalidateRect(hWnd, NULL, TRUE);
		return 0;
	case WM_LBUTTONDOWN:
		ChessMotion(hWnd, lParam);
		InvalidateRect(hWnd, NULL, TRUE);
		return 0;
	case WM_RBUTTONDOWN:
		if (Move_On)
		{
			Move_On = false;
			Board::GetInstance()->Release_MoveBlock();
			InvalidateRect(hWnd, NULL, TRUE);
		}
		return 0;
	case WM_KEYDOWN:
		if (wParam == VK_ESCAPE)
		{
			if (MessageBox(hWnd, TEXT("���� �����"), TEXT("������ �����Ͻðڽ��ϱ�?"), MB_YESNO) == IDYES)
			{
				GmaeReSet(hWnd);
				InvalidateRect(hWnd, NULL, TRUE);
			}
		}
		return 0;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		PaintGame(hdc);
		Rectangle(hdc, rt.left, rt.top, rt.right, rt.bottom);
		GameKey(hdc);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}

void ChessMotion(HWND hWnd, LPARAM lParam)
{
	POINT in_Pt;
	bool GameEnd = false;
	in_Pt.x = LOWORD(lParam);
	in_Pt.y = HIWORD(lParam);
	if (!Move_On)
	{
		if (Board::GetInstance()->CheckBlock(in_Pt))
			Move_On = true;
	}
	else
	{
		if (Board::GetInstance()->MoveBlock(hWnd, in_Pt))
		{
			if (Board::GetInstance()->CheckMate(hWnd))
				GameEnd = true;
			Board::GetInstance()->Release_MoveBlock();
			Move_On = false;
			TurnCount++;
			if (Board::GetInstance()->GameEnd(hWnd) || GameEnd)
			{
				if (MessageBox(hWnd, TEXT("���� �����"), TEXT("������ �����Ͻðڽ��ϱ�?"), MB_YESNO) == IDYES)
				{
					GmaeReSet(hWnd);
					InvalidateRect(hWnd, NULL, TRUE);
				}
				else
				{
					MessageBox(hWnd, TEXT("������ �����մϴ�."), TEXT("���� ����"), MB_OK);
					Board::GetInstance()->ReleaseBorad();
					PostQuitMessage(0);
				}
			}
		}
	}
}

void GmaeReSet(HWND hWnd)
{
	Board::GetInstance()->ReleaseBorad();
	Board::GetInstance()->SetBoard();
	Board::GetInstance()->SetPiece();
	Move_On = false;
	TurnCount = 1;
}

void PaintGame(HDC hdc)
{
	Board::GetInstance()->DrawBoard(hdc, g_hInst);
	if (Move_On)
	{
		if (Board::GetInstance()->GetMoveSize() == 0)
			Move_On = false;
		else
			Board::GetInstance()->MoveRangeDraw(hdc, g_hInst);
	}
	Board::GetInstance()->DrawPiece(hdc, g_hInst);
}

void GameKey(HDC hdc)
{
	TCHAR Turn[128];
	TextOut(hdc, WIDTH * 8 + 50, 20, TEXT("ESC : ���� �����"), 17);
	TextOut(hdc, WIDTH * 8 + 50, 40, TEXT("��Ŭ�� : �� ����"), 16);
	TextOut(hdc, WIDTH * 8 + 50, 60, TEXT("��Ŭ�� : �� ���� ���"), 21);
	wsprintf(Turn, TEXT("���� �ϼ� : %d"), TurnCount);
	TextOut(hdc, WIDTH * 8 + 50, 80, Turn, lstrlen(Turn));
	if (TurnCount % 2 == 1)
		TextOut(hdc, WIDTH * 8 + 50, 100, TEXT("����� ��"), 9);
	else
		TextOut(hdc, WIDTH * 8 + 50, 100, TEXT("����� ��"), 9);
}