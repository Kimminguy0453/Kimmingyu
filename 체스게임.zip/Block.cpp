#include "Block.h"

Block::Block()
{
	m_ID = TEXT("Chess\\block02.bmp");
	m_Type = NOT_PIECE;
}

void Block::SetPoint(int x, int y)
{
	m_Point.x = x;
	m_Point.y = y;
	m_Rt.left = x * WIDTH;
	m_Rt.top = y * HEIGHT;
	m_Rt.right = m_Rt.left + WIDTH;
	m_Rt.bottom = m_Rt.top + HEIGHT;
}

void Block::InitBlock(HDC hdc, HINSTANCE hInst)
{
	bt_Map = new BitMap;
	bt_Map->InitBitMap(hdc, hInst, m_ID);
}

void Block::DrawBlock(HDC hdc)
{
	bt_Map->DrawBitMap(hdc, m_Point.x, m_Point.y);
}

void Block::Release()
{
	delete bt_Map;
	bt_Map = NULL;
}

bool Block::PointCheck(POINT pt)
{
	if (PtInRect(&m_Rt, pt))
		return true;
	return false;
}

Block::~Block(){}

King::King(int Team)
{
	if (Team == WHITE)
		m_ID = TEXT("Chess\\block_w_05.bmp");
	else if (Team == BLACK)
		m_ID = TEXT("Chess\\block_b_05.bmp");
	m_Type = KING;
	BlockMove = new KingMove;
}

King::~King() 
{
	delete BlockMove;
	BlockMove = NULL;
}

Queen::Queen(int Team)
{
	if (Team == WHITE)
		m_ID = TEXT("Chess\\block_w_04.bmp");
	else if (Team == BLACK)
		m_ID = TEXT("Chess\\block_b_04.bmp");
	m_Type = QUEEN;
	BlockMove = new QueenMove;
}

Queen::~Queen() {}


Rook::Rook(int Team)
{
	if (Team == WHITE)
		m_ID = TEXT("Chess\\block_w_03.bmp");
	else if (Team == BLACK)
		m_ID = TEXT("Chess\\block_b_03.bmp");
	m_Type = ROOK;
	BlockMove = new RookMove;
}

Rook::~Rook() 
{
	delete BlockMove;
	BlockMove = NULL;
}

Bishop::Bishop(int Team)
{
	if (Team == WHITE)
		m_ID = TEXT("Chess\\block_w_02.bmp");
	else if (Team == BLACK)
		m_ID = TEXT("Chess\\block_b_02.bmp");
	m_Type = BISHOP;
	BlockMove = new BishopMove;
}

Bishop::~Bishop() 
{
	delete BlockMove;
	BlockMove = NULL;
}

Knight::Knight(int Team)
{
	if (Team == WHITE)
		m_ID = TEXT("Chess\\block_w_01.bmp");
	else if (Team == BLACK)
		m_ID = TEXT("Chess\\block_b_01.bmp");
	m_Type = KNIGHT;
	BlockMove = new KnightMove;
}

Knight::~Knight() 
{
	delete BlockMove;
	BlockMove = NULL;
}

Pawn::Pawn(int Team)
{
	if (Team == WHITE)
		m_ID = TEXT("Chess\\block_w_00.bmp");
	else if (Team == BLACK)
		m_ID = TEXT("Chess\\block_b_00.bmp");
	m_Type = PAWN;
	BlockMove = new PawnMove(Team);
}

Pawn::~Pawn()
{
	delete BlockMove;
	BlockMove = NULL;
}