#include "Character.h"


Character::Character()
{
	m_ix = 450;
	m_iy = 300;
	m_Motion.Motion = 0;
	m_Motion.Direction = 0;
	m_Move.x = 0;
	m_Move.y = 2;

}

void Character::MoveSetCharacter(WPARAM wParam)
{
	switch (wParam)
	{
	case VK_LEFT:
		m_Motion.Direction = LEFT;
		m_Move.x = -2;
		m_Move.y = 0;
		break;
	case VK_RIGHT:
		m_Motion.Direction = RIGHT;
		m_Move.x = 2;
		m_Move.y = 0;
		break;
	case VK_UP:
		m_Motion.Direction = UP;
		m_Move.x = 0;
		m_Move.y = -2;
		break;
	case VK_DOWN:
		m_Motion.Direction = DOWN;
		m_Move.x = 0;
		m_Move.y = 2;
		break;
	}
}

void Character::CharacterJump(int Count)
{
	if (m_Motion.Direction == DOWN || m_Motion.Direction == UP)
	{
		if (Count <= 7)
			m_ix++;
		m_iy += m_Move.y;
		if (Count >= 14)
			m_ix--;
	}
	else if(m_Motion.Direction == LEFT || m_Motion.Direction == RIGHT)
	{
		if (Count <= 7)
			m_iy--;
		m_ix += m_Move.x;
		if (Count >= 14)
			m_iy++;
	}
}

void Character::CharacterMove()
{
	m_Motion.Motion++;
	if (m_Motion.Motion > 3)
		m_Motion.Motion = 0;
	if (m_Motion.Motion % 2 != 0)
	{
		m_ix += m_Move.x;
		m_iy += m_Move.y;
	}
}

void Character::CharacterDraw(HDC hdc)
{
	Bt_Image = new BitMap;
	Bt_Image->InitImage(hdc);
	Bt_Image->DrawImage(hdc, m_ix, m_iy, m_Motion.Motion, m_Motion.Direction);
}

void Character::ReleaseImage()
{
	delete Bt_Image;
	Bt_Image = NULL;
}

Character::~Character()
{

}