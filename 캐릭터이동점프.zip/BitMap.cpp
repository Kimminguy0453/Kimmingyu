#include "BitMap.h"


BitMap::BitMap()
{}

void BitMap::InitImage(HDC hdc)
{
	MemDC = CreateCompatibleDC(hdc);
	m_pImage = (HBITMAP)LoadImage(NULL, TEXT("image.bmp"),
		IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
	m_pOld = (HBITMAP)SelectObject(MemDC, m_pImage);
	BITMAP bit;
	GetObject(m_pImage, sizeof(BITMAP), &bit);
	bx = bit.bmWidth;
	by = bit.bmHeight;
}

void BitMap::DrawImage(HDC hdc, int x, int y, int Motion, int Direction)
{
	TransparentBlt(hdc, x, y, bx / 4, by / 4, MemDC, (bx / 4) * Motion, (by / 4) * Direction, bx / 4, by / 4, RGB(255, 0, 255));
}


BitMap::~BitMap()
{
	SelectObject(MemDC, m_pOld);
	DeleteObject(m_pImage);
	DeleteDC(MemDC);
}
