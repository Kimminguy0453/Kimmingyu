#pragma once
#include "Character.h"

class CharacterManager
{
private:
	Character* m_Character;
	static CharacterManager* m_hThis;
	int JumpCount;
public:
	void CharacteSet();
	static CharacterManager* GetInstance()
	{
		if (m_hThis == NULL)
			m_hThis = new CharacterManager;
		return m_hThis;
	}
	void Move(WPARAM wParam);
	void Jump();
	void DrawAct(HDC hdc);
	inline int GetCount()
	{
		return JumpCount;
	}
};

