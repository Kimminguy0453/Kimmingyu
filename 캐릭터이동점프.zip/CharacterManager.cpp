#include "CharacterManager.h"

CharacterManager* CharacterManager::m_hThis = NULL;
void CharacterManager::CharacteSet()
{
	m_Character = new Character;
	JumpCount = 0;
}

void CharacterManager::Move(WPARAM wParam)
{
	m_Character->MoveSetCharacter(wParam);
	m_Character->CharacterMove();
}

void CharacterManager::Jump()
{
	JumpCount++;
	if (JumpCount <= 20)
		m_Character->CharacterJump(JumpCount);
	else
		JumpCount = 0;
}

void CharacterManager::DrawAct(HDC hdc)
{
	m_Character->CharacterDraw(hdc);
	m_Character->ReleaseImage();
}

