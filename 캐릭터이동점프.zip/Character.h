#pragma once
#include "BitMap.h"

enum DIRECTION
{
	DOWN,
	UP,
	LEFT,
	RIGHT
};

struct CharacterMotion
{
	int Motion;
	int Direction;
};

struct Move
{
	int x;
	int y;
};

class Character
{
private:
	int m_ix;
	int m_iy;
	Move m_Move;
	CharacterMotion m_Motion;
	BitMap* Bt_Image;
public:
	Character();
	void MoveSetCharacter(WPARAM wParam);
	void CharacterJump(int Count);
	void CharacterMove();
	void CharacterDraw(HDC hdc);
	void ReleaseImage();
	~Character();
};

