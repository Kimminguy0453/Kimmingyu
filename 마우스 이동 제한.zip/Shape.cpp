#include "Shape.h"

Shape* Shape::m_hThis = NULL;

void Shape::SetPoint(int x, int y)
{
	if (x - 50 <= rt.left)
		m_Point.x = rt.left + 50;
	else if (x + 50 >= rt.right)
		m_Point.x = rt.right - 50;
	else
		m_Point.x = x;

	if (y - 50 <= rt.left)
		m_Point.y = rt.left + 50;
	else if (y + 50 >= rt.right)
		m_Point.y = rt.right - 50;
	else
		m_Point.y = y;
}


void Shape::Draw(HDC hdc)
{
	Ellipse(hdc, m_Point.x - 50, m_Point.y - 50, m_Point.x + 50, m_Point.y + 50);
}

void Shape::DrawRectRange(HDC hdc)
{
	Rectangle(hdc, rt.left, rt.top, rt.right, rt.bottom);
}

void Shape::DeleteShape()
{
	delete m_hThis;
	m_hThis = NULL;
}
