#pragma once
#include <iostream>
#include<Windows.h>
#include<string>
using namespace std;

struct Point
{
	int x;
	int y;
};

class Shape
{
private:
	Point m_Point;
	static Shape* m_hThis;
	RECT rt = { 150, 150, 500, 500 };
public:
	void SetPoint(int x, int y);
	void Draw(HDC hdc);
	void DeleteShape();
	void DrawRectRange(HDC hdc);
	static Shape* GetInstance()
	{
		if (m_hThis == NULL)
			m_hThis = new Shape;
		return m_hThis;
	}

};

