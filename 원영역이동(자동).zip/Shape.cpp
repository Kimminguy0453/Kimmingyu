#include "Shape.h"

Shape* Shape::m_hThis = NULL;

void  Shape::SetPoint(int x, int y)
{
	m_Point.x = x;
	m_Point.y = y;
	m_MoveX = DOWN;
	m_MoveY = STOP;
}

void Shape::Move()
{
	if (m_Point.x + DOWN <= rt.left)
	{
		m_MoveX = UP;
		m_MoveY = rand() % 3 - 1;
		m_Point.x += m_MoveX;
		m_Point.y += m_MoveY;
	}
	else if ((m_Point.x + 100) + UP >= rt.right)
	{
		m_MoveX = DOWN;
		m_MoveY = rand() % 3 - 1;
		m_Point.x += m_MoveX;
		m_Point.y += m_MoveY;
	}
	else
		m_Point.x += m_MoveX;

	if (m_Point.y + DOWN <= rt.top)
	{
		m_MoveY = UP;
		m_MoveX = rand() % 3 - 1;
		m_Point.x += m_MoveX;
		m_Point.y += m_MoveY;
	}
	else if ((m_Point.y + 100) + UP >= rt.bottom)
	{
		m_MoveY = DOWN;
		m_MoveX = rand() % 3 - 1;
		m_Point.x += m_MoveX;
		m_Point.y += m_MoveY;
	}
	else
		m_Point.y += m_MoveY;
}

void Shape::Draw(HDC hdc)
{
	Ellipse(hdc, m_Point.x, m_Point.y, m_Point.x + 100, m_Point.y + 100);
}

void Shape::DrawRectRange(HDC hdc)
{
	Rectangle(hdc, rt.left, rt.top, rt.right, rt.bottom);
}

void Shape::DeleteShape()
{
	delete m_hThis;
	m_hThis = NULL;
}
