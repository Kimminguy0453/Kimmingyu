#pragma once
#include <iostream>
#include<Windows.h>
#include<string>
using namespace std;

struct Point
{
	int x;
	int y;
};

enum DIRECTION
{
	DOWN = -1,
	STOP,
	UP,
};

class Shape
{
private:
	Point m_Point;
	int m_MoveX;
	int m_MoveY;
	static Shape* m_hThis;
	RECT rt = { 150, 150, 500, 500 };
public:
	void SetPoint(int x, int y);
	void Move();
	void MoveChange();
	void Draw(HDC hdc);
	void DeleteShape();
	void DrawRectRange(HDC hdc);
	static Shape* GetInstance()
	{
		if (m_hThis == NULL)
			m_hThis = new Shape;
		return m_hThis;
	}

};

