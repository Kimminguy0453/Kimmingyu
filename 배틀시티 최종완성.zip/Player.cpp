#include "Player.h"

Player::Player(GameMap* map, int x, int y)
{
	ReadMap = map;
	BackPoint.x = 50 + x * BLOCK_WIDTH;
	BackPoint.y = 50 + y * BLOCK_HEIGHT;
	m_Data.rt = SetRect(BackPoint.x, BackPoint.y);
	m_Data.Type = PLAYER;
	UseUnit = true;
	MoveSpeed = 80;
	m_Life = 6;
	DeathFlag = false;
	FrameCounter = 0;
	MissileCount = 0;
	MoveWay = UP;
	Back_Up_MoveWay = MoveWay;
	WayImage = UP_1;
	Reloading = 0.6;
	Shoot = true;
	SetDataPoint();
	ImageID();
}

void Player::SetDataPoint()
{
	m_Data.pt.x = m_Data.rt.left;
	m_Data.pt.y = m_Data.rt.top;
}

void Player::ReleaseFrame()
{
	FrameCounter = 0;
	SetDataPoint();
}

bool Player::MoveCharacter()
{
	RECT tmp;
	int tmp_x;
	int tmp_y;
	int BackUp_Move = MoveWay;
	bool Check = false;

	if (GetKeyState(VK_LEFT) & 0x8000)
	{

		if (BackUp_Move != LEFT)
			ReleaseFrame();
		tmp_x = m_Data.pt.x - MoveSpeed * FrameCounter;
		tmp_y = m_Data.pt.y;
		tmp = { tmp_x , tmp_y, tmp_x + CHARACTER_WIDTH, tmp_y + CHARACTER_HEIGHT };
		if (ReadMap->CheckNotImpulse(tmp))
		{
			if (m_Data.pt.x - MoveSpeed * FrameCounter < 50)
				tmp_x = 50;
			else
				Check = true;
			m_Data.rt = SetRect(tmp_x, tmp_y);
			Back_Up_MoveWay = LEFT;
			MoveChange();
		}
	}
	else if (GetKeyState(VK_RIGHT) & 0x8000)
	{
		if (BackUp_Move != RIGHT)
			ReleaseFrame();
		tmp_x = m_Data.pt.x + MoveSpeed * FrameCounter;
		tmp_y = m_Data.pt.y;
		tmp = { tmp_x , tmp_y, tmp_x + CHARACTER_WIDTH, tmp_y + CHARACTER_HEIGHT };
		if (ReadMap->CheckNotImpulse(tmp))
		{
			if (tmp_x + CHARACTER_WIDTH > 50 + BLOCK_WIDTH * 13)
				tmp_x = 50 + BLOCK_WIDTH * 13 - CHARACTER_WIDTH;
			else
				Check = true;
			m_Data.rt = SetRect(tmp_x, tmp_y);
			Back_Up_MoveWay = RIGHT;
			MoveChange();
		}
	}
	else if (GetKeyState(VK_UP) & 0x8000)
	{
		if (BackUp_Move != UP)
 			ReleaseFrame();
		tmp_x = m_Data.pt.x;
		tmp_y = m_Data.pt.y - MoveSpeed * FrameCounter;
		tmp = { tmp_x , tmp_y, tmp_x + CHARACTER_WIDTH, tmp_y + CHARACTER_HEIGHT };
		if (ReadMap->CheckNotImpulse(tmp))
		{
			if (tmp_y < 50)
				tmp_y = 50;
			else
				Check = true;
			m_Data.rt = SetRect(tmp_x, tmp_y);
			Back_Up_MoveWay = UP;
			MoveChange();
		}
	}
	else if (GetKeyState(VK_DOWN) & 0x8000)
	{
		if (BackUp_Move != DOWN)
			ReleaseFrame();
		tmp_x = m_Data.pt.x;
		tmp_y = m_Data.pt.y + MoveSpeed * FrameCounter;
		tmp = { tmp_x , tmp_y, tmp_x + CHARACTER_WIDTH, tmp_y + CHARACTER_HEIGHT };
		if (ReadMap->CheckNotImpulse(tmp))
		{
			if (tmp_y + CHARACTER_HEIGHT > 50 + BLOCK_HEIGHT * 13)
				tmp_y = 50 + BLOCK_HEIGHT * 13 - CHARACTER_HEIGHT;
			else
				Check = true;
			m_Data.rt = SetRect(tmp_x, tmp_y);
			Back_Up_MoveWay = DOWN;
			MoveChange();
		}
	}
	return Check;
}

void Player::MoveChange()
{
	MoveWay = Back_Up_MoveWay;
	SetWayImage(MoveWay);
}

bool Player::DamageCheck(Missile* CheckMissile)
{
	RECT tmp;
	if (!DeathFlag)
	{
		if (IntersectRect(&tmp, &m_Data.rt, &(CheckMissile->GetMissileRect())))
		{
			m_Life--;
			DeathFlag = true;
			FrameCounter = 0;
			return true;
		}
	}
	return false;
}

void Player::SetFrame(double Delta)
{
	FrameCounter += Delta;
	if (FrameCounter > 1)
		FrameCounter = 1;
	if (FrameCounter == 1)
		ReleaseFrame();


	if (!Shoot)
	{
		MissileCount += Delta;
		if (MissileCount > Reloading)
		{
			MissileCount = 0;
			Shoot = true;
		}
	}
}

void Player::DeathProcess()
{
	if (FrameCounter == 0)
	{
		DeathFlag = false;
		if (m_Life > 0)
		{
			SetRect(BackPoint.x, BackPoint.y);
			SetDataPoint();
			MoveWay = UP;
			SetWayImage(UP);
		}
		else
			UseUnit = false;
	}
	else if (FrameCounter < 0.20)
		DeathImage(0);
	else if (FrameCounter < 0.40)
		DeathImage(1);
	else if (FrameCounter < 0.60)
		DeathImage(2);
	else if (FrameCounter < 0.80)
		DeathImage(3);
	else if (FrameCounter < 1)
		DeathImage(4);
}

void Player::ImageID()
{
	if (WayImage == DOWN_1)
		m_Image = TEXT("BattleCity\\tank_down_00.bmp");
	else if (WayImage == DOWN_2)
		m_Image = TEXT("BattleCity\\tank_down_01.bmp");
	if (WayImage == LEFT_1)
		m_Image = TEXT("BattleCity\\tank_left_00.bmp");
	else if (WayImage == LEFT_2)
		m_Image = TEXT("BattleCity\\tank_left_01.bmp");
	if (WayImage == RIGHT_1)
		m_Image = TEXT("BattleCity\\tank_right_00.bmp");
	else if (WayImage == RIGHT_2)
		m_Image = TEXT("BattleCity\\tank_right_01.bmp");
	if (WayImage == UP_1)
		m_Image = TEXT("BattleCity\\tank_up_00.bmp");
	else if (WayImage == UP_2)
		m_Image = TEXT("BattleCity\\tank_up_01.bmp");
}

void Player::DrawUnit()
{
	Image::GetImageMaker()->DrawUnit(m_Image, m_Data.rt.left, m_Data.rt.top);
}


Missile* Player::MakeMissile()
{
	Shoot = false;
	if (MoveWay == LEFT)
		return new Missile(ReadMap, PLAYER, MoveWay, m_Data.rt.left, m_Data.rt.top + (CHARACTER_HEIGHT / 2) - 3);
	else if (MoveWay == RIGHT)
		return new Missile(ReadMap, PLAYER, MoveWay, m_Data.rt.right, m_Data.rt.top + (CHARACTER_HEIGHT / 2) - 3);
	else if (MoveWay == UP)
		return new Missile(ReadMap, PLAYER, MoveWay, m_Data.rt.left + (CHARACTER_WIDTH / 2) - 3, m_Data.rt.top);
	else if (MoveWay == DOWN)
		return new Missile(ReadMap, PLAYER, MoveWay, m_Data.rt.left + (CHARACTER_WIDTH / 2) - 3, m_Data.rt.bottom);
}

Player::~Player()
{

}