#include "Enemy.h"

Enemy::Enemy(GameMap* map, int x, int y)
{
	int tmp_Life = rand() % 100 + 1;
	ReadMap = map;
	Top = NULL;

	//�÷��� ����
	UseUnit = true;
	MoveFlag = true;
	Counterattack = false;
	NotImpulseFlag = false;
	ComeBack = false;
	DamageFlag = false;
	DeathFlag = false;
	Shoot = true;
	PrepareFlag = false;
	MoveChangeCounter = 0;
	MoveWay = STOP;
	Hit_Direction = STOP;

	//ī����
	FrameCounter = 0;
	MissileCount = 0;
	DamageCounter = 0;

	if (tmp_Life <= 80)
	{
		Reloading = 2;
		m_Life = 2;
		MoveSpeed = 70;
	}
	else
	{
		Reloading = 1.5;
		m_Life = 3;
		MoveSpeed = 100;
	}
	Insert(x * 2, y * 2);
	SetWayImage(MoveWay);
}

void Enemy::Insert(int x, int y)
{
	MoveRecord* tmp = Top;
	Top = new MoveRecord;
	Top->Per = tmp;
	Top->Data.pt.x = x;
	Top->Data.pt.y = y;
	Top->ComebackCount = 0;
	Top->Data.rt.left = Top->Data.pt.x * HALF_WIDTH + 53;
	Top->Data.rt.top = Top->Data.pt.y * HALF_HEIGHT + 53;
	Top->Data.rt.right = Top->Data.rt.left + CHARACTER_WIDTH;
	Top->Data.rt.bottom = Top->Data.rt.top + CHARACTER_HEIGHT;

	Cur_pt.x = Top->Data.rt.left;
	Cur_pt.y = Top->Data.rt.top;

	Top->M_falg.Left = false;
	Top->M_falg.Right = false;
	Top->M_falg.Down = false;
	Top->M_falg.Up = false;

	PathCheck();
	MoveChange();
}

void Enemy::Delete()
{
	MoveRecord* tmp;
	if (Top->Per != NULL)
	{
		tmp = Top;
		Top = Top->Per;
		delete tmp;
		tmp = NULL;
	}
     MoveChange();
}

bool Enemy::PerCheck(int x, int y)
{
	MoveRecord* tmp = Top->Per;
	while (tmp != NULL)
	{
		if (tmp->Data.pt.x == x && tmp->Data.pt.y == y)
			return false;
		tmp = tmp->Per;
	}
	return true;
}

bool Enemy::CheckNext(int x, int y)
{
	if (ReadMap->GetBlock(x, y) == NOT_BLOCK)
		return true;

	return false;
}

bool Enemy::CheckBroken(int x, int y)
{
	if (ReadMap->GetBlock(x, y) >= INTACT_BRICK && ReadMap->GetBlock(x, y) <= RIGHT_BRICK || ReadMap->GetBlock(x, y) == NOT_BLOCK)
		return true;
	return false;
}

bool Enemy::NotImpluseCheck(int x, int y)
{
	if (ReadMap->CheckNotImpulse(SetRect(x * HALF_WIDTH + 53, y * HALF_HEIGHT + 53)))
		return true;
	else
		return false;
}

bool Enemy::PathCheckWay(int Way, int x, int y)
{
	int tmp;

	if (Way == LEFT || Way == UP)
		tmp = -1;
	else if (Way == RIGHT || Way == DOWN)
		tmp = 1;

	if (Way == LEFT || Way ==  RIGHT)
	{
		if (y % 2 == 1)
		{
			if (CheckNext(x / 2 + tmp, y / 2) && CheckNext(x / 2 + tmp, y / 2 + 1))//����� Ȯ��.
				return true;
			else if (CheckBroken(x / 2 + tmp, y / 2) && CheckBroken(x / 2 + tmp, y / 2 + 1))//������� �ƴҶ� �μ��� �ִº������� Ȯ��.
				return true;
		}
		else
		{
			if (CheckNext(x / 2 + tmp, y / 2))
				return true;
			else if (CheckBroken(x / 2 + tmp, y / 2))
				return true;
		}
	}
	else if (Way == DOWN || Way == UP)
	{
		if (x % 2 == 1)
		{
			if (CheckNext(x / 2 , y / 2 + tmp) && CheckNext(x / 2 + 1, y / 2 + tmp))//����� Ȯ��.
				return true;
			else if (CheckBroken(x / 2, y / 2 + tmp) && CheckBroken(x / 2 + 1, y / 2 + tmp))//������� �ƴҶ� �μ��� �ִº������� Ȯ��.
				return true;
		}
		else
		{
			if (CheckNext(x / 2, y / 2 + tmp))
				return true;
			else if (CheckNext(x / 2, y / 2 + tmp))//������� �ƴҶ� �μ��� �ִº������� Ȯ��.
				return true;
		}
	}
	return false;
}


void Enemy::PathCheck()
{
	if (Top->Data.pt.x - 1 >= 0 && Top->Data.pt.x / 2 - 1 >= 0)
		Top->M_falg.Left = PathCheckWay(LEFT, Top->Data.pt.x, Top->Data.pt.y) & PerCheck(Top->Data.pt.x - 1, Top->Data.pt.y) ;
	if (Top->Data.pt.x + 1 < 25 && Top->Data.pt.x / 2 + 1 < 13)
		Top->M_falg.Right = PathCheckWay(RIGHT, Top->Data.pt.x, Top->Data.pt.y) & PerCheck(Top->Data.pt.x + 1, Top->Data.pt.y);
	if (Top->Data.pt.y - 1 >= 0 && Top->Data.pt.y / 2 - 1 >= 0)
		Top->M_falg.Up = PathCheckWay(UP, Top->Data.pt.x, Top->Data.pt.y) & PerCheck(Top->Data.pt.x, Top->Data.pt.y - 1);
	if (Top->Data.pt.y + 1 < 25 && Top->Data.pt.y / 2 + 1 < 13)
		Top->M_falg.Down = PathCheckWay(DOWN, Top->Data.pt.x, Top->Data.pt.y)  & PerCheck(Top->Data.pt.x, Top->Data.pt.y + 1);
}

void Enemy::RockOnTarget(int x, int y)
{
	Target.x = x;
	Target.y = y;
	if (!ComeBack)
	{
		int Way = MoveWay;
		if (ReadMap->CheckNotImpulse(SetRect(x * HALF_WIDTH + 53, y * HALF_HEIGHT + 53)))//Ÿ������ ���� ������ ������ �μ��� �ִº��� �־��� ������ Ÿ�������� �����ִ��� Ȯ�� ����.
			MoveFlag = true;//�ȸ��������� ������.
		else if((x == 12 && y >= 23) || (x == 13 && y >= 23) || (y == 23 && x >= 11 && x < 14))
			MoveFlag = false;
		else if (rand() & 100 + 1 <= MoveSpeed / 2)
			MoveFlag = false;//����������� ����Ȯ���� �������� �ʰ� ������ ��ٸ�.
		else
   			MoveChange();
	}
}

void Enemy::MoveChange()
{
	bool Go_Straight = false;
	map <int, int> SelectMove;
	int Key = 0;
	int SelectKey;
	bool CheckMate = CheckMateCommandCenter();

	if (!CheckMate)
	{
		MoveFlag = true;
		if (Top->M_falg.Left)
		{
			if (MoveWay == LEFT && MoveChangeCounter < 2)
				Go_Straight = true;
			SelectMove.insert(pair<int, int>(Key++, LEFT));
		}
		if (Top->M_falg.Right)
		{
			if (MoveWay == RIGHT && MoveChangeCounter < 2)
				Go_Straight = true;
			SelectMove.insert(pair<int, int>(Key++, RIGHT));
		}
		if (Top->M_falg.Down)
		{
			if (MoveWay == DOWN && MoveChangeCounter < 2)
				Go_Straight = true;
			SelectMove.insert(pair<int, int>(Key++, DOWN));
		}
		if (Top->M_falg.Up &&SelectMove.size() == 0 && !ComeBack)
				SelectMove.insert(pair<int, int>(Key++, UP));

		if (ComeBack)
			ComeBack = false;


		if (Counterattack)
		{
			MoveFlag = false;

			Counterattack = false;
			BackUpMoveWay = MoveWay;
			MoveWay = Hit_Direction;
			SetWayImage(MoveWay);

			if (BackUpMoveWay == LEFT)
				Top->M_falg.Left = true;
			else if (BackUpMoveWay == RIGHT)
				Top->M_falg.Right = true;
			else if (BackUpMoveWay == DOWN)
				Top->M_falg.Down = true;
			else if (BackUpMoveWay == UP)
				Top->M_falg.Up = true;
		}
		else if (SelectMove.size() != 0)
		{
			if(!Go_Straight && !Counterattack)
			{
				MoveChangeCounter = 0;
				SelectKey = rand() % SelectMove.size();
				MoveWay = SelectMove.find(SelectKey)->second;
			}
			SelectCheck();
			SetWayImage(MoveWay);
		}
		else
		{
			if (Top->Per != NULL)
				Comeback();
		}
	}
	else
		MoveFlag = false;
	if(Counterattack)
		Counterattack = false;
}

void Enemy::SelectCheck()
{
	if (MoveWay == LEFT)
	{
		Top->M_falg.Left = false;
		RockOnTarget(Top->Data.pt.x - 1, Top->Data.pt.y);
	}
	else if (MoveWay == RIGHT)
	{
		Top->M_falg.Right = false;
		RockOnTarget(Top->Data.pt.x + 1, Top->Data.pt.y);
	}
	else if (MoveWay == DOWN)
	{
		Top->M_falg.Down = false;
		RockOnTarget(Top->Data.pt.x, Top->Data.pt.y + 1);
	}
	else if (MoveWay == UP)
	{
		Top->M_falg.Up = false;
		RockOnTarget(Top->Data.pt.x, Top->Data.pt.y - 1);
	}
}

void Enemy::Comeback()
{
	ComeBack = true;
	RockOnTarget(Top->Per->Data.pt.x, Top->Per->Data.pt.y);
	Top->Per->ComebackCount++;
}


bool Enemy::MoveCharacter()
{
	if (!DamageFlag)
	{
		if (MoveFlag)
		{
			if (Target.y == Top->Data.pt.y)
			{
				if (Target.x < Top->Data.pt.x)
				{
					MoveWay = LEFT;
					SetWayImage(LEFT);
					if (Target.x * HALF_WIDTH + 53 < Top->Data.rt.left - MoveSpeed * FrameCounter)
						Cur_pt.x = Top->Data.rt.left - MoveSpeed * FrameCounter;
					else
					{
						FrameCounter = 0;
						if (!ComeBack)
							Insert(Target.x, Target.y);
						else
							Delete();
					}
				}
				else if (Target.x > Top->Data.pt.x)
				{
					MoveWay = RIGHT;
					SetWayImage(RIGHT);
					if (Target.x * HALF_WIDTH + 53 > Top->Data.rt.left + MoveSpeed * FrameCounter)
						Cur_pt.x = Top->Data.rt.left + MoveSpeed * FrameCounter;
					else
					{
						FrameCounter = 0;
						if (!ComeBack)
							Insert(Target.x, Target.y);
						else
							Delete();
					}
				}
			}
			else if (Target.x == Top->Data.pt.x)
			{
				if (Target.y < Top->Data.pt.y)
				{
					MoveWay = UP;
					SetWayImage(UP);
					if (Target.y * HALF_HEIGHT + 53 < Top->Data.rt.top - MoveSpeed * FrameCounter)
							Cur_pt.y = Top->Data.rt.top - MoveSpeed * FrameCounter;
					else
					{
						FrameCounter = 0;
						if (!ComeBack)
							Insert(Target.x, Target.y);
						else
							Delete();
					}
				}
				else if (Target.y > Top->Data.pt.y)
				{
					MoveWay = DOWN;
					SetWayImage(DOWN);
					if (Target.y * HALF_HEIGHT + 53 > Top->Data.rt.top + MoveSpeed * FrameCounter)
						Cur_pt.y = Top->Data.rt.top + MoveSpeed * FrameCounter;
					else
					{
						FrameCounter = 0;
						if (!ComeBack)
							Insert(Target.x, Target.y);
						else
							Delete();
					}
				}
			}
		}
		else 
		{
			if (MoveChangeCounter > 1)
			{
				MoveChangeCounter = 0;
				MoveChange();
			}
		}
	}
	else
		ImageID();

	return true;
}


bool Enemy::DamageCheck(Missile* CheckMissile)
{
	RECT tmp;
	RECT Cur_Rt = { Cur_pt.x, Cur_pt.y, Cur_pt.x + CHARACTER_WIDTH, Cur_pt.y + CHARACTER_HEIGHT };

	if (!DeathFlag)
	{
		if (IntersectRect(&tmp, &(Cur_Rt), &(CheckMissile->GetMissileRect())))
		{
			if (!DamageFlag)
			{
				m_Life--;
				if (m_Life > 0)
				{
					if (CheckMissile->GetMoveWay() == LEFT)
						Hit_Direction = RIGHT;
					else if (CheckMissile->GetMoveWay() == RIGHT)
						Hit_Direction = LEFT;
					else if (CheckMissile->GetMoveWay() == UP)
						Hit_Direction = DOWN;
					else if (CheckMissile->GetMoveWay() == DOWN)
						Hit_Direction = UP;
					DamageFlag = true;
				}
				else
				{
					DeathFlag = true;
					FrameCounter = 0;
				}
			}
			return true;
		}
	}
	return false;
}

void Enemy::SetFrame(double Delta)
{
	if (!DamageFlag)
	{
		if (MoveFlag)
			FrameCounter += Delta;
 		MoveChangeCounter += Delta;
	}

		

	if (DeathFlag)
	{
		if (FrameCounter > 1.5)
			FrameCounter = 0;
	}
	if (!Shoot)
	{
		if (!DamageFlag)
		{
			MissileCount += Delta;
			if (MissileCount > Reloading)
			{
				MissileCount = 0;
				Shoot = true;
			}
		}
	}
	if (DamageFlag)
	{
		DamageCounter += Delta;
		if (DamageCounter > 1)
			DamageCounter = 1;
		if (DamageCounter == 1)
		{
			DamageFlag = false;
			DamageCounter = 0;	
			MoveChangeCounter = 0;
			Counterattack = true;
			MoveChange();
	    }
	}
}

void Enemy::DeathProcess()
{
	if (FrameCounter == 0)
		UseUnit = false;
	else if (FrameCounter < 0.20)
		DeathImage(0);
	else if (FrameCounter < 0.40)
		DeathImage(1);
	else if (FrameCounter < 0.60)
		DeathImage(2);
	else if (FrameCounter < 0.80)
		DeathImage(3);
	else if (FrameCounter < 1)
		DeathImage(4);
}

Missile* Enemy::MakeMissile()
{
	Shoot = false;
	if (MoveWay == LEFT)
		return new Missile(ReadMap, ENEMY, MoveWay, Cur_pt.x, Cur_pt.y + (CHARACTER_HEIGHT / 2) - 3);
	else if (MoveWay == RIGHT)
		return new Missile(ReadMap, ENEMY, MoveWay, Cur_pt.x + CHARACTER_WIDTH, Cur_pt.y + (CHARACTER_HEIGHT / 2) - 3);
	else if (MoveWay == UP)
		return new Missile(ReadMap, ENEMY, MoveWay, Cur_pt.x + (CHARACTER_WIDTH / 2) - 3, Cur_pt.y);
	else if (MoveWay == DOWN)
		return new Missile(ReadMap, ENEMY, MoveWay, Cur_pt.x + (CHARACTER_WIDTH / 2) - 3, Cur_pt.y + CHARACTER_HEIGHT);
}

void Enemy::ImageID()
{
	if (!DamageFlag)
	{
		if (WayImage == DOWN_1)
			m_Image = TEXT("BattleCity\\e_down_00.bmp");
		else if (WayImage == DOWN_2)
			m_Image = TEXT("BattleCity\\e_down_01.bmp");
		else if (WayImage == LEFT_1)
			m_Image = TEXT("BattleCity\\e_left_00.bmp");
		else if (WayImage == LEFT_2)
			m_Image = TEXT("BattleCity\\e_left_01.bmp");
		else if (WayImage == RIGHT_1)
			m_Image = TEXT("BattleCity\\e_right_00.bmp");
		else if (WayImage == RIGHT_2)
			m_Image = TEXT("BattleCity\\e_right_01.bmp");
		else if (WayImage == UP_1)
			m_Image = TEXT("BattleCity\\e_up_00.bmp");
		else if (WayImage == UP_2)
			m_Image = TEXT("BattleCity\\e_up_01.bmp");
	}
	else
	{
		if (MoveWay == DOWN)
			m_Image = TEXT("BattleCity\\e_down_02.bmp");
		else if (MoveWay == LEFT)
			m_Image = TEXT("BattleCity\\e_left_02.bmp");
		else if (MoveWay == RIGHT)
			m_Image = TEXT("BattleCity\\e_right_02.bmp");
		else if (MoveWay == UP)
			m_Image = TEXT("BattleCity\\e_UP_02.bmp");
	}
}

void Enemy::DrawUnit()
{
	Image::GetImageMaker()->DrawUnit(m_Image, Cur_pt.x, Cur_pt.y);
}


bool Enemy::CheckMateCommandCenter()
{
	if (MoveWay == RIGHT && (Top->Data.pt.x == 10 && (Top->Data.pt.y >= 23)))
		return true;
	else if (MoveWay == LEFT && (Top->Data.pt.x == 10 && (Top->Data.pt.y >= 23)))
		return true;
	else if (MoveWay == DOWN && (Top->Data.pt.y == 22 && (Top->Data.pt.x >= 11 && Top->Data.pt.x < 14)))
		return true;

	return false;
}

Enemy::~Enemy()
{
}