#include "Character.h"


RECT Character::SetRect(int x, int y)
{
	RECT tmp;
	tmp.left = x;
	tmp.top = y;
	tmp.right = tmp.left + CHARACTER_WIDTH;
	tmp.bottom = tmp.top + CHARACTER_HEIGHT;

	return tmp;
}

void Character::SetWayImage(int Way)
{
	if (Way == LEFT)
	{
		if (WayImage != LEFT_1)
			WayImage = LEFT_1;
		else
			WayImage = LEFT_2;
	}
	else if (Way == RIGHT)
	{
		if (WayImage != RIGHT_1)
			WayImage = RIGHT_1;
		else
			WayImage = RIGHT_2;
	}
	else if (Way == UP)
	{
		if (WayImage != UP_1)
			WayImage = UP_1;
		else
			WayImage = UP_2;
	}
	else if (Way == DOWN)
	{
		if (WayImage != DOWN_1)
			WayImage = DOWN_1;
		else
			WayImage = DOWN_2;
	}
	ImageID();
}

void  Character::DeathImage(int Number)
{
	if (Number == 0)
		m_Image = TEXT("BattleCity\\explosion_00.bmp");
	else if (Number == 1)
		m_Image = TEXT("BattleCity\\explosion_01.bmp");
	else if (Number == 2)
		m_Image = TEXT("BattleCity\\explosion_02.bmp");
	else if (Number == 3)
		m_Image = TEXT("BattleCity\\explosion_03.bmp");
	else if (Number == 4)
		m_Image = TEXT("BattleCity\\explosion_04.bmp");
}