#pragma once
#include "Player.h"
#include "Enemy.h"
#include <map>
#include <list>
using namespace std;

#define SAVE 100
#define LOAD 101
#define EXIT 102

struct GameProcessFlag
{
	bool PlayFlag;
	bool UseFrameCount;
	bool PlayCustom;
};

class BattleCity
{
private:
	//������ī����
	LARGE_INTEGER Start, End, Frequency;
	double Delta;
	double MakeEnemyCounter;
	//=======================

	//��ư
	HWND CustomButtom[17];
	HWND TitleButtom[4];
	//=======================
	map<int, POINT> respawn;

	//���� ���� �� ���ϰ��
	char curFile[MAX_PATH] = "";
	char ProjectPath[MAX_PATH] = "";
	//=======================

	map<int, POINT> Respawn;
	Player* PlayerUnit;
	list<Enemy*> EnemyList;
	GameMap* m_Map;
	GameProcessFlag m_Flag;
	list<Missile*> m_MissileList;
	int CurType;
	int m_iStage;
	int Total_Enemy;
	int Field_Enemy;
	static BattleCity* m_hThis;
public:
	static BattleCity* GetGame()
	{
		if (m_hThis == NULL)
			m_hThis = new BattleCity;
		return m_hThis;
	}
	void Default(HWND hWnd);
	void DefaultFlag();
	void SetTitleButton(HWND hWnd, HINSTANCE g_hInst);
	void EndTitle();
	
	void SetOpenFile(HWND hWnd, int Type);
	void SelectStage(bool CustomStart = false);
	void SaveMap(OPENFILENAME &OFN);
	void LoadMap(LPSTR hFile);

	void InitCursor(int Type);
	void CustomStart(HWND hWnd, HINSTANCE g_hInst);
	void CustomEnd();
	void ChangeBlock(POINT pt);

	void MakeEnemy();
	void Game_UpDate(HWND hWnd);
	void PlayerMove();
	void EnemyMove();
	void MissileMove();
	void ReleaseEnemy();
	void ReleaseMissile();
	void DamageCheck();
	void DrawGame(HWND hWnd);
	void QuestionNextStage(HWND hWnd);
	void GameEnd(HWND hWnd, bool Over);
	void GameRelease();

	inline bool GetGameFlag()
	{
		return m_Flag.PlayFlag;
	}
	inline bool GetCustom()
	{
		return m_Map->GetCoustomMode();
	}
};

