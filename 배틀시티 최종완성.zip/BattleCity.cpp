#include "BattleCity.h"

BattleCity* BattleCity::m_hThis = NULL;
void BattleCity::Default(HWND hWnd)
{
	char str[MAX_PATH];
	srand(time(NULL));
	GetCurrentDirectory(MAX_PATH, str);
	wsprintf(ProjectPath, "%s\\Map", str);
	m_Map = new GameMap;
	PlayerUnit = NULL;
	DefaultFlag();
}



void BattleCity::DefaultFlag()
{
	m_Map->CustomMode_On(false);
	m_Flag.PlayCustom = false;
	m_Flag.PlayFlag = false;
	m_Flag.UseFrameCount = false;
}

//==================================================================================================================
//Ÿ��Ʋ ����
void BattleCity::SetTitleButton(HWND hWnd, HINSTANCE g_hInst)
{
	m_iStage = 1;
	CurType = 0;
	TitleButtom[0] = CreateWindow("button", "������", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 325, 250, 100, 30, hWnd, (HMENU)50, g_hInst, NULL);
	TitleButtom[1] = CreateWindow("button", "�ҷ�����", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 325, 300, 100, 30, hWnd, (HMENU)51, g_hInst, NULL);
	TitleButtom[2] = CreateWindow("button", "Ŀ���� ���", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 325, 350, 100, 30, hWnd, (HMENU)52, g_hInst, NULL);
	TitleButtom[3] = CreateWindow("button", "���� ����", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 325, 400, 100, 30, hWnd, (HMENU)53, g_hInst, NULL);
}

void BattleCity::EndTitle()
{
	for (int i = 0; i < 4; i++)
		DestroyWindow(TitleButtom[i]);
}
//==================================================================================================================

//==================================================================================================================
//���������
void BattleCity::SelectStage(bool CustomStart)
{
	char File[MAX_PATH] = "";

	if (CustomStart)
		wsprintf(File, "%s\\DefaultMap", ProjectPath);
	else
		wsprintf(File, "%s\\Stage%d", ProjectPath, m_iStage);

	LoadMap(File);
}

void BattleCity::SetOpenFile(HWND hWnd, int Type)
{
	OPENFILENAME OFN;
	char lpstrFile[MAX_PATH] = "";
	char lpstrPath[MAX_PATH] = "";
	char str[MAX_PATH] = "";

	memset(&OFN, 0, sizeof(OPENFILENAME));//
	OFN.lStructSize = sizeof(OPENFILENAME);
	OFN.hwndOwner = hWnd;
	OFN.lpstrFilter = "File\0*.*\0Text File\0*.txt;*.doc\0";
	OFN.lpstrFile = lpstrFile;
	OFN.nMaxFile = 256;

	OFN.lpstrInitialDir = ProjectPath;

	if (Type == 100)
		SaveMap(OFN);
	else
	{
		if (!m_Map->GetCoustomMode())
			m_Flag.PlayCustom = true;
		if (GetOpenFileName(&OFN) != 0)
		{
			wsprintf(curFile, "%s", OFN.lpstrFile);
			LoadMap(OFN.lpstrFile);
		}
	}
}

void BattleCity::SaveMap(OPENFILENAME &OFN)
{
	int type;
	if (GetSaveFileName(&OFN) != 0)
	{
		HANDLE hFile = CreateFile(OFN.lpstrFile, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
		for (int i = 0; i < 13; i++)
		{
			for (int j = 0; j < 13; j++)
			{
				type = m_Map->GetBlock(j, i);
				DWORD writeB;
				WriteFile(hFile, &type, sizeof(int), &writeB, NULL);
			}
		}
		CloseHandle(hFile);
	}
}

void BattleCity::LoadMap(LPSTR hFileName)
{
	int Count = 0;
	int type;
	GameRelease();

	HANDLE hFile = CreateFile(hFileName, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	for (int i = 0; i < 13; i++)
	{
		for (int j = 0; j < 13; j++)
		{
			DWORD readB;
			ReadFile(hFile, &type, sizeof(int), &readB, NULL);
			if (!m_Map->GetCoustomMode())
			{
				if (type == PLAYER)
					PlayerUnit = new Player(m_Map, j, i);
				else if (type == ENEMY)
				{
					POINT pt;
					pt.x = j;
					pt.y = i;
					respawn.insert(pair<int, POINT>(Count++, pt));
				}
				else
					m_Map->InitBloclk(j, i, type);
			}
			else
				m_Map->InitBloclk(j, i, type);
		}
	}
	CloseHandle(hFile);
	if (!m_Map->GetCoustomMode())
	{
		Total_Enemy = 18;
		MakeEnemyCounter = 1.5;
		m_Flag.PlayFlag = true;
	}
}
//==================================================================================================================


void BattleCity::CustomStart(HWND hWnd, HINSTANCE g_hInst)
{
	m_Map->CustomMode_On(true);
	CustomButtom[0] = CreateWindow("button", "1. �����", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | WS_GROUP, 1010, 50, 100, 30, hWnd, (HMENU)0, g_hInst, NULL);
	CustomButtom[1] = CreateWindow("button", "2. ����", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 1010, 90, 100, 30, hWnd, (HMENU)1, g_hInst, NULL);
	CustomButtom[2] = CreateWindow("button", "3. ������", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 1010, 130, 100, 30, hWnd, (HMENU)2, g_hInst, NULL);
	CustomButtom[3] = CreateWindow("button", "4. �º���", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 1010, 170, 100, 30, hWnd, (HMENU)3, g_hInst, NULL);
	CustomButtom[4] = CreateWindow("button", "5. �Ʒ�����", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 1010, 210, 100, 30, hWnd, (HMENU)4, g_hInst, NULL);
	CustomButtom[5] = CreateWindow("button", "6. �캮��", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 1010, 250, 100, 30, hWnd, (HMENU)5, g_hInst, NULL);
	CustomButtom[6] = CreateWindow("button", "7. ����", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 1010, 290, 100, 30, hWnd, (HMENU)6, g_hInst, NULL);
	CustomButtom[7] = CreateWindow("button", "8. ��Ǯ", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 1010, 330, 100, 30, hWnd, (HMENU)7, g_hInst, NULL);
	CustomButtom[8] = CreateWindow("button", "9. ��", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 1010, 370, 100, 30, hWnd, (HMENU)8, g_hInst, NULL);
	CustomButtom[9] = CreateWindow("button", "10. ö��", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 1010, 410, 100, 30, hWnd, (HMENU)9, g_hInst, NULL);
	CustomButtom[10] = CreateWindow("button", "11. ��ö��", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 1010, 450, 100, 30, hWnd, (HMENU)10, g_hInst, NULL);
	CustomButtom[11] = CreateWindow("button", "12. ��ö��", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 1010, 490, 100, 30, hWnd, (HMENU)11, g_hInst, NULL);
	CustomButtom[12] = CreateWindow("button", "13. �Ʒ�ö��", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 1010, 530, 100, 30, hWnd, (HMENU)12, g_hInst, NULL);
	CustomButtom[13] = CreateWindow("button", "14. ��ö��", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 1010, 570, 100, 30, hWnd, (HMENU)13, g_hInst, NULL);
	CustomButtom[14] = CreateWindow("button", "Save", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 1250, 50, 100, 30, hWnd, (HMENU)100, g_hInst, NULL);
	CustomButtom[15] = CreateWindow("button", "Load", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 1250, 90, 100, 30, hWnd, (HMENU)101, g_hInst, NULL);
	CustomButtom[16] = CreateWindow("button", "EXIT", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 1250, 130, 100, 30, hWnd, (HMENU)102, g_hInst, NULL);
}

void BattleCity::CustomEnd()
{
	m_Map->ReleaseMap();
	for (int i = 0; i < 20; i++)
		DestroyWindow(CustomButtom[i]);
	m_Map->CustomMode_On(false);

}

void BattleCity::InitCursor(int Type)
{
	CurType = Type;
}

void BattleCity::ChangeBlock(POINT pt)
{
	int x = (pt.x - 50) / BLOCK_WIDTH;
	int y = (pt.y - 50) / BLOCK_HEIGHT;
	if ((pt.x < BLOCK_WIDTH * 13 + 50 && pt.x > 50) && (pt.y < BLOCK_HEIGHT * 13 + 50 && pt.y > 50))
	{
		m_Map->InitBloclk(x, y, CurType);
	}
}

//==================================================================================================================

void BattleCity::MakeEnemy()
{
	if (Field_Enemy < 1 && Total_Enemy >= 4)
	{
		int Count = rand() % respawn.size();
		EnemyList.push_back(new Enemy(m_Map, respawn.find(Count)->second.x, respawn.find(Count)->second.y));
	}
}

void BattleCity::Game_UpDate(HWND hWnd)
{
	QueryPerformanceFrequency(&Frequency);
	Field_Enemy = EnemyList.size();
	if (m_Flag.UseFrameCount)
	{
		QueryPerformanceCounter(&End);
		Delta = (double)(End.QuadPart - Start.QuadPart) / (double)(Frequency.QuadPart);
		MakeEnemyCounter += Delta;
		PlayerMove();
		EnemyMove();
		if (MakeEnemyCounter >= 2)
		{
			MakeEnemy();
			MakeEnemyCounter = 0;
		}
		MissileMove();
		DamageCheck();
		ReleaseMissile();
		ReleaseEnemy();

		QueryPerformanceCounter(&Start);
	}
	else
	{
		m_Flag.UseFrameCount = true;
		QueryPerformanceCounter(&Start);
	}

	DrawGame(hWnd);

	if (Total_Enemy == 0)
	{
		if (m_iStage <= 4)
			QuestionNextStage(hWnd);
		else
			GameEnd(hWnd, false);
	}
	if (!PlayerUnit->GetUseUnit() || m_Map->GetCommandCenter() == DEFEAT)
		GameEnd(hWnd, true);

 	if (m_Map->GetCommandCenter() == DEFEAT)
		GameEnd(hWnd, true);
}

void BattleCity::PlayerMove()
{
	bool DeathCheck = PlayerUnit->GetDeath();

	PlayerUnit->SetFrame(Delta);
	if (PlayerUnit->GetDeath())
		PlayerUnit->DeathProcess();
	else
	{
		if (!PlayerUnit->MoveCharacter())
			PlayerUnit->ReleaseFrame();
		if (GetKeyState(VK_SPACE) & 0x8000)
		{
			if (PlayerUnit->UseShoot())
				m_MissileList.push_back(PlayerUnit->MakeMissile());
		}
	}
}

void BattleCity::EnemyMove()
{
	int RandomMissile;
	bool Fire = false;
	bool Move;
	for (auto iter = EnemyList.begin(); iter != EnemyList.end(); iter++)
	{
		int RandomShoot = rand() % 100 + 1;
		(*iter)->SetFrame(Delta);
		if (!(*iter)->GetDeath())
		{	
			/*
			if ((*iter)->UseShoot())
			{
				if (RandomShoot < (*iter)->GetMoveSpeed() / 5)
					m_MissileList.push_back((*iter)->MakeMissile());
			}
			*/
			(*iter)->MoveCharacter();
		}
		else
			(*iter)->DeathProcess();
	}
}


void BattleCity::MissileMove()
{
	if (m_MissileList.size() != 0)
	{
		for (auto iter = m_MissileList.begin(); iter != m_MissileList.end(); iter++)
		{
			(*iter)->SetFrameCounter(Delta);
			(*iter)->MoveMissile();
		}
	}
}


void BattleCity::ReleaseEnemy()
{
	bool NotDelete;
	while (1)
	{
		NotDelete = true;
		for (auto iter = EnemyList.begin(); iter != EnemyList.end(); iter++)
		{
			if (!(*iter)->GetUseUnit() && (*iter)->GetDeath())
			{
				iter = EnemyList.erase(iter);
				NotDelete = false;
				break;
			}
		}
		if (NotDelete)
			return;
		else
			Total_Enemy--;
	}
}



void BattleCity::ReleaseMissile()
{
	bool NotDelete;
	while (1)
	{
		NotDelete = true;
		for (auto iter = m_MissileList.begin(); iter != m_MissileList.end(); iter++)
		{
			if (!(*iter)->GetStand())
			{
				iter = m_MissileList.erase(iter);
				NotDelete = false;
				break;
			}
		}
		if (NotDelete)
			return;
	}
}

void BattleCity::QuestionNextStage(HWND hWnd)
{
	if (MessageBox(hWnd, TEXT("GO Next Game?"), TEXT("Stage Clear!"), MB_YESNO) == IDYES)
	{
		if (!m_Flag.PlayCustom)
		{
			m_iStage++;
			SelectStage();
			DrawGame(hWnd);
		}
		else
		{
			SetOpenFile(hWnd, LOAD);
			DrawGame(hWnd);
		}
	}
	else
	{
		m_Flag.PlayFlag = false;
		m_Flag.PlayCustom = false;
		GameRelease();
		DrawGame(hWnd);
	}
}

void BattleCity::GameEnd(HWND hWnd, bool Over)
{
	bool End = true;
	if (Over)
	{
		if (MessageBox(hWnd, TEXT("New Game"), TEXT("GAME OVER"), MB_YESNO) == IDYES)
			End = false;
	}
	else
	{
		if (MessageBox(hWnd, TEXT("New Game"), TEXT("GAME CLEAR"), MB_YESNO) == IDYES)
			End = false;
	}
	if (!End)
	{
		if (!m_Flag.PlayCustom)
		{
			m_iStage = 1;
			SelectStage();
			DrawGame(hWnd);
		}
		else
		{
			LoadMap(curFile);
			DrawGame(hWnd);
		}
	}
	else
	{
		m_Flag.PlayFlag = false;
		m_Flag.PlayCustom = false;
		GameRelease();
		DrawGame(hWnd);
	}
}

void BattleCity::GameRelease()
{
	delete PlayerUnit;
	PlayerUnit = NULL;

	m_Map->ReleaseMap();
	for (auto iter = m_MissileList.begin(); iter != m_MissileList.end(); iter++)
		delete (*iter);
	m_MissileList.clear();

	for(auto iter = EnemyList.begin(); iter != EnemyList.end(); iter++)
		delete (*iter);
	EnemyList.clear();

	Respawn.clear();
}

void BattleCity::DamageCheck()
{
	for (auto iter = m_MissileList.begin(); iter != m_MissileList.end(); iter++)
	{
		if ((*iter)->GetStartUnit() == ENEMY)
		{
			if (PlayerUnit->DamageCheck(*iter))
				(*iter)->ReleaseStand();
		}
		else if ((*iter)->GetStartUnit() == PLAYER)
		{
			for (auto iter2 = EnemyList.begin(); iter2 != EnemyList.end(); iter2++)
			{
				if ((*iter2)->DamageCheck(*iter))
				{
					(*iter)->ReleaseStand();
					break;
				}
			}
		}
	}
}

void BattleCity::DrawGame(HWND hWnd)
{
	bool Custom = m_Map->GetCoustomMode();
	HDC hdc = GetDC(hWnd);
	Image::GetImageMaker()->SetBlock(hdc);
	Image::GetImageMaker()->SetScreen(Custom);
	m_Map->DrawMap(false);
	for (auto iter = m_MissileList.begin(); iter != m_MissileList.end(); iter++)
		(*iter)->DrawMissile();
	if (m_Flag.PlayFlag)
	{
		PlayerUnit->DrawUnit();
		if (EnemyList.size() != 0)
		{
			for (auto iter = EnemyList.begin(); iter != EnemyList.end(); iter++)
				(*iter)->DrawUnit();
		}
		Image::GetImageMaker()->DrawGameIcon(ICON_X, PLAYER_ICON_Y, PLAYER_ICON, PlayerUnit->GetLife());
		Image::GetImageMaker()->DrawGameIcon(ICON_X, STAGE_ICON_Y, STAGE_ICON, m_iStage);
		Image::GetImageMaker()->DrawGameIcon(ICON_X, ENEMY_ICON_Y, ENEMY_ICON, Total_Enemy);
	}
	if (!Custom)
		m_Map->DrawMap(true);
	Image::GetImageMaker()->DrawScreen(hdc);
	Image::GetImageMaker()->ReleaseMap();
	ReleaseDC(hWnd, hdc);
}

