#pragma once
#include "Image.h"
#include <map>
using namespace std;

struct BlockData
{
	int Type;
	POINT pt;
	RECT rt;
};

class GameMap
{
private:
	bool CustomeMode;
	int Command_Key;
	BlockData g_Map[13][13];
	POINT Base_pt;
public:
	GameMap();
	void ReleaseMap();
	void CustomMode_On(bool On_Off);
	void InitBloclk(int x, int y, int Type);
	BlockData MakeData(int x, int y, int Type);
	void DrawMap(bool DrawThicket);
	bool CheckNotImpulse(RECT rt, bool missile = false);
	void BorkenWall(RECT rt, int ImpulseWay);

	inline int GetBlock(int x, int y)
	{
		return g_Map[y][x].Type;
	}
	inline int GetCommandCenter()
	{
		return g_Map[Base_pt.y][Base_pt.x].Type;
	}
	inline bool GetCoustomMode()
	{
		return CustomeMode;
	}
	inline POINT GetCommandPoint()
	{
		return Base_pt;
	}
	~GameMap();
};

