#include "GameMap.h"

GameMap::GameMap()
{
	ReleaseMap();
}

void GameMap::CustomMode_On(bool On_Off)
{
	CustomeMode = On_Off;
}

void GameMap::InitBloclk(int x, int y, int Type)
{
	g_Map[y][x].Type = Type;

	g_Map[y][x].rt.top = 50 + y * BLOCK_HEIGHT;
	g_Map[y][x].rt.bottom = (50 + y * BLOCK_HEIGHT) + BLOCK_HEIGHT;
	g_Map[y][x].rt.left = 50 + x * BLOCK_WIDTH;
	g_Map[y][x].rt.right = (50 + x * BLOCK_WIDTH) + BLOCK_WIDTH;


	if (Type == TOP_BRICK || Type == TOP_METAL)
		g_Map[y][x].rt.bottom = (50 + y * BLOCK_HEIGHT) + (BLOCK_HEIGHT / 2);
	else if (Type == BOTTOM_BRICK || Type == BOTTOM_METAL)
		g_Map[y][x].rt.top = (50 + y * BLOCK_HEIGHT) + (BLOCK_HEIGHT / 2);
	else if (Type == LEFT_BRICK || Type == LEFT_METAL)
		g_Map[y][x].rt.right = (50 + x * BLOCK_WIDTH) + (BLOCK_WIDTH / 2);
	else if (Type == RIGHT_BRICK || Type == RIGHT_METAL)
		g_Map[y][x].rt.left = (50 + x * BLOCK_WIDTH) + (BLOCK_WIDTH / 2);

	if (Type == COMMAND_CENTER)
	{
		Base_pt.x = x;
		Base_pt.y = y;
	}
}


void GameMap::ReleaseMap()
{
	memset(g_Map, 0, sizeof(BlockData) * 13 * 13);
}

BlockData GameMap::MakeData(int x, int y, int Type)
{
	BlockData tmp;
	tmp.Type = Type;
	tmp.pt.x = x;
	tmp.pt.y = y;
	tmp.rt = { 50 + x * BLOCK_WIDTH , 50 + y * BLOCK_HEIGHT,  (50 + x * BLOCK_WIDTH) + BLOCK_WIDTH , (50 + y * BLOCK_HEIGHT) + BLOCK_HEIGHT };
	return tmp;
}

void GameMap::DrawMap(bool DrawThicket)
{
	for (int i = 0; i < 13; i++)
	{
		for (int j = 0; j < 13; j++)
		{
			if (g_Map[i][j].Type != NOT_BLOCK)
			{
				if (CustomeMode)
				{
					if (g_Map[i][j].Type == PLAYER)
						Image::GetImageMaker()->DrawUnit(TEXT("BattleCity\\tank_up_01.bmp"), j * BLOCK_WIDTH + 53, i * BLOCK_HEIGHT + 53);
					else if (g_Map[i][j].Type == ENEMY)
						Image::GetImageMaker()->DrawUnit(TEXT("BattleCity\\e_down_00.bmp"), j * BLOCK_WIDTH + 53, i * BLOCK_HEIGHT + 53);
					else
						Image::GetImageMaker()->DrawBlock(g_Map[i][j].Type, j, i);
				}
				else
				{
					if (!DrawThicket)
					{
						if (g_Map[i][j].Type != NOT_BLOCK && g_Map[i][j].Type != PLAYER && g_Map[i][j].Type != ENEMY)
							Image::GetImageMaker()->DrawBlock(g_Map[i][j].Type, j, i);
					}
					else
					{
						if (g_Map[i][j].Type == THICKET)
							Image::GetImageMaker()->DrawBlock(g_Map[i][j].Type, j, i);
					}
				}
			}
		}
	}
}


bool GameMap::CheckNotImpulse(RECT rt, bool missile)
{
	RECT tmp;
	for (int i = 0; i < 13; i++)
	{
		for (int j = 0; j < 13; j++)
		{
			if (g_Map[i][j].Type != NOT_BLOCK && g_Map[i][j].Type != ICE && g_Map[i][j].Type != THICKET)
			{
				if (IntersectRect(&tmp, &rt, &(g_Map[i][j].rt)))
				{
					if (missile && g_Map[i][j].Type == WATER)
						return true;
					else
						return false;
				}
			}
		}
	}
	return true;
}

void GameMap::BorkenWall(RECT rt, int ImpulseWay)
{
	RECT tmp;
	bool check = false;
	for (int i = 0; i < 13; i++)
	{
		for (int j = 0; j < 13; j++)
		{
			if (IntersectRect(&tmp, &rt, &(g_Map[i][j].rt)))
			{
				if (g_Map[i][j].Type == INTACT_BRICK)
				{
					if (ImpulseWay == LEFT)
					{
						InitBloclk(j, i, LEFT_BRICK);
						break;
					}
					else if (ImpulseWay == RIGHT)
					{
						InitBloclk(j, i, RIGHT_BRICK);
						break;
					}
					else if (ImpulseWay == UP)
					{
						InitBloclk(j, i, TOP_BRICK);
						break;
					}
					else if (ImpulseWay == DOWN)
					{
						InitBloclk(j, i, BOTTOM_BRICK);
						break;
					}
				}
				else if (g_Map[i][j].Type == TOP_BRICK || g_Map[i][j].Type == RIGHT_BRICK || g_Map[i][j].Type == LEFT_BRICK || g_Map[i][j].Type == BOTTOM_BRICK)
				{
					InitBloclk(j, i, NOT_BLOCK);
					break;
				}
				else if (g_Map[i][j].Type == COMMAND_CENTER)
				{
					InitBloclk(j, i, DEFEAT);
					break;
				}
			}
		}
	}
}

GameMap::~GameMap()
{
	ReleaseMap();
}