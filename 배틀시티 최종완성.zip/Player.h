#pragma once
#include "Character.h"

class Player : public Character
{
private:
	POINT BackPoint;
	int Back_Up_MoveWay;
public:
	Player(GameMap* map,  int x, int y);
	void SetFrame(double Delta);
	bool MoveCharacter();
	void ImageID();
	bool DamageCheck(Missile* CheckMissile);
	void DeathProcess();
	void MoveChange();
	void DrawUnit();

	void SetDataPoint();
	void ReleaseFrame();
	Missile* MakeMissile();
	~Player();
};

