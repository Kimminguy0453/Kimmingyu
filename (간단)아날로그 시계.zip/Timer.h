#pragma once
#include<iostream>
#include<Windows.h>
using namespace std;

struct Time
{
	int Hour;
	int Second;
	int Minute;
};

struct Line
{
	int Angel;
	int Length;
};

enum LINETYPE
{
	HOUR,
	MINUTE,
	SECOND
};

class Timer
{
private:
	Time m_Time;
	Line HourLine;
	Line MinuteLine;
	Line SecondLine;
	RECT Circle = { 200, 200, 600, 600};
	static Timer* m_hThis;
public:
	static Timer* GetInstance()
	{
		if (m_hThis == NULL)
			m_hThis = new Timer;
		return m_hThis;
	}
	void SetTime(int hour, int minute, int second);
	void WatchDraw(HDC hdc);
	void SetLine();
};

