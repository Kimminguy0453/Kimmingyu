#include "Timer.h"

Timer* Timer::m_hThis = NULL;

void Timer::SetLine()
{
	HourLine.Angel = 30;
	MinuteLine.Angel = 6;
	SecondLine.Angel = 6;
	HourLine.Length = 70;
	MinuteLine.Length = 150;
	SecondLine.Length = 190;

}

void Timer::SetTime(int hour, int minute, int second)
{
	m_Time.Hour = hour;
	m_Time.Minute = minute;
	m_Time.Second = second;
}

void Timer::WatchDraw(HDC hdc)
{
	int x; 
	int y;
	int Num = 1;
	TCHAR Str[128];
	Ellipse(hdc, 200, 200, 600, 600);
	for (int i = -60; i < 300; i = i + 30)
	{
		//������ 0���� �����ϸ� sin(0)�� 0�̰� cos(0)�� 1�̱� ������ x 600, y 400 �� ������. sin(-60) = sin(360 - 60) = sin(300)
		x = cos(i * 3.14 / 180) * 200 + 400;
		y = sin(i * 3.14 / 180) * 200 + 400;
		wsprintf(Str, TEXT("%d"), Num);
		SetTextAlign(hdc,TA_CENTER);
		TextOut(hdc, x, y, Str, lstrlen(Str));
		Num++;
	}
	MoveToEx(hdc, 400 , 400, NULL);
	LineTo(hdc, cos((-90 + (SecondLine.Angel*m_Time.Second)) * 3.14 / 180) * SecondLine.Length + 400, sin((-90 + (SecondLine.Angel*m_Time.Second)) * 3.14 / 180) * SecondLine.Length + 400);
	MoveToEx(hdc, 400, 400, NULL);
	LineTo(hdc, cos((-90 + (MinuteLine.Angel*m_Time.Minute)) * 3.14 / 180) * MinuteLine.Length + 400, sin((-90 + (MinuteLine.Angel*m_Time.Minute)) * 3.14 / 180) * 	MinuteLine.Length + 400);
	MoveToEx(hdc, 400, 400, NULL);
	LineTo(hdc, cos((-90 + (HourLine.Angel*m_Time.Hour)) * 3.14 / 180) *HourLine.Length + 400, sin((-90 + (HourLine.Angel*m_Time.Hour)) * 3.14 / 180) * HourLine.Length + 400);
}

