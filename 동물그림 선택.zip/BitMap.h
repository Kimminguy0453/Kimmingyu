#pragma once
#include<iostream>
#include<list>
#include"resource.h"
#include<Windows.h>
using namespace std;

#define MAP_WIDHT 145
#define MAP_HEIGHT 235

struct MapData
{
	int Map;
	int x;
	int y;
	int Width;
	int Height;
	LPCTSTR Name;
};

class BitMap
{
private:
	list<MapData> m_List;
	HBITMAP MyBitMap, OldBitMap;
	static BitMap* m_hThis;
public:
	BitMap();
	static BitMap* GetInstance()
	{
		if (m_hThis == NULL)
			m_hThis = new BitMap;
		return m_hThis;
	}
	void SetBitMap();
	void DrawBitMap(HINSTANCE inst, HDC Memdc, HDC hdc);
	MapData SetMapData(int Map,int x, int y, int Width, int Height, LPCTSTR Name);
	void DeleteBitMap();
	void DeleteInstance();
	void MessageBoxDraw(HWND hWnd, int x, int y);
	inline HBITMAP GetBitMap()
	{
		return OldBitMap;
	}
	~BitMap();
};

