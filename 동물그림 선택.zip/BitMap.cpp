#include "BitMap.h"

BitMap* BitMap::m_hThis = NULL;
BitMap::BitMap(){}

void BitMap::SetBitMap()
{
	int x = MAP_WIDHT + 10;
	int y = MAP_HEIGHT + 10;
	m_List.push_back(SetMapData(IDB_BITMAP1, 0, 0, MAP_WIDHT, MAP_HEIGHT, TEXT("������ �׸�")));
	m_List.push_back(SetMapData(IDB_BITMAP2, x * 1, 0, MAP_WIDHT, MAP_HEIGHT, TEXT("ȣ���� �׸�")));
	m_List.push_back(SetMapData(IDB_BITMAP3, x * 2, 0, MAP_WIDHT, MAP_HEIGHT, TEXT("���� �׸�")));
	m_List.push_back(SetMapData(IDB_BITMAP4, x * 3, 0, MAP_WIDHT, MAP_HEIGHT, TEXT("�ڳ��� �׸�")));
	m_List.push_back(SetMapData(IDB_BITMAP5, x * 4, 0, MAP_WIDHT, MAP_HEIGHT, TEXT("�� �׸�")));
	m_List.push_back(SetMapData(IDB_BITMAP6, 0, y, MAP_WIDHT, MAP_HEIGHT, TEXT("�� �׸�")));
	m_List.push_back(SetMapData(IDB_BITMAP7, x * 1, y, MAP_WIDHT, MAP_HEIGHT, TEXT("������ �׸�")));
	m_List.push_back(SetMapData(IDB_BITMAP8, x * 2, y, MAP_WIDHT, MAP_HEIGHT, TEXT("������ �׸�")));
	m_List.push_back(SetMapData(IDB_BITMAP9, x * 3, y, MAP_WIDHT, MAP_HEIGHT, TEXT("�������׸�")));
	m_List.push_back(SetMapData(IDB_BITMAP10, x * 4, y, MAP_WIDHT, MAP_HEIGHT, TEXT("�� �׸�")));
}

void BitMap::DrawBitMap(HINSTANCE inst, HDC Memdc, HDC hdc)
{
	for (auto iter = m_List.begin(); iter != m_List.end(); iter++)
	{
		MyBitMap = LoadBitmap(inst, MAKEINTRESOURCE((*iter).Map));
		OldBitMap = (HBITMAP)SelectObject(Memdc, MyBitMap);
		BitBlt(hdc, (*iter).x, (*iter).y, (*iter).Width, (*iter).Height, Memdc, 0, 0, SRCCOPY);
	//	TextOut(hdc, 100, 100, (*iter).second.Name, lstrlen((*iter).second.Name));
		DeleteBitMap();
	}
}

void BitMap::DeleteBitMap()
{
	DeleteObject(MyBitMap);
}

void BitMap::DeleteInstance()
{
	delete m_hThis;
	m_hThis = NULL;
}

void BitMap::MessageBoxDraw(HWND hWnd, int x, int y)
{
	int Width;
	int Height;      
	for (auto iter = m_List.begin(); iter != m_List.end(); iter++)
	{
		Width = (*iter).Width + (*iter).x;
		Height = (*iter).Height + (*iter).y;

		if (x >= (*iter).x && x <= Width && y >= (*iter).y && y <= Height)
		{
			if (MessageBox(hWnd, (*iter).Name, TEXT("���� ����"), MB_OK) == IDOK)
				return;
		}
	}
}

MapData BitMap::SetMapData(int Map, int x, int y, int Width, int Height, LPCTSTR Name)
{
	MapData data;

	data.Map = Map;
	data.x = x;
	data.y = y;
	data.Width = Width;
	data.Height = Height;
	data.Name = Name;

	return data;
}

BitMap::~BitMap()
{
}