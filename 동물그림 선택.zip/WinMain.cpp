#include "BitMap.h"
#include <iomanip>
HINSTANCE g_hInst;//�۷ι� �ν��Ͻ��ڵ鰪
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LPCTSTR lpszClass = TEXT("HelloWorld");

struct Circle
{
	int x;
	int y;
	int Radius;
};

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPervlnstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);
	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL,
		(HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);
	while (GetMessage(&Message, NULL, 0, 0))
	{
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc, MemDC;
	PAINTSTRUCT ps;
	switch (iMessage)
	{
	case WM_CREATE:
		BitMap::GetInstance()->SetBitMap();
		return 0;
	case WM_LBUTTONDOWN:
		BitMap::GetInstance()->MessageBoxDraw(hWnd, LOWORD(lParam), HIWORD(lParam));
		return 0;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		MemDC = CreateCompatibleDC(hdc);
		BitMap::GetInstance()->DrawBitMap(g_hInst, MemDC, hdc);
		SelectObject(MemDC, BitMap::GetInstance()->GetBitMap());//DC�� ������ �ϳ��̻��� ����� ������ �־���Ѵ�.
		DeleteDC(MemDC);
		EndPaint(hWnd, &ps);
		//���̶� �Ѱ��� ���� �������� ��� �������� ������ ������ �Ÿ��� ������ ������ ����.
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		BitMap::GetInstance()->DeleteInstance();
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
