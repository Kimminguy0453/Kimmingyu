#pragma once
#include <Windows.h>
#include <list>
using namespace std;

#define TIMER 109
#define MINEBOARD 648
#define SCOREBOARD_Y 467
#define SCOREBOARD_WDITH 104
#define SCOREBOARD_HEIGHT 34

enum IMAGE_STYLE
{
	SCREEN,
	BACK,
	BLOCK_ZERO,
	BLOCK_ONE,
	BLOCK_TWO,
	BLOCK_THREE,
	BLOCK_FOUR,
	BLOCK_FIVE,
	BLOCK_SIX,
	BLOCK_SEVEN,
	BLOCK_EIGHT,
	BLOCK_UNCHECK,
	BLOCK_FLAG,
	BLOCK_MINE,
	STYLE_MAX
};
class Image
{
private:
	HDC MemDC[STYLE_MAX];
	HBITMAP Use_Image[STYLE_MAX];
	HBITMAP Old_Image[STYLE_MAX];
	list <RECT> BackRectList;
	static Image* p_DrawMaker;
public:
	static Image* GetImageMaker()
	{
		if (p_DrawMaker == NULL)
			p_DrawMaker = new Image;
		return p_DrawMaker;
	}
	void InitScreen(HDC hdc, int Width, int Height);
	void DrawScreen(HDC hdc);
	void InitImage();
	LPCTSTR MakeGetID(int Style);
	void DrawBlock(int Style, int x, int y, int Width, int Height);
	void DrawBack(int Width, int Height, int HBorderline, int VBorderline);
	void DrawTime(int x, int y, int Width, int Height, int Time);
	void DrawMine(int x, int y, int Width, int Height, int MineCount);
	void Release();
	void ReleaseMaker();
};

