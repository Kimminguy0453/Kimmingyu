#include "Image.h"

Image* Image::p_DrawMaker = NULL;
void Image::InitScreen(HDC hdc, int Width, int Height)
{
	MemDC[(int)SCREEN] = CreateCompatibleDC(hdc);
	Use_Image[(int)SCREEN] = CreateCompatibleBitmap(hdc, Width, Height);
	Old_Image[(int)SCREEN] = (HBITMAP)SelectObject(MemDC[(int)SCREEN], Use_Image[(int)SCREEN]);

}

void  Image::DrawScreen(HDC hdc)
{
	BITMAP btSize;
	GetObject(Use_Image[(int)SCREEN], sizeof(btSize), &btSize);
	BitBlt(hdc, 0, 0, btSize.bmWidth, btSize.bmHeight, MemDC[(int)SCREEN], 0, 0, SRCCOPY);
}

void Image::InitImage()
{
	for (int i = BACK; i < STYLE_MAX; i++)
	{
		MemDC[i] = CreateCompatibleDC(MemDC[(int)SCREEN]);
		Use_Image[i] = (HBITMAP)LoadImage(NULL, MakeGetID(i), IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE);
		Old_Image[i] = (HBITMAP)SelectObject(MemDC[i], Use_Image[i]);
	}
}

LPCTSTR Image::MakeGetID(int Style)
{
	if (Style == BACK)
		return TEXT("Mine\\back.bmp");
	else if (Style == BLOCK_ZERO)
		return TEXT("Mine\\block_0.bmp");
	else if (Style == BLOCK_ONE)
		return TEXT("Mine\\block_1.bmp");
	else if (Style == BLOCK_TWO)
		return TEXT("Mine\\block_2.bmp");
	else if (Style == BLOCK_THREE)
		return TEXT("Mine\\block_3.bmp");
	else if (Style == BLOCK_FOUR)
		return TEXT("Mine\\block_4.bmp");
	else if (Style == BLOCK_FIVE)
		return TEXT("Mine\\block_5.bmp");
	else if (Style == BLOCK_SIX)
		return TEXT("Mine\\block_6.bmp");
	else if (Style == BLOCK_SEVEN)
		return TEXT("Mine\\block_7.bmp");
	else if (Style == BLOCK_EIGHT)
		return TEXT("Mine\\block_8.bmp");
	else if (Style == BLOCK_UNCHECK)
		return TEXT("Mine\\block.bmp");
	else if (Style == BLOCK_FLAG)
		return TEXT("Mine\\flag.bmp");
	else if (Style == BLOCK_MINE)
		return TEXT("Mine\\mine.bmp");
}

void Image::DrawBlock(int Style, int x, int y, int Width, int Height)
{
	BITMAP btSize;
	GetObject(Use_Image[Style], sizeof(btSize), &btSize);
	TransparentBlt(MemDC[(int)SCREEN], x, y, Width, Height, MemDC[Style], 0, 0, btSize.bmWidth, btSize.bmHeight, RGB(255, 0, 255));
}


void Image::DrawBack(int Width, int Height, int HBorderline, int VBorderline)
{
	TCHAR strScore[128];
	BITMAP btSize;
	GetObject(Use_Image[(int)BACK], sizeof(btSize), &btSize);
	//��� �κ�
	TransparentBlt(MemDC[(int)SCREEN], 0, 0, HBorderline, VBorderline, MemDC[BACK], 0, 0, btSize.bmWidth / 21, btSize.bmHeight / 11.7, RGB(255, 0, 255));//Top������
	TransparentBlt(MemDC[(int)SCREEN], HBorderline, 0, Width - (HBorderline * 2), VBorderline, MemDC[BACK], btSize.bmWidth / 21, 0, btSize.bmWidth - (btSize.bmWidth / 21) * 2, btSize.bmHeight / 11.7, RGB(255, 0, 255));//Top������
	TransparentBlt(MemDC[(int)SCREEN], Width - HBorderline, 0, HBorderline, VBorderline, MemDC[BACK], btSize.bmWidth - (btSize.bmWidth / 21), 0, btSize.bmWidth / 21, btSize.bmHeight / 11.7, RGB(255, 0, 255));//Top������
	//
	//�ϴ� �κ�
	TransparentBlt(MemDC[(int)SCREEN], 0, Height - VBorderline, HBorderline, VBorderline, MemDC[BACK], 0, btSize.bmHeight - (btSize.bmHeight / 11.6), btSize.bmWidth / 20.5, (btSize.bmHeight / 11.7), RGB(255, 0, 255));//bottom�׵θ�
	TransparentBlt(MemDC[(int)SCREEN], HBorderline, Height - VBorderline, Width - (HBorderline * 2), VBorderline, MemDC[BACK], btSize.bmWidth / 21, btSize.bmHeight - (btSize.bmHeight / 11.7), btSize.bmWidth - (btSize.bmWidth / 21) * 2, (btSize.bmHeight / 11.7), RGB(255, 0, 255));//bottom�׵θ�
	TransparentBlt(MemDC[(int)SCREEN], Width - HBorderline, Height - VBorderline, HBorderline, VBorderline, MemDC[BACK], btSize.bmWidth - (btSize.bmWidth / 21), btSize.bmHeight - (btSize.bmHeight / 11.7), btSize.bmWidth / 21, (btSize.bmHeight / 11.7), RGB(255, 0, 255));//bottom�׵θ�
	//
	//�¿� �κ�
	TransparentBlt(MemDC[(int)SCREEN], 0, VBorderline, HBorderline, Height - VBorderline * 2, MemDC[BACK], 0, btSize.bmHeight / 11.7, btSize.bmWidth / 21, btSize.bmHeight - (btSize.bmHeight / 11.7)*2, RGB(255, 0, 255));//Left�׵θ�
	TransparentBlt(MemDC[(int)SCREEN], Width-HBorderline, VBorderline, HBorderline, Height - VBorderline * 2, MemDC[BACK], btSize.bmWidth-(btSize.bmWidth / 21), btSize.bmHeight / 11.7, btSize.bmWidth / 21, btSize.bmHeight - (btSize.bmHeight / 11.6) * 2, RGB(255, 0, 255));//Right�׵θ�
	//
}

void Image::DrawTime(int x, int y, int Width, int Height, int Time)
{
	TCHAR strScore[128];

	SetTextColor(MemDC[(int)SCREEN], RGB(255, 255, 255));
	SetBkMode(MemDC[(int)SCREEN], TRANSPARENT);//�������ó��

	TransparentBlt(MemDC[(int)SCREEN], x, y, Width, Height, MemDC[BACK], TIMER, SCOREBOARD_Y, SCOREBOARD_WDITH, SCOREBOARD_HEIGHT, RGB(255, 0, 255));//Ÿ�̸� �κ�
	wsprintf(strScore, TEXT("%d"), Time);
	TextOut(MemDC[(int)SCREEN], x + Width * 0.7, y + Height * 0.45, strScore, lstrlen(strScore));
}

void Image::DrawMine(int x, int y, int Width, int Height, int Mine)
{
	TCHAR strScore[128];


	SetTextColor(MemDC[(int)SCREEN], RGB(255, 255, 255));
	SetBkMode(MemDC[(int)SCREEN], TRANSPARENT);//�������ó��

	TransparentBlt(MemDC[(int)SCREEN], x, y, Width, Height, MemDC[BACK], MINEBOARD, SCOREBOARD_Y, SCOREBOARD_WDITH, SCOREBOARD_HEIGHT, RGB(255, 0, 255));//Ÿ�̸� �κ�
	wsprintf(strScore, TEXT("%d"), Mine);
	TextOut(MemDC[(int)SCREEN], x + Width * 0.2, y + Height * 0.45, strScore, lstrlen(strScore));
}

void Image::Release()
{
	for (int i = STYLE_MAX - 1; i >= SCREEN; i--)
	{
		SelectObject(MemDC[i], Old_Image[i]);
		DeleteObject(Use_Image[i]);
		DeleteDC(MemDC[i]);
	}
}

void Image::ReleaseMaker()
{
	delete p_DrawMaker;
	p_DrawMaker = NULL;
}