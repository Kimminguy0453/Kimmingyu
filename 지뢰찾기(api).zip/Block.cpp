#include "Block.h"

Block::Block(int x, int y, int Width, int Height, bool Mine, int Style)
{
	rt = { x , y, x + Width, y + Height };
	m_iWidth = Width;
	m_iHeight = Height;
	m_iStyle = Style;
	m_bMine = Mine;
	m_bCheck = false;
}

void Block::DrawBlock()
{
	if (m_bCheck)
		Image::GetImageMaker()->DrawBlock(m_iStyle, rt.left, rt.top, m_iWidth, m_iHeight);
	else 
		Image::GetImageMaker()->DrawBlock(BLOCK_UNCHECK, rt.left, rt.top, m_iWidth, m_iHeight);
}

void Block::StyleChange(int style)
{
	m_iStyle = style;
	if (style != BLOCK_UNCHECK)
		m_bCheck = true;
	else
		m_bCheck = false;
}

bool Block::CheckBlock(int x, int y)
{
	POINT pt;
	pt.x = x;
	pt.y = y;
	if (PtInRect(&rt, pt))
		return true;
	else
		return false;
}

bool Block::MineFlagCheck()
{
	if (m_bMine && m_bCheck)
		return true;
	else
		return false;
}