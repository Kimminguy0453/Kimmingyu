#pragma once
#include <Windows.h>
#include <map>
#include "Block.h"
#include <Time.h>
#define NOTKEY 999

enum GAME_LEVEL
{
	EASY = 9,
	NOMAL = 16,
	HARD = 30
};

enum GAME_SIZE
{
	EASY_WIDTH = 342,
	EASY_HEIGHT = 413,
	NOMAL_WIDTH = 552, 
	NOMAL_HEIGHT = 623,
	HARD_WIDTH = 972,
};

enum MINE_LEVEL
{
	EASY_MINE = 10,
	NOMAL_MINE = 40,
	HARD_MINE = 99
};


struct GAMEOPTION
{
	int Width;
	int Height;
	int MineCount;
};

class MineGame
{
private:
	GAMEOPTION Option;
	map <int, Block*> BlockList;
	list <POINT> MinePointList;
	bool FristCount;
	int Time;
	double Delta;
	LARGE_INTEGER Start, End, Frequency;
	RECT Screen;
	int HBorderline;
	int VBorderline;
	bool GameFlag;
	double DeltaTime;
	static MineGame* m_hThis;
public:
	static MineGame* GetGame()
	{
		if (m_hThis == NULL)
			m_hThis = new MineGame;
		return m_hThis;
	}
	//=================================================================
	//���� �ɼǰ���
	void SetGameOption(int Width, int Height, int Count);
	void SetBackSize(HWND hWnd);
	//=================================================================

	//=================================================================
	//���� ����
	void SetBlock();
	int FindKey(int x, int y);
	bool CheckBlock(int Key);
	void CheckFlag(int Key);
	bool PointCheck(int x, int y);
	bool MineCheck(int Key);
	void ReleaseBlock();
	//=================================================================

	//=================================================================
	//���� ����
	void GameUpdate(HWND hWnd);
	void GameDraw(HDC hdc);
	bool WinGame();
	void ReleaseGame();
	void ReSetGame();
	void EndGame();
	inline bool GetGameFlag()
	{
		return GameFlag;
	}

	//=================================================================

	//=================================================================
	//��Ÿ
	POINT MakeMinePoint();
	//=================================================================
};

