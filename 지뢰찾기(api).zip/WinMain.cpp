#pragma once
#include "MineGame.h"
#include "resource.h"
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
LPCTSTR lpszClass = TEXT("����ã��");
RECT Window_Rect = { CW_USEDEFAULT, CW_USEDEFAULT, NOMAL_WIDTH, NOMAL_HEIGHT };
bool ChangeOption = false;
int MineCount = NOMAL_MINE;
int GameWIdth = NOMAL;
int GameHeight = NOMAL;

void ChangeLevel();
void EndGame(HWND hWnd, bool Win);
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPervlnstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = MAKEINTRESOURCE(IDR_MENU1);
	WndClass.style = CS_HREDRAW | CS_VREDRAW;

	RegisterClass(&WndClass);
	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, Window_Rect.left, Window_Rect.top, Window_Rect.right, Window_Rect.bottom,
		NULL, (HMENU)NULL, hInstance, NULL);
	MineGame::GetGame()->SetGameOption(GameWIdth, GameHeight, MineCount);
	ShowWindow(hWnd, nCmdShow);
	MineGame::GetGame()->SetBackSize(hWnd);
	MineGame::GetGame()->SetBlock();

	while (1)
	{
		if (PeekMessage(&Message, NULL, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&Message);
			DispatchMessage(&Message);
			if (Message.message == WM_QUIT)
				break;
		}
		if (MineGame::GetGame()->GetGameFlag())
			MineGame::GetGame()->GameUpdate(hWnd);
		if (MineGame::GetGame()->WinGame())
			EndGame(hWnd, true);
	}
	return (int)Message.wParam;
}

BOOL CALLBACK AboutDlgProc(HWND hDlg, UINT iMessage, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	int x; 
	int y;
	switch (iMessage)
	{
	case WM_CREATE:
		GetWindowRect(hWnd, &Window_Rect);
		return 0;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case ID_OPTION_NEWGAME:
			MineGame::GetGame()->ReSetGame();
			break;
		case ID_GAME_OPTION:
			DialogBox(g_hInst, MAKEINTRESOURCE(IDD_DIALOG1), hWnd, AboutDlgProc);
			if (ChangeOption)
			{
				ChangeLevel();
				SetWindowPos(hWnd, NULL, Window_Rect.left, Window_Rect.top, Window_Rect.right, Window_Rect.bottom, NULL);
				MineGame::GetGame()->SetBackSize(hWnd);
				ChangeOption = false;
			}
			break;
		case ID_GAME_EXIT:
			MineGame::GetGame()->EndGame();
			PostQuitMessage(0);
			break;
		}
		return 0;
	case WM_LBUTTONDOWN:
		x = LOWORD(lParam);
		y = HIWORD(lParam);
		if (MineGame::GetGame()->CheckBlock(MineGame::GetGame()->FindKey(x, y)))
			EndGame(hWnd, false);
		return 0;
	case WM_RBUTTONDOWN:
		x = LOWORD(lParam);
		y = HIWORD(lParam);
		MineGame::GetGame()->CheckFlag(MineGame::GetGame()->FindKey(x, y));
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}

BOOL CALLBACK AboutDlgProc(HWND hDlg, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HWND hRadio;
	int BackUpWidth;
	int BackUpHeight;
	int BackUpMine;
	hRadio = CreateWindow(NULL, NULL, WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | WS_GROUP, 10, 20, 100, 30, hDlg, (HMENU)IDC_RADIO1, g_hInst, NULL);

	switch (iMessage)
	{
	case WM_INITDIALOG:
		CheckDlgButton(hDlg, IDC_CHECK1, BST_UNCHECKED);
		CheckRadioButton(hDlg, IDC_RADIO1, IDC_RADIO3, IDC_RADIO1);
		SetDlgItemInt(hDlg, IDC_EDIT1, GameWIdth, FALSE);
		SetDlgItemInt(hDlg, IDC_EDIT2, GameHeight, FALSE);
		SetDlgItemInt(hDlg, IDC_EDIT3, MineCount, FALSE);
		return TRUE;
	case WM_COMMAND:
		switch (wParam)
		{
		case IDOK:
			if (IsDlgButtonChecked(hDlg, IDC_CHECK1) == BST_UNCHECKED)
			{
				if (IsDlgButtonChecked(hDlg, IDC_RADIO1) == BST_CHECKED)
				{
					MineCount = EASY_MINE;
					GameWIdth = EASY;
					GameHeight = EASY;
					Window_Rect.right = EASY_WIDTH;
					Window_Rect.bottom = EASY_HEIGHT;
				}
				if (IsDlgButtonChecked(hDlg, IDC_RADIO2) == BST_CHECKED)
				{
					MineCount = NOMAL_MINE;
					GameWIdth = NOMAL;
					GameHeight = NOMAL;
					Window_Rect.right = NOMAL_WIDTH;
					Window_Rect.bottom = NOMAL_HEIGHT;
				}
				if (IsDlgButtonChecked(hDlg, IDC_RADIO3) == BST_CHECKED)
				{
					MineCount = HARD_MINE;
					GameWIdth = HARD;
					GameHeight = NOMAL;
					Window_Rect.right = HARD_WIDTH;
					Window_Rect.bottom = NOMAL_HEIGHT;
				}
				ChangeOption = true;
			}
			else
			{
				BackUpWidth = GameWIdth;
				BackUpHeight = GameHeight;
				BackUpMine = MineCount;
				GameWIdth = GetDlgItemInt(hDlg, IDC_EDIT1, NULL, FALSE);
				GameHeight = GetDlgItemInt(hDlg, IDC_EDIT2, NULL, FALSE);
				MineCount = GetDlgItemInt(hDlg, IDC_EDIT3, NULL, FALSE);
				
				if (MineCount > 99)
					MineCount = BackUpMine;

				if ((GameWIdth > 24 && GameWIdth < 0)|| (GameHeight > 24) && (GameHeight < 0) )
				{
					GameWIdth = BackUpWidth;
					GameHeight = BackUpHeight;
					MineCount = BackUpMine;
					ChangeOption = false;
				}
				else
				{
					Window_Rect.right = NOMAL_WIDTH + (GameWIdth - NOMAL) * 30;
					Window_Rect.bottom = NOMAL_HEIGHT + (GameHeight - NOMAL) * 30;
					ChangeOption = true;
				}
			}
			EndDialog(hDlg, 0);
			return TRUE;
		case IDCANCEL:
			ChangeOption = false;
			EndDialog(hDlg, 0);
			return TRUE;
		}
		break;
	}
	return false;
}


void EndGame(HWND hWnd, bool Win)
{
	MineGame::GetGame()->GameUpdate(hWnd);
	if (Win)
		MessageBox(hWnd, TEXT("�����մϴ�! ������ Ŭ�����ϼ̽��ϴ�."), TEXT("GAME CLEAR"), MB_OK);
	else
		MessageBox(hWnd, TEXT("Game Over"), TEXT("GAME OVER"), MB_OK);
	if (MessageBox(hWnd, TEXT("������ �����Ͻðڽ��ϱ�?"), TEXT("GAME OVER"), MB_YESNO) == IDYES)
		MineGame::GetGame()->EndGame();
	else
		MineGame::GetGame()->ReSetGame();
}

void ChangeLevel()
{
	MineGame::GetGame()->ReleaseBlock();
	MineGame::GetGame()->SetGameOption(GameWIdth, GameHeight, MineCount);
	MineGame::GetGame()->SetBlock();
}
