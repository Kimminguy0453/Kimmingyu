//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// Project1.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDR_MENU1                       101
#define IDD_DIALOG1                     102
#define IDC_RADIO1                      1007
#define IDC_RADIO2                      1008
#define IDC_RADIO3                      1009
#define IDC_EDIT1                       1010
#define IDC_CHECK1                      1013
#define IDC_EDIT2                       1015
#define IDC_EDIT3                       1016
#define ID_OPTION_NEWGAME               40001
#define ID_GAME_OPTION                  40002
#define ID_GAME_EXIT                    40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
