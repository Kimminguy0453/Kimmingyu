#include "MineGame.h"
//ù��° �� ������ Ű���� 0 ~29 �ι����� 30 ~ 59�̷���. 
//x ��ǥ + (y��ǥ*30) = map�� Ű ��
MineGame* MineGame::m_hThis = NULL;
void MineGame::SetBackSize(HWND hWnd)
{
	GetClientRect(hWnd, &Screen);

	HBorderline = (Screen.right - Option.Width  * 30) / 2;
	VBorderline = (Screen.bottom - Option.Height * 30) / 2;

}

void  MineGame::SetGameOption(int Width, int Height, int Count)
{
	Option.Width = Width;
	Option.Height = Height;
	Option.MineCount = Count;
	GameFlag = true;
	FristCount = true;
	Delta = 0;
	QueryPerformanceFrequency(&Frequency);
	Time = 0;
}

POINT MineGame::MakeMinePoint()
{
	POINT pt;

	while (1)
	{
		pt.x = rand() % Option.Width;
		pt.y = rand() % Option.Height;
		if (!PointCheck(pt.x, pt.y))
			return pt;
	}
}

bool MineGame::PointCheck(int x, int y)
{
	for (auto iter = MinePointList.begin(); iter != MinePointList.end(); iter++)
	{
		if (x == (*iter).x && y == (*iter).y)
			return true;
	}
	return false;
}

void MineGame::SetBlock()
{

	srand(time(NULL));
	for (int i = 0; i < Option.MineCount; i++)
		MinePointList.push_back(MakeMinePoint());
	for (int y = 0; y < Option.Height; y++)
	{
		for (int x = 0; x < Option.Width; x++)
		{
			if(PointCheck(x, y))
				BlockList.insert(pair<int, Block*>(x + y * Option.Width, new Block(HBorderline + x * 30, VBorderline + y * 30, 30 , 30 , true)));
			else
				BlockList.insert(pair<int, Block*>(x + y * Option.Width, new Block(HBorderline + x * 30, VBorderline + y * 30, 30, 30)));
		}
	}
	MinePointList.clear();
}

bool MineGame::WinGame()
{
	int EndCount = 0;
	for (auto iter = BlockList.begin(); iter != BlockList.end(); iter++)//�����׷��ֱ�
	{
		if (!(*iter).second->GetCheck())
			return false;
		if ((*iter).second->GetStyle() == BLOCK_FLAG)
		{
			if ((*iter).second->MineFlagCheck())
				EndCount++;
		}
	}
	if (EndCount == Option.MineCount)
		return true;
	else
		return false;
}

void MineGame::GameUpdate(HWND hWnd)
{
	int Minute;
	int Second;

	if (FristCount)
	{
		QueryPerformanceCounter(&Start);
		FristCount = false;
	}
	else
	{
		QueryPerformanceCounter(&End);
		Delta += (double)(End.QuadPart - Start.QuadPart) / (double)(Frequency.QuadPart);
	}
	HDC hdc = GetDC(hWnd);
	if (Delta > 1)
	{
		Time++;
		Delta = 0;
	}
	GameDraw(hdc);
	ReleaseDC(hWnd, hdc);
	if (!FristCount)
		Start = End;
}


bool MineGame::CheckBlock(int Key)
{
	int Count = BLOCK_ZERO;
	int Key_X = Key % Option.Width;
	int Key_Y = Key / Option.Width;;
	if (Key >= 0 && Key < Option.Width * Option.Height)
	{
		if (!BlockList.find(Key)->second->GetCheck())
		{
			if (MineCheck(Key))
			{
				BlockList.find(Key)->second->StyleChange(BLOCK_MINE);
				GameFlag = false;
				return true;
			}
			else
			{
				for (int y = Key_Y - 1; y <= Key_Y + 1; y++)
				{
					for (int x = Key_X - 1; x <= Key_X + 1; x++)
					{
						if (y >= 0 && y < Option.Height)
						{
							if (x >= 0 && x < Option.Width)
							{
								if(MineCheck(x + y * Option.Width))
									Count++;
							}
						}
					}
				}
				BlockList.find(Key)->second->StyleChange(Count);
			}
			if (Count == BLOCK_ZERO)
			{
				for (int y = Key_Y - 1; y <= Key_Y + 1; y++)
				{
					for (int x = Key_X - 1; x <= Key_X + 1; x++)
					{
						if (y >= 0 && y < Option.Height)
						{
							if (x >= 0 && x < Option.Width)
								CheckBlock(x + y * Option.Width);
						}
					} 
				}
			}
		}
	}
	return false;
}

bool MineGame::MineCheck(int Key)
{
	if (Key >= 0 && Key < Option.Width * Option.Height)
		return BlockList.find(Key)->second->GetMine();
	return false;
}

void MineGame::CheckFlag(int Key)
{
	if(Key >= 0 && Key < Option.Width * Option.Height)
	{
		if (!BlockList.find(Key)->second->GetCheck())
		{
			if(BlockList.find(Key)->second->GetStyle() == BLOCK_UNCHECK)
				BlockList.find(Key)->second->StyleChange(BLOCK_FLAG);
		}
		else
		{
			if (BlockList.find(Key)->second->GetStyle() == BLOCK_FLAG)
				BlockList.find(Key)->second->StyleChange(BLOCK_UNCHECK);
		}
	}
}

int MineGame::FindKey(int x, int y)
{
	for (auto iter = BlockList.begin(); iter != BlockList.end(); iter++)//�����׷��ֱ�
	{
		if ((*iter).second->CheckBlock(x, y))
			return (*iter).first;
	}
	return NOTKEY;
}

void MineGame::ReleaseBlock()
{
	for (auto iter = BlockList.begin(); iter != BlockList.end(); iter++)//�����׷��ֱ�
	{
		delete (*iter).second;
		(*iter).second = NULL;
	}
	BlockList.clear();
}

void MineGame::GameDraw(HDC hdc)
{
	int time_x = HBorderline + (Screen.right - HBorderline * 2) * 0.18;
	int Mine_x = HBorderline + (Screen.right - HBorderline * 2) * 0.8;

	Image::GetImageMaker()->InitScreen(hdc, Screen.right, Screen.bottom);// ��ũ������
	Image::GetImageMaker()->InitImage();//�̹����� ����
	Image::GetImageMaker()->DrawBack(Screen.right, Screen.bottom, HBorderline, VBorderline);

	for (auto iter = BlockList.begin(); iter != BlockList.end(); iter++)//�����׷��ֱ�
		(*iter).second->DrawBlock();
	Image::GetImageMaker()->DrawTime(HBorderline + (Screen.right - HBorderline * 2) * 0.09, (Screen.bottom - VBorderline) + (VBorderline * 0.04), (Screen.right - HBorderline * 2) * 0.2, VBorderline - 10, Time);
	Image::GetImageMaker()->DrawMine(HBorderline + (Screen.right - HBorderline * 2) * 0.7, (Screen.bottom - VBorderline) + (VBorderline * 0.04), (Screen.right - HBorderline * 2) * 0.2, VBorderline - 10, Option.MineCount);
	Image::GetImageMaker()->DrawScreen(hdc);
	Image::GetImageMaker()->Release();
}

void MineGame::ReSetGame()
{
	MineGame::GetGame()->ReleaseBlock();
	MineGame::GetGame()->SetBlock();
	Delta = 0;
	Time = 0;
	GameFlag = true;
}

void MineGame::EndGame()
{
	MineGame::GetGame()->ReleaseBlock();
	Image::GetImageMaker()->ReleaseMaker();
	MineGame::GetGame()->ReleaseGame();
	PostQuitMessage(0);
}


void MineGame::ReleaseGame()
{
	delete m_hThis;
	m_hThis = NULL;
}