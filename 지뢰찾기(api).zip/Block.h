#pragma once
#include "Image.h"

class Block
{
private:
	RECT rt;
	int m_iWidth;
	int m_iHeight;
	int m_iStyle;
	bool m_bMine;
	bool m_bCheck;
public:
	Block(int x, int y, int Width, int Height, bool Mine = false, int Style = BLOCK_UNCHECK);
	void DrawBlock();
	void StyleChange(int Style);
	bool CheckBlock(int x, int y);
	bool MineFlagCheck();
	inline bool GetCheck()
	{
		return m_bCheck;
	}
	inline bool GetMine()
	{
		return m_bMine;
	}
	inline int GetStyle()
	{
		return  m_iStyle;
	}
};

